import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type { SubtitleProject, SubtitleTrack, SubtitleSegment, SubtitleStyle } from '../types/subtitle';

interface SubtitleState {
  // Projects
  projects: SubtitleProject[];
  currentProjectId: string | null;
  currentProject: SubtitleProject | null;
  
  // Video
  videoFile: File | null;
  videoUrl: string | null;
  videoDuration: number;
  videoWidth: number;
  videoHeight: number;
  
  // Playback
  playbackTime: number;
  playbackRate: number;
  isPlaying: boolean;
  volume: number;
  
  // Selection
  selectedSegmentIds: string[];
  selectedSegmentId: string | null; // Add for backward compatibility
  activeTrackId: string | null;
  
  // UI State
  zoomLevel: number;
  scrollPosition: number;
  showWaveform: boolean;
  showTimestamps: boolean;
  snapToGrid: boolean;
  gridSize: number;
  
  // Transcription
  isTranscribing: boolean;
  selectedModel: string;
  transcriptionLanguage: string;
  
  // Styling
  fontSize: number;
  fontFamily: string;
  fontColor: string;
  backgroundColor: string;
  backgroundOpacity: number;
  textShadow: string;
  textStroke: string;
  padding: number;
  borderRadius: number;
  position: 'top' | 'center' | 'bottom';
  alignment: 'left' | 'center' | 'right';
  subtitleStyle: SubtitleStyle; // Add aggregated style object
  
  // Auto-save
  lastSaved: Date | null;
  hasUnsavedChanges: boolean;
  autoSaveEnabled: boolean;
  autoSaveInterval: number;
  
  // History
  history: any[];
  historyIndex: number;
  maxHistorySize: number;
  
  // Actions - Project Management
  createProject: (nameOrOptions: string | { name: string; videoUrl?: string; videoName?: string }) => void;
  loadProject: (projectId: string) => void;
  saveProject: () => void;
  deleteProject: (projectId: string) => void;
  exportProject: (format: 'json' | 'zip') => void;
  importProject: (file: File) => void;
  
  // Actions - Video
  setVideoFile: (file: File | null) => void;
  setVideoUrl: (url: string | null) => void;
  setVideoDuration: (duration: number) => void;
  setVideoSize: (width: number, height: number) => void;
  
  // Actions - Playback
  setPlaybackTime: (time: number) => void;
  setPlaybackRate: (rate: number) => void;
  setIsPlaying: (playing: boolean) => void;
  setVolume: (volume: number) => void;
  seekTo: (time: number) => void;
  skipForward: (seconds: number) => void;
  skipBackward: (seconds: number) => void;
  
  // Actions - Tracks
  addTrack: (projectIdOrTrack: string | Partial<SubtitleTrack>, track?: Partial<SubtitleTrack>) => void;
  updateTrack: (trackId: string, updates: Partial<SubtitleTrack>) => void;
  deleteTrack: (trackId: string) => void;
  setActiveTrack: (trackId: string) => void;
  reorderTracks: (fromIndex: number, toIndex: number) => void;
  
  // Actions - Segments
  addSegment: (projectIdOrTrackId: string, trackIdOrSegment: string | Partial<SubtitleSegment>, segment?: Partial<SubtitleSegment>) => void;
  addSegments: (trackId: string, segments: SubtitleSegment[]) => void;
  updateSegment: (projectIdOrTrackId: string, trackIdOrSegmentId: string, segmentIdOrUpdates: string | Partial<SubtitleSegment>, updates?: Partial<SubtitleSegment>) => void;
  deleteSegment: (projectIdOrTrackId: string, trackIdOrSegmentId: string, segmentId?: string) => void;
  deleteSelectedSegments: () => void;
  
  // Actions - Selection
  selectSegment: (segmentId: string, multi?: boolean) => void;
  selectAllSegments: () => void;
  clearSelection: () => void;
  selectSegmentsInRange: (startTime: number, endTime: number) => void;
  
  // Actions - Segment Operations
  splitSegment: (segmentIdOrTrackId: string, ratioOrSegmentId: number | string, time?: number) => void;
  mergeSegments: (segmentIdsOrTrackId: string[] | string, segmentIds?: string[]) => void;
  shiftSegments: (trackId: string, segmentIds: string[], deltaTime: number) => void;
  alignSegments: (trackId: string, segmentIds: string[], alignment: 'start' | 'end' | 'center') => void;
  
  // Actions - UI
  setZoomLevel: (level: number) => void;
  setScrollPosition: (position: number) => void;
  toggleWaveform: () => void;
  toggleTimestamps: () => void;
  toggleSnapToGrid: () => void;
  setGridSize: (size: number) => void;
  
  // Actions - Transcription
  setIsTranscribing: (transcribing: boolean) => void;
  setSelectedModel: (model: string) => void;
  setTranscriptionLanguage: (language: string) => void;
  
  // Actions - Styling
  setFontSize: (size: number) => void;
  setFontFamily: (family: string) => void;
  setFontColor: (color: string) => void;
  setBackgroundColor: (color: string) => void;
  setBackgroundOpacity: (opacity: number) => void;
  setTextShadow: (shadow: string) => void;
  setTextStroke: (stroke: string) => void;
  setPadding: (padding: number) => void;
  setBorderRadius: (radius: number) => void;
  setPosition: (position: 'top' | 'center' | 'bottom') => void;
  setAlignment: (alignment: 'left' | 'center' | 'right') => void;
  applyStyleToSelected: (style: Partial<SubtitleStyle>) => void;
  updateStyle: (style: Partial<SubtitleStyle>) => void; // Add updateStyle method
  setSubtitleStyle: (style: Partial<SubtitleStyle>) => void; // Add setSubtitleStyle method
  
  // Actions - History
  undo: () => void;
  redo: () => void;
  clearHistory: () => void;
  
  // Actions - Import/Export
  importSegments: (segments: SubtitleSegment[]) => void;
  exportSegments: (format: 'srt' | 'vtt' | 'ass') => string;
  
  // Actions - Auto-save
  setAutoSaveEnabled: (enabled: boolean) => void;
  setAutoSaveInterval: (interval: number) => void;
  markAsUnsaved: () => void;
  markAsSaved: () => void;
  
  // Computed getters
  getSegmentsInTimeRange: (startTime: number, endTime: number) => SubtitleSegment[]; // Add missing method
  getSegmentById: (segmentId: string) => SubtitleSegment | undefined; // Add missing method
}

export const useSubtitleStore = create<SubtitleState>()(
  devtools(
    persist(
      immer((set, get) => ({
        // Initial state
        projects: [],
        currentProjectId: null,
        currentProject: null,
        videoFile: null,
        videoUrl: null,
        videoDuration: 0,
        videoWidth: 1920,
        videoHeight: 1080,
        playbackTime: 0,
        playbackRate: 1,
        isPlaying: false,
        volume: 1,
        selectedSegmentIds: [],
        selectedSegmentId: null,
        activeTrackId: null,
        zoomLevel: 1,
        scrollPosition: 0,
        showWaveform: false,
        showTimestamps: true,
        snapToGrid: true,
        gridSize: 0.1,
        isTranscribing: false,
        selectedModel: 'whisper-base',
        transcriptionLanguage: 'auto',
        fontSize: 24,
        fontFamily: 'Arial',
        fontColor: '#FFFFFF',
        backgroundColor: '#000000',
        backgroundOpacity: 0.8,
        textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
        textStroke: '',
        padding: 10,
        borderRadius: 4,
        position: 'bottom' as const,
        alignment: 'center' as const,
        subtitleStyle: {
          fontSize: 24,
          fontFamily: 'Arial',
          fontColor: '#FFFFFF',
          backgroundColor: '#000000',
          backgroundOpacity: 0.8,
          textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
          textStroke: '',
          padding: 10,
          borderRadius: 4,
          position: 'bottom',
          alignment: 'center'
        },
        lastSaved: null,
        hasUnsavedChanges: false,
        autoSaveEnabled: true,
        autoSaveInterval: 30000,
        history: [],
        historyIndex: -1,
        maxHistorySize: 50,
        
        // Project Management
        createProject: (nameOrOptions) => set((state) => {
          const isObject = typeof nameOrOptions === 'object';
          const project: SubtitleProject = {
            id: Date.now().toString(),
            name: isObject ? nameOrOptions.name : nameOrOptions,
            createdAt: new Date(),
            updatedAt: new Date(),
            tracks: [],
            activeTrackId: null,
            videoFile: state.videoFile,
            videoUrl: isObject && nameOrOptions.videoUrl ? nameOrOptions.videoUrl : state.videoUrl,
            videoDuration: state.videoDuration,
            videoWidth: state.videoWidth,
            videoHeight: state.videoHeight,
            style: state.subtitleStyle
          };
          state.projects.push(project);
          state.currentProjectId = project.id;
          state.currentProject = project;
          state.hasUnsavedChanges = true;
        }),
        
        loadProject: (projectId) => set((state) => {
          const project = state.projects.find(p => p.id === projectId);
          if (project) {
            state.currentProjectId = projectId;
            state.currentProject = project;
            state.activeTrackId = project.activeTrackId;
            
            // Load project style
            if (project.style) {
              Object.assign(state, project.style);
            }
            
            // Load video info
            state.videoDuration = project.videoDuration;
            state.videoWidth = project.videoWidth;
            state.videoHeight = project.videoHeight;
          }
        }),
        
        saveProject: () => set((state) => {
          if (state.currentProject) {
            const projectIndex = state.projects.findIndex(p => p.id === state.currentProject!.id);
            if (projectIndex !== -1) {
              state.projects[projectIndex] = {
                ...state.currentProject,
                updatedAt: new Date()
              };
              state.lastSaved = new Date();
              state.hasUnsavedChanges = false;
            }
          }
        }),
        
        deleteProject: (projectId) => set((state) => {
          state.projects = state.projects.filter(p => p.id !== projectId);
          if (state.currentProjectId === projectId) {
            state.currentProjectId = null;
            state.currentProject = null;
          }
        }),
        
        exportProject: (format) => {
          // Implementation depends on format
          const state = get();
          if (!state.currentProject) return;
          
          if (format === 'json') {
            const data = JSON.stringify(state.currentProject, null, 2);
            const blob = new Blob([data], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${state.currentProject.name}.json`;
            a.click();
            URL.revokeObjectURL(url);
          }
        },
        
        importProject: async (file) => {
          // Implementation for importing project
          const text = await file.text();
          const project = JSON.parse(text) as SubtitleProject;
          
          set((state) => {
            project.id = Date.now().toString();
            state.projects.push(project);
            state.currentProjectId = project.id;
            state.currentProject = project;
          });
        },
        
        // Video
        setVideoFile: (file) => set((state) => {
          state.videoFile = file;
          if (state.currentProject) {
            state.currentProject.videoFile = file;
            state.hasUnsavedChanges = true;
          }
        }),
        
        setVideoUrl: (url) => set((state) => {
          state.videoUrl = url;
          if (state.currentProject) {
            state.currentProject.videoUrl = url;
            state.hasUnsavedChanges = true;
          }
        }),
        
        setVideoDuration: (duration) => set((state) => {
          state.videoDuration = duration;
          if (state.currentProject) {
            state.currentProject.videoDuration = duration;
            state.hasUnsavedChanges = true;
          }
        }),
        
        setVideoSize: (width, height) => set((state) => {
          state.videoWidth = width;
          state.videoHeight = height;
          if (state.currentProject) {
            state.currentProject.videoWidth = width;
            state.currentProject.videoHeight = height;
            state.hasUnsavedChanges = true;
          }
        }),
        
        // Playback
        setPlaybackTime: (time) => set((state) => {
          state.playbackTime = time;
        }),
        
        setPlaybackRate: (rate) => set((state) => {
          state.playbackRate = rate;
        }),
        
        setIsPlaying: (playing) => set((state) => {
          state.isPlaying = playing;
        }),
        
        setVolume: (volume) => set((state) => {
          state.volume = volume;
        }),
        
        seekTo: (time) => set((state) => {
          state.playbackTime = Math.max(0, Math.min(time, state.videoDuration));
        }),
        
        skipForward: (seconds) => set((state) => {
          state.playbackTime = Math.min(state.playbackTime + seconds, state.videoDuration);
        }),
        
        skipBackward: (seconds) => set((state) => {
          state.playbackTime = Math.max(state.playbackTime - seconds, 0);
        }),
        
        // Tracks
        addTrack: (projectIdOrTrack, track) => set((state) => {
          if (!state.currentProject) return;
          
          // Handle backward compatibility
          const trackData = typeof projectIdOrTrack === 'string' ? track! : projectIdOrTrack;
          
          const newTrack: SubtitleTrack = {
            id: Date.now().toString(),
            name: trackData.name || 'New Track',
            language: trackData.language || 'en',
            segments: [],
            isVisible: trackData.isVisible !== undefined ? trackData.isVisible : true,
            isLocked: trackData.isLocked || false,
            style: trackData.style || {}
          };
          
          state.currentProject.tracks.push(newTrack);
          
          if (!state.currentProject.activeTrackId) {
            state.currentProject.activeTrackId = newTrack.id;
            state.activeTrackId = newTrack.id;
          }
          
          state.hasUnsavedChanges = true;
        }),
        
        updateTrack: (trackId, updates) => set((state) => {
          if (!state.currentProject) return;
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (track) {
            Object.assign(track, updates);
            state.hasUnsavedChanges = true;
          }
        }),
        
        deleteTrack: (trackId) => set((state) => {
          if (!state.currentProject) return;
          
          state.currentProject.tracks = state.currentProject.tracks.filter(t => t.id !== trackId);
          
          if (state.activeTrackId === trackId) {
            state.activeTrackId = state.currentProject.tracks[0]?.id || null;
            state.currentProject.activeTrackId = state.activeTrackId;
          }
          
          state.hasUnsavedChanges = true;
        }),
        
        setActiveTrack: (trackId) => set((state) => {
          state.activeTrackId = trackId;
          if (state.currentProject) {
            state.currentProject.activeTrackId = trackId;
            state.hasUnsavedChanges = true;
          }
        }),
        
        reorderTracks: (fromIndex, toIndex) => set((state) => {
          if (!state.currentProject) return;
          
          const tracks = [...state.currentProject.tracks];
          const [movedTrack] = tracks.splice(fromIndex, 1);
          tracks.splice(toIndex, 0, movedTrack);
          state.currentProject.tracks = tracks;
          state.hasUnsavedChanges = true;
        }),
        
        // Segments
        addSegments: (trackId: string, segmentsToAdd: SubtitleSegment[]) => set((state) => {
          if (!state.currentProject) return state;
          const trackIndex = state.currentProject.tracks.findIndex(t => t.id === trackId);
          if (trackIndex === -1) return state;
          const newTracks = [...state.currentProject.tracks];
          const track = {...newTracks[trackIndex]};
          track.segments = [...track.segments, ...segmentsToAdd];
          track.segments.sort((a, b) => a.startTime - b.startTime);
          newTracks[trackIndex] = track;
          return {
            ...state,
            currentProject: {
              ...state.currentProject,
              tracks: newTracks
            },
            hasUnsavedChanges: true
          };
        }),

        addSegment: (projectIdOrTrackId: string, trackIdOrSegment: string | Partial<SubtitleSegment>, segment?: Partial<SubtitleSegment>) => set((state) => {
          if (!state.currentProject) return;
          
          // Handle backward compatibility with multiple signatures
          let trackId: string;
          let segmentData: Partial<SubtitleSegment>;
          
          if (typeof trackIdOrSegment === 'string') {
            // Called with (projectId, trackId, segment)
            trackId = trackIdOrSegment;
            segmentData = segment!;
          } else {
            // Called with (trackId, segment)
            trackId = projectIdOrTrackId;
            segmentData = trackIdOrSegment;
          }
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (!track) return;
          
          const newSegment: SubtitleSegment = {
            id: Date.now().toString(),
            text: segmentData.text || '',
            startTime: segmentData.startTime || state.playbackTime,
            endTime: segmentData.endTime || state.playbackTime + 2,
            style: segmentData.style,
            confidence: segmentData.confidence
          };
          
          track.segments.push(newSegment);
          track.segments.sort((a, b) => a.startTime - b.startTime);
          
          state.hasUnsavedChanges = true;
        }),
        
        updateSegment: (projectIdOrTrackId: string, trackIdOrSegmentId: string, segmentIdOrUpdates: string | Partial<SubtitleSegment>, updates?: Partial<SubtitleSegment>) => set((state) => {
          if (!state.currentProject) return;
          
          // Handle backward compatibility
          let trackId: string;
          let segmentId: string;
          let segmentUpdates: Partial<SubtitleSegment>;
          
          if (typeof segmentIdOrUpdates === 'string') {
            // Called with (projectId, trackId, segmentId, updates)
            trackId = trackIdOrSegmentId;
            segmentId = segmentIdOrUpdates;
            segmentUpdates = updates!;
          } else {
            // Called with (trackId, segmentId, updates)
            trackId = projectIdOrTrackId;
            segmentId = trackIdOrSegmentId;
            segmentUpdates = segmentIdOrUpdates;
          }
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (!track) return;
          
          const segment = track.segments.find(s => s.id === segmentId);
          if (segment) {
            Object.assign(segment, segmentUpdates);
            
            // Re-sort if timing changed
            if ('startTime' in segmentUpdates || 'endTime' in segmentUpdates) {
              track.segments.sort((a, b) => a.startTime - b.startTime);
            }
            
            state.hasUnsavedChanges = true;
          }
        }),
        
        deleteSegment: (projectIdOrTrackId: string, trackIdOrSegmentId: string, segmentId?: string) => set((state) => {
          if (!state.currentProject) return;
          
          // Handle backward compatibility
          let trackId: string;
          let segmentIdToDelete: string;
          
          if (segmentId) {
            // Called with (projectId, trackId, segmentId)
            trackId = trackIdOrSegmentId;
            segmentIdToDelete = segmentId;
          } else {
            // Called with (trackId, segmentId)
            trackId = projectIdOrTrackId;
            segmentIdToDelete = trackIdOrSegmentId;
          }
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (!track) return;
          
          track.segments = track.segments.filter(s => s.id !== segmentIdToDelete);
          state.selectedSegmentIds = state.selectedSegmentIds.filter(id => id !== segmentIdToDelete);
          state.selectedSegmentId = state.selectedSegmentId === segmentIdToDelete ? null : state.selectedSegmentId;
          state.hasUnsavedChanges = true;
        }),
        
        deleteSelectedSegments: () => set((state) => {
          if (!state.currentProject) return;
          
          const selectedIds = new Set(state.selectedSegmentIds);
          
          state.currentProject.tracks.forEach(track => {
            track.segments = track.segments.filter(s => !selectedIds.has(s.id));
          });
          
          state.selectedSegmentIds = [];
          state.hasUnsavedChanges = true;
        }),
        
        // Selection
        selectSegment: (segmentId, multi = false) => set((state) => {
          if (multi) {
            if (state.selectedSegmentIds.includes(segmentId)) {
              state.selectedSegmentIds = state.selectedSegmentIds.filter(id => id !== segmentId);
            } else {
              state.selectedSegmentIds.push(segmentId);
            }
          } else {
            state.selectedSegmentIds = [segmentId];
          }
          state.selectedSegmentId = segmentId;
        }),
        
        selectAllSegments: () => set((state) => {
          if (!state.currentProject) return;
          
          const allSegmentIds: string[] = [];
          state.currentProject.tracks.forEach(track => {
            track.segments.forEach(segment => {
              allSegmentIds.push(segment.id);
            });
          });
          
          state.selectedSegmentIds = allSegmentIds;
        }),
        
        clearSelection: () => set((state) => {
          state.selectedSegmentIds = [];
        }),
        
        selectSegmentsInRange: (startTime, endTime) => set((state) => {
          if (!state.currentProject) return;
          
          const segmentIds: string[] = [];
          state.currentProject.tracks.forEach(track => {
            track.segments.forEach(segment => {
              if (segment.startTime >= startTime && segment.endTime <= endTime) {
                segmentIds.push(segment.id);
              }
            });
          });
          
          state.selectedSegmentIds = segmentIds;
        }),
        
        // Segment Operations
        splitSegment: (segmentIdOrTrackId, ratioOrSegmentId, time) => set((state) => {
          if (!state.currentProject) return;
          
          let trackId: string;
          let segmentId: string;
          let splitTime: number;
          
          if (typeof ratioOrSegmentId === 'number') {
            // Called with (segmentId, ratio)
            segmentId = segmentIdOrTrackId;
            const allSegments = state.currentProject.tracks.flatMap(t => t.segments);
            const segment = allSegments.find(s => s.id === segmentId);
            if (!segment) return;
            
            splitTime = segment.startTime + (segment.endTime - segment.startTime) * ratioOrSegmentId;
            const track = state.currentProject.tracks.find(t => t.segments.includes(segment));
            if (!track) return;
            trackId = track.id;
          } else if (time !== undefined) {
            // Called with (trackId, segmentId, time)
            trackId = segmentIdOrTrackId;
            segmentId = ratioOrSegmentId;
            splitTime = time;
          } else {
            return;
          }
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (!track) return;
          
          const segmentIndex = track.segments.findIndex(s => s.id === segmentId);
          const segment = track.segments[segmentIndex];
          if (!segment || splitTime <= segment.startTime || splitTime >= segment.endTime) return;
          
          const newSegment: SubtitleSegment = {
            id: Date.now().toString(),
            text: segment.text,
            startTime: splitTime,
            endTime: segment.endTime,
            style: segment.style,
            confidence: segment.confidence
          };
          
          segment.endTime = splitTime;
          track.segments.splice(segmentIndex + 1, 0, newSegment);
          
          state.hasUnsavedChanges = true;
        }),
        
        mergeSegments: (segmentIdsOrTrackId, segmentIds) => set((state) => {
          if (!state.currentProject) return;
          
          let trackId: string;
          let segmentIdsToMerge: string[];
          
          if (Array.isArray(segmentIdsOrTrackId)) {
            // Called with (segmentIds)
            segmentIdsToMerge = segmentIdsOrTrackId;
            // Find track containing these segments
            const track = state.currentProject.tracks.find(t => 
              segmentIdsToMerge.some(id => t.segments.some(s => s.id === id))
            );
            if (!track) return;
            trackId = track.id;
          } else {
            // Called with (trackId, segmentIds)
            trackId = segmentIdsOrTrackId;
            segmentIdsToMerge = segmentIds!;
          }
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (!track || segmentIdsToMerge.length < 2) return;
          
          const segments = track.segments.filter(s => segmentIdsToMerge.includes(s.id));
          if (segments.length < 2) return;
          
          segments.sort((a, b) => a.startTime - b.startTime);
          
          const mergedSegment: SubtitleSegment = {
            id: segments[0].id,
            text: segments.map(s => s.text).join(' '),
            startTime: segments[0].startTime,
            endTime: segments[segments.length - 1].endTime,
            style: segments[0].style,
            confidence: segments.reduce((sum, s) => sum + (s.confidence || 0), 0) / segments.length
          };
          
          // Remove all segments except the first
          track.segments = track.segments.filter(s => !segmentIdsToMerge.includes(s.id) || s.id === mergedSegment.id);
          
          // Update the first segment
          const index = track.segments.findIndex(s => s.id === mergedSegment.id);
          track.segments[index] = mergedSegment;
          
          state.selectedSegmentIds = [mergedSegment.id];
          state.selectedSegmentId = mergedSegment.id;
          state.hasUnsavedChanges = true;
        }),
        
        shiftSegments: (trackId, segmentIds, deltaTime) => set((state) => {
          if (!state.currentProject) return;
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (!track) return;
          
          const segmentIdSet = new Set(segmentIds);
          track.segments.forEach(segment => {
            if (segmentIdSet.has(segment.id)) {
              segment.startTime = Math.max(0, segment.startTime + deltaTime);
              segment.endTime = Math.max(segment.startTime + 0.1, segment.endTime + deltaTime);
            }
          });
          
          track.segments.sort((a, b) => a.startTime - b.startTime);
          state.hasUnsavedChanges = true;
        }),
        
        alignSegments: (trackId, segmentIds, alignment) => set((state) => {
          if (!state.currentProject || segmentIds.length < 2) return;
          
          const track = state.currentProject.tracks.find(t => t.id === trackId);
          if (!track) return;
          
          const segments = track.segments.filter(s => segmentIds.includes(s.id));
          if (segments.length < 2) return;
          
          segments.sort((a, b) => a.startTime - b.startTime);
          
          let referenceTime: number;
          switch (alignment) {
            case 'start':
              referenceTime = segments[0].startTime;
              segments.forEach(segment => {
                const duration = segment.endTime - segment.startTime;
                segment.startTime = referenceTime;
                segment.endTime = referenceTime + duration;
              });
              break;
            case 'end':
              referenceTime = segments[segments.length - 1].endTime;
              segments.forEach(segment => {
                const duration = segment.endTime - segment.startTime;
                segment.endTime = referenceTime;
                segment.startTime = referenceTime - duration;
              });
              break;
            case 'center':
              const firstCenter = (segments[0].startTime + segments[0].endTime) / 2;
              segments.forEach(segment => {
                const duration = segment.endTime - segment.startTime;
                const currentCenter = (segment.startTime + segment.endTime) / 2;
                const offset = firstCenter - currentCenter;
                segment.startTime += offset;
                segment.endTime += offset;
              });
              break;
          }
          
          state.hasUnsavedChanges = true;
        }),
        
        // UI
        setZoomLevel: (level) => set((state) => {
          state.zoomLevel = Math.max(0.1, Math.min(10, level));
        }),
        
        setScrollPosition: (position) => set((state) => {
          state.scrollPosition = position;
        }),
        
        toggleWaveform: () => set((state) => {
          state.showWaveform = !state.showWaveform;
        }),
        
        toggleTimestamps: () => set((state) => {
          state.showTimestamps = !state.showTimestamps;
        }),
        
        toggleSnapToGrid: () => set((state) => {
          state.snapToGrid = !state.snapToGrid;
        }),
        
        setGridSize: (size) => set((state) => {
          state.gridSize = size;
        }),
        
        // Transcription
        setIsTranscribing: (transcribing) => set((state) => {
          state.isTranscribing = transcribing;
        }),
        
        setSelectedModel: (model) => set((state) => {
          state.selectedModel = model;
        }),
        
        setTranscriptionLanguage: (language) => set((state) => {
          state.transcriptionLanguage = language;
        }),
        
        // Styling
        setFontSize: (size) => set((state) => {
          state.fontSize = size;
          state.hasUnsavedChanges = true;
        }),
        
        setFontFamily: (family) => set((state) => {
          state.fontFamily = family;
          state.hasUnsavedChanges = true;
        }),
        
        setFontColor: (color) => set((state) => {
          state.fontColor = color;
          state.hasUnsavedChanges = true;
        }),
        
        setBackgroundColor: (color) => set((state) => {
          state.backgroundColor = color;
          state.hasUnsavedChanges = true;
        }),
        
        setBackgroundOpacity: (opacity) => set((state) => {
          state.backgroundOpacity = opacity;
          state.hasUnsavedChanges = true;
        }),
        
        setTextShadow: (shadow) => set((state) => {
          state.textShadow = shadow;
          state.hasUnsavedChanges = true;
        }),
        
        setTextStroke: (stroke) => set((state) => {
          state.textStroke = stroke;
          state.hasUnsavedChanges = true;
        }),
        
        setPadding: (padding) => set((state) => {
          state.padding = padding;
          state.hasUnsavedChanges = true;
        }),
        
        setBorderRadius: (radius) => set((state) => {
          state.borderRadius = radius;
          state.hasUnsavedChanges = true;
        }),
        
        setPosition: (position) => set((state) => {
          state.position = position;
          state.hasUnsavedChanges = true;
        }),
        
        setAlignment: (alignment) => set((state) => {
          state.alignment = alignment;
          state.hasUnsavedChanges = true;
        }),
        
        applyStyleToSelected: (style) => set((state) => {
          if (!state.currentProject || state.selectedSegmentIds.length === 0) return;
          
          const selectedIds = new Set(state.selectedSegmentIds);
          
          state.currentProject.tracks.forEach(track => {
            track.segments.forEach(segment => {
              if (selectedIds.has(segment.id)) {
                segment.style = { ...segment.style, ...style };
              }
            });
          });
          
          state.hasUnsavedChanges = true;
        }),
        
        updateStyle: (style) => set((state) => {
          Object.assign(state, style);
          state.subtitleStyle = {
            fontSize: state.fontSize,
            fontFamily: state.fontFamily,
            fontColor: state.fontColor,
            backgroundColor: state.backgroundColor,
            backgroundOpacity: state.backgroundOpacity,
            textShadow: state.textShadow,
            textStroke: state.textStroke,
            padding: state.padding,
            borderRadius: state.borderRadius,
            position: state.position,
            alignment: state.alignment
          };
          if (state.currentProject) {
            state.currentProject.style = { ...state.subtitleStyle };
            state.hasUnsavedChanges = true;
          }
        }),

        setSubtitleStyle: (style) => set((state) => {
          Object.assign(state, style);
          state.subtitleStyle = {
            fontSize: state.fontSize,
            fontFamily: state.fontFamily,
            fontColor: state.fontColor,
            backgroundColor: state.backgroundColor,
            backgroundOpacity: state.backgroundOpacity,
            textShadow: state.textShadow,
            textStroke: state.textStroke,
            padding: state.padding,
            borderRadius: state.borderRadius,
            position: state.position,
            alignment: state.alignment
          };
          if (state.currentProject) {
            state.currentProject.style = { ...state.subtitleStyle };
            state.hasUnsavedChanges = true;
          }
        }),
        
        // History
        undo: () => set((state) => {
          if (state.historyIndex > 0) {
            state.historyIndex--;
            // Apply state from history[historyIndex]
          }
        }),
        
        redo: () => set((state) => {
          if (state.historyIndex < state.history.length - 1) {
            state.historyIndex++;
            // Apply state from history[historyIndex]
          }
        }),
        
        clearHistory: () => set((state) => {
          state.history = [];
          state.historyIndex = -1;
        }),
        
        // Import/Export
        importSegments: (segments) => set((state) => {
          if (!state.currentProject || !state.activeTrackId) return;
          
          const track = state.currentProject.tracks.find(t => t.id === state.activeTrackId);
          if (!track) return;
          
          segments.forEach(segment => {
            segment.id = Date.now().toString() + Math.random();
          });
          
          track.segments.push(...segments);
            track.segments.sort((a, b) => a.startTime - b.startTime);
          
          state.hasUnsavedChanges = true;
        }),
        
        exportSegments: (format) => {
          const state = get();
          if (!state.currentProject || !state.activeTrackId) return '';
          
          const track = state.currentProject.tracks.find(t => t.id === state.activeTrackId);
          if (!track) return '';
          
          // This would call the appropriate export function from subtitle-utils
          return '';
        },
        
        // Auto-save
        setAutoSaveEnabled: (enabled) => set((state) => {
          state.autoSaveEnabled = enabled;
        }),
        
        setAutoSaveInterval: (interval) => set((state) => {
          state.autoSaveInterval = interval;
        }),
        
        markAsUnsaved: () => set((state) => {
          state.hasUnsavedChanges = true;
        }),
        
        markAsSaved: () => set((state) => {
          state.hasUnsavedChanges = false;
          state.lastSaved = new Date();
        }),
        
        // Computed getters
        getSegmentsInTimeRange: (startTime: number, endTime: number) => {
          const state = get();
          if (!state.currentProject || !state.activeTrackId) return [];
          const track = state.currentProject.tracks.find(t => t.id === state.activeTrackId);
          const segments = track?.segments || [];
          return segments.filter(
            segment => segment.startTime < endTime && segment.endTime > startTime
          );
        },
        
        getSegmentById: (segmentId: string) => {
          const state = get();
          if (!state.currentProject || !state.activeTrackId) return undefined;
          const track = state.currentProject.tracks.find(t => t.id === state.activeTrackId);
          const segments = track?.segments || [];
          return segments.find(segment => segment.id === segmentId);
        }
      })),
      {
        name: 'subtitle-store',
        partialize: (state) => ({
          projects: state.projects,
          currentProjectId: state.currentProjectId,
          selectedModel: state.selectedModel,
          transcriptionLanguage: state.transcriptionLanguage,
          subtitleStyle: state.subtitleStyle,
          autoSaveEnabled: state.autoSaveEnabled,
          autoSaveInterval: state.autoSaveInterval,
        }),
      }
    )
  )
); 