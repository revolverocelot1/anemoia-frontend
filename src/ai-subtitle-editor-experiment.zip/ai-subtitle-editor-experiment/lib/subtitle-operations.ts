import type { SubtitleSegment } from '../types/subtitle';

/**
 * Split a subtitle segment at a specific time or ratio
 */
export function splitSegment(
  segment: SubtitleSegment,
  splitPoint: number | { ratio: number }
): [SubtitleSegment, SubtitleSegment] {
  const splitTime = typeof splitPoint === 'number' 
    ? splitPoint 
    : segment.startTime + (segment.endTime - segment.startTime) * splitPoint.ratio;
  
  // Ensure split time is within segment bounds
  const actualSplitTime = Math.max(
    segment.startTime + 0.1,
    Math.min(segment.endTime - 0.1, splitTime)
  );
  
  // Split text at approximate position
  const duration = segment.endTime - segment.startTime;
  const splitRatio = (actualSplitTime - segment.startTime) / duration;
  const words = segment.text.split(' ');
  const splitIndex = Math.round(words.length * splitRatio);
  
  const firstText = words.slice(0, splitIndex).join(' ');
  const secondText = words.slice(splitIndex).join(' ');
  
  return [
    {
      ...segment,
      id: `${segment.id}-1`,
      endTime: actualSplitTime,
      text: firstText || segment.text
    },
    {
      ...segment,
      id: `${segment.id}-2`,
      startTime: actualSplitTime,
      text: secondText || segment.text
    }
  ];
}

/**
 * Merge multiple segments into one
 */
export function mergeSegments(segments: SubtitleSegment[]): SubtitleSegment | null {
  if (segments.length === 0) return null;
  if (segments.length === 1) return segments[0];
  
  const sorted = [...segments].sort((a, b) => a.startTime - b.startTime);
  const mergedText = sorted.map(s => s.text).join(' ');
  
  return {
    id: `merged-${Date.now()}`,
    startTime: sorted[0].startTime,
    endTime: sorted[sorted.length - 1].endTime,
    text: mergedText,
    confidence: sorted.reduce((sum, s) => sum + (s.confidence || 1), 0) / sorted.length,
    speaker: sorted[0].speaker
  };
}

/**
 * Shift segments by a time offset
 */
export function shiftSegments(
  segments: SubtitleSegment[],
  offset: number
): SubtitleSegment[] {
  return segments.map(segment => ({
    ...segment,
    startTime: Math.max(0, segment.startTime + offset),
    endTime: Math.max(0, segment.endTime + offset)
  }));
}

/**
 * Scale segment durations
 */
export function scaleSegments(
  segments: SubtitleSegment[],
  factor: number,
  anchor: 'start' | 'center' | 'end' = 'start'
): SubtitleSegment[] {
  return segments.map(segment => {
    const duration = segment.endTime - segment.startTime;
    const newDuration = duration * factor;
    
    switch (anchor) {
      case 'start':
        return {
          ...segment,
          endTime: segment.startTime + newDuration
        };
      case 'end':
        return {
          ...segment,
          startTime: segment.endTime - newDuration
        };
      case 'center':
        const center = (segment.startTime + segment.endTime) / 2;
        return {
          ...segment,
          startTime: center - newDuration / 2,
          endTime: center + newDuration / 2
        };
    }
  });
}

/**
 * Fix overlapping segments
 */
export function fixOverlaps(
  segments: SubtitleSegment[],
  minGap: number = 0.1
): SubtitleSegment[] {
  const sorted = [...segments].sort((a, b) => a.startTime - b.startTime);
  const fixed: SubtitleSegment[] = [];
  
  for (let i = 0; i < sorted.length; i++) {
    const current = { ...sorted[i] };
    
    if (i > 0) {
      const previous = fixed[i - 1];
      if (current.startTime < previous.endTime) {
        // Fix overlap
        current.startTime = previous.endTime + minGap;
        if (current.endTime <= current.startTime) {
          current.endTime = current.startTime + 0.5; // Minimum duration
        }
      }
    }
    
    fixed.push(current);
  }
  
  return fixed;
}

/**
 * Distribute segments evenly over a time range
 */
export function distributeSegments(
  segments: SubtitleSegment[],
  startTime: number,
  endTime: number,
  gap: number = 0.1
): SubtitleSegment[] {
  if (segments.length === 0) return [];
  
  const totalDuration = endTime - startTime;
  const totalGaps = gap * (segments.length - 1);
  const availableDuration = totalDuration - totalGaps;
  const segmentDuration = availableDuration / segments.length;
  
  return segments.map((segment, index) => ({
    ...segment,
    startTime: startTime + index * (segmentDuration + gap),
    endTime: startTime + index * (segmentDuration + gap) + segmentDuration
  }));
}

/**
 * Snap segments to nearest frame boundary
 */
export function snapToFrames(
  segments: SubtitleSegment[],
  frameRate: number = 30
): SubtitleSegment[] {
  const frameDuration = 1 / frameRate;
  
  return segments.map(segment => ({
    ...segment,
    startTime: Math.round(segment.startTime / frameDuration) * frameDuration,
    endTime: Math.round(segment.endTime / frameDuration) * frameDuration
  }));
}

/**
 * Auto-fix common subtitle issues
 */
export function autoFixSegments(
  segments: SubtitleSegment[],
  options: {
    minDuration?: number;
    maxDuration?: number;
    minGap?: number;
    maxCharsPerLine?: number;
    maxLines?: number;
  } = {}
): SubtitleSegment[] {
  const {
    minDuration = 0.5,
    maxDuration = 7,
    minGap = 0.1,
    maxCharsPerLine = 42,
    maxLines = 2
  } = options;
  
  let fixed = [...segments];
  
  // Fix durations
  fixed = fixed.map(segment => {
    const duration = segment.endTime - segment.startTime;
    if (duration < minDuration) {
      return { ...segment, endTime: segment.startTime + minDuration };
    }
    if (duration > maxDuration) {
      return { ...segment, endTime: segment.startTime + maxDuration };
    }
    return segment;
  });
  
  // Fix overlaps
  fixed = fixOverlaps(fixed, minGap);
  
  // Fix text formatting
  fixed = fixed.map(segment => ({
    ...segment,
    text: formatSubtitleText(segment.text, maxCharsPerLine, maxLines)
  }));
  
  return fixed;
}

/**
 * Format subtitle text for display
 */
export function formatSubtitleText(
  text: string,
  maxCharsPerLine: number = 42,
  maxLines: number = 2
): string {
  const words = text.split(' ');
  const lines: string[] = [];
  let currentLine = '';
  
  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    
    if (testLine.length <= maxCharsPerLine) {
      currentLine = testLine;
    } else {
      if (currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        // Word is too long, force break
        lines.push(word.substring(0, maxCharsPerLine));
        currentLine = word.substring(maxCharsPerLine);
      }
    }
    
    if (lines.length >= maxLines - 1 && currentLine) {
      // Reached max lines, add remaining text to last line
      lines.push(currentLine + ' ' + words.slice(words.indexOf(word) + 1).join(' '));
      break;
    }
  }
  
  if (currentLine && lines.length < maxLines) {
    lines.push(currentLine);
  }
  
  return lines.slice(0, maxLines).join('\n');
}

/**
 * Calculate reading speed for segments
 */
export function calculateReadingSpeed(segment: SubtitleSegment): {
  wordsPerMinute: number;
  charactersPerSecond: number;
  isOptimal: boolean;
} {
  const duration = segment.endTime - segment.startTime;
  const words = segment.text.split(/\s+/).filter(w => w.length > 0).length;
  const characters = segment.text.length;
  
  const wordsPerMinute = (words / duration) * 60;
  const charactersPerSecond = characters / duration;
  
  // Optimal reading speed is 150-180 WPM or 15-20 CPS
  const isOptimal = wordsPerMinute >= 150 && wordsPerMinute <= 180 &&
                   charactersPerSecond >= 15 && charactersPerSecond <= 20;
  
  return {
    wordsPerMinute,
    charactersPerSecond,
    isOptimal
  };
}

/**
 * Adjust segment timing based on reading speed
 */
export function adjustTimingForReadingSpeed(
  segment: SubtitleSegment,
  targetCPS: number = 17
): SubtitleSegment {
  const characters = segment.text.length;
  const optimalDuration = characters / targetCPS;
  const currentDuration = segment.endTime - segment.startTime;
  
  if (Math.abs(currentDuration - optimalDuration) < 0.1) {
    return segment; // Already optimal
  }
  
  // Adjust end time to achieve target reading speed
  return {
    ...segment,
    endTime: segment.startTime + optimalDuration
  };
}

/**
 * Group segments by speaker
 */
export function groupSegmentsBySpeaker(
  segments: SubtitleSegment[]
): Map<string, SubtitleSegment[]> {
  const groups = new Map<string, SubtitleSegment[]>();
  
  segments.forEach(segment => {
    const speaker = segment.speaker || 'Unknown';
    if (!groups.has(speaker)) {
      groups.set(speaker, []);
    }
    groups.get(speaker)!.push(segment);
  });
  
  return groups;
}

/**
 * Find gaps between segments
 */
export function findGaps(
  segments: SubtitleSegment[],
  minGapDuration: number = 1
): Array<{ startTime: number; endTime: number; duration: number }> {
  const sorted = [...segments].sort((a, b) => a.startTime - b.startTime);
  const gaps: Array<{ startTime: number; endTime: number; duration: number }> = [];
  
  for (let i = 1; i < sorted.length; i++) {
    const gapStart = sorted[i - 1].endTime;
    const gapEnd = sorted[i].startTime;
    const duration = gapEnd - gapStart;
    
    if (duration >= minGapDuration) {
      gaps.push({
        startTime: gapStart,
        endTime: gapEnd,
        duration
      });
    }
  }
  
  return gaps;
} 