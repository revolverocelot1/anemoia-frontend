import { v4 as uuidv4 } from 'uuid';
import type { SubtitleSegment, SubtitleStyle } from '../types/subtitle';
import { DEFAULT_SUBTITLE_STYLE } from '../types/subtitle';

/**
 * Generate subtitle template based on video duration
 */
export function generateSubtitleTemplate(
  duration: number,
  options: {
    segmentDuration?: number;
    overlap?: number;
    minSegmentDuration?: number;
  } = {}
): SubtitleSegment[] {
  const {
    segmentDuration = 5, // 5 seconds per segment
    overlap = 0.1, // 100ms overlap
    minSegmentDuration = 1 // Minimum 1 second
  } = options;

  const segments: SubtitleSegment[] = [];
  let currentTime = 0;

  while (currentTime < duration) {
    const remainingTime = duration - currentTime;
    const actualDuration = Math.max(
      minSegmentDuration,
      Math.min(segmentDuration, remainingTime)
    );

    segments.push({
      id: uuidv4(),
      text: '',
      startTime: currentTime,
      endTime: Math.min(duration, currentTime + actualDuration),
      confidence: 1
    });

    currentTime += actualDuration - overlap;
  }

  return segments;
}

/**
 * Create subtitle at specific time
 */
export function createSubtitleAtTime(
  time: number,
  duration: number = 2,
  text: string = ''
): SubtitleSegment {
  return {
    id: uuidv4(),
    text,
    startTime: time,
    endTime: time + duration,
    confidence: 1
  };
}

/**
 * Export subtitles to SRT format
 */
export function exportToSRT(segments: SubtitleSegment[]): string {
  const sortedSegments = [...segments].sort((a, b) => a.startTime - b.startTime);
  
  return sortedSegments
    .map((segment, index) => {
      const startTime = formatSRTTime(segment.startTime);
      const endTime = formatSRTTime(segment.endTime);
      const text = stripHTML(segment.text);
      
      return `${index + 1}\n${startTime} --> ${endTime}\n${text}\n`;
    })
    .join('\n');
}

/**
 * Export subtitles to WebVTT format
 */
export function exportToWebVTT(segments: SubtitleSegment[], style?: SubtitleStyle): string {
  const sortedSegments = [...segments].sort((a, b) => a.startTime - b.startTime);
  
  let vtt = 'WEBVTT\n\n';
  
  // Add style if provided
  if (style) {
    vtt += 'STYLE\n';
    vtt += '::cue {\n';
    vtt += `  font-family: ${style.fontFamily};\n`;
    vtt += `  font-size: ${style.fontSize}px;\n`;
    vtt += `  color: ${style.fontColor};\n`;
    if (style.backgroundColor) {
      vtt += `  background-color: ${style.backgroundColor};\n`;
    }
    vtt += '}\n\n';
  }
  
  // Add cues
  sortedSegments.forEach((segment) => {
    const startTime = formatWebVTTTime(segment.startTime);
    const endTime = formatWebVTTTime(segment.endTime);
    
    vtt += `${startTime} --> ${endTime}\n`;
    vtt += segment.text + '\n\n';
  });
  
  return vtt;
}

/**
 * Import subtitles from SRT format
 */
export function importFromSRT(content: string): SubtitleSegment[] {
  const segments: SubtitleSegment[] = [];
  const blocks = content.trim().split(/\n\s*\n/);
  
  blocks.forEach(block => {
    const lines = block.trim().split('\n');
    if (lines.length >= 3) {
      const timeMatch = lines[1].match(/(\d{2}:\d{2}:\d{2},\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2},\d{3})/);
      
      if (timeMatch) {
        const startTime = parseSRTTime(timeMatch[1]);
        const endTime = parseSRTTime(timeMatch[2]);
        const text = lines.slice(2).join('\n');
        
        segments.push({
          id: `imported-${Date.now()}-${segments.length}`,
          startTime,
          endTime,
          text: text.trim()
        });
      }
    }
  });
  
  return segments;
}

/**
 * Import subtitles from WebVTT format
 */
export function importFromWebVTT(content: string): SubtitleSegment[] {
  const segments: SubtitleSegment[] = [];
  const lines = content.split('\n');
  let i = 0;
  
  // Skip header
  while (i < lines.length && !lines[i].includes('-->')) {
    i++;
  }
  
  // Parse cues
  while (i < lines.length) {
    if (lines[i].includes('-->')) {
      const timeMatch = lines[i].match(/(\d{2}:\d{2}:\d{2}\.\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}\.\d{3})/);
      if (timeMatch) {
        const startTime = parseWebVTTTime(timeMatch[1]);
        const endTime = parseWebVTTTime(timeMatch[2]);
        
        const textLines: string[] = [];
        i++;
        while (i < lines.length && lines[i].trim() !== '') {
          textLines.push(lines[i].trim());
          i++;
        }
        
        segments.push({
          id: `imported-${Date.now()}-${segments.length}`,
          startTime,
          endTime,
          text: textLines.join('\n')
        });
      }
    }
    i++;
  }
  
  return segments;
}

// Helper functions
function formatSRTTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const millis = Math.floor((seconds % 1) * 1000);
  
  return `${pad(hours)}:${pad(minutes)}:${pad(secs)},${pad(millis, 3)}`;
}

function formatWebVTTTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const millis = Math.floor((seconds % 1) * 1000);
  
  return `${pad(hours)}:${pad(minutes)}:${pad(secs)}.${pad(millis, 3)}`;
}

function parseSRTTime(time: string): number {
  const parts = time.split(/[:,]/);
  return parseInt(parts[0]) * 3600 + parseInt(parts[1]) * 60 + parseInt(parts[2]) + parseInt(parts[3]) / 1000;
}

function parseWebVTTTime(time: string): number {
  const parts = time.split(/[:\.]/);
  return parseInt(parts[0]) * 3600 + parseInt(parts[1]) * 60 + parseInt(parts[2]) + parseInt(parts[3]) / 1000;
}

function pad(num: number, size: number = 2): string {
  return num.toString().padStart(size, '0');
}

function stripHTML(text: string): string {
  return text.replace(/<[^>]*>/g, '');
}

/**
 * Validate subtitle segments
 */
export function validateSegments(segments: SubtitleSegment[]): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];
  
  segments.forEach((segment, index) => {
    if (segment.startTime >= segment.endTime) {
      errors.push(`Segment ${index + 1}: Start time must be before end time`);
    }
    
    if (segment.startTime < 0) {
      errors.push(`Segment ${index + 1}: Start time cannot be negative`);
    }
    
    if (!segment.text.trim()) {
      errors.push(`Segment ${index + 1}: Text cannot be empty`);
    }
  });
  
  // Check for overlaps
  const sortedSegments = [...segments].sort((a, b) => a.startTime - b.startTime);
  for (let i = 0; i < sortedSegments.length - 1; i++) {
    if (sortedSegments[i].endTime > sortedSegments[i + 1].startTime) {
      errors.push(
        `Overlap detected between segments ${i + 1} and ${i + 2}`
      );
    }
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Format time for display
 */
export function formatTime(seconds: number): string {
  if (!isFinite(seconds) || seconds < 0) return '00:00';
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Auto-fix common subtitle issues
 */
export function autoFixSegments(segments: SubtitleSegment[]): SubtitleSegment[] {
  const fixed = [...segments];
  
  // Sort by start time
  fixed.sort((a, b) => a.startTime - b.startTime);
  
  // Fix overlaps
  for (let i = 0; i < fixed.length - 1; i++) {
    if (fixed[i].endTime > fixed[i + 1].startTime) {
      fixed[i].endTime = fixed[i + 1].startTime - 0.01;
    }
  }
  
  // Fix negative times
  fixed.forEach(segment => {
    if (segment.startTime < 0) segment.startTime = 0;
    if (segment.endTime < segment.startTime) {
      segment.endTime = segment.startTime + 1;
    }
  });
  
  return fixed;
} 

/**
 * Export subtitles to ASS format with styling
 */
export function exportToASS(segments: SubtitleSegment[], globalStyle: Partial<SubtitleStyle> = {}): string {
  let ass = '[Script Info]\n';
  ass += 'Title: Generated Subtitles\n';
  ass += 'ScriptType: v4.00+\n';
  ass += 'PlayResX: 1920\n';
  ass += 'PlayResY: 1080\n\n';

  // Styles section
  ass += '[V4+ Styles]\n';
  ass += 'Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n';

  // Create unique styles for different style combinations
  const styleMap = new Map<string, string>();
  let styleCount = 0;

  // Default style
  const defaultStyle = {
    ...DEFAULT_SUBTITLE_STYLE,
    ...globalStyle
  };

  // Function to get style name for a segment
  const getStyleName = (segmentStyle: Partial<SubtitleStyle> = {}) => {
    const merged = { ...defaultStyle, ...segmentStyle };
    const key = JSON.stringify(merged);

    if (!styleMap.has(key)) {
      const styleName = `Style${styleCount++}`;
      styleMap.set(key, styleName);

      // Convert colors to ASS format (&HBBGGRR&)
      const convertColor = (color: string) => {
        if (color.startsWith('#')) {
          const hex = color.slice(1);
          return `&H${hex[4]}${hex[5]}${hex[2]}${hex[3]}${hex[0]}${hex[1]}&`;
        }
        return '&H000000&'; // default black
      };

      const primaryColor = convertColor(merged.fontColor || '#FFFFFF');
      const backColor = convertColor(merged.backgroundColor || '#000000');
      const outlineColor = merged.textStroke ? convertColor(merged.textStroke.split(' ')[1]) : '&H000000&';

      // Alignment: 1=left bottom, 2=center bottom, 3=right bottom, etc.
      let alignment = 2; // center bottom
      switch (merged.alignment) {
        case 'left': alignment = merged.position?.includes('top') ? 7 : merged.position?.includes('middle') ? 4 : 1; break;
        case 'center': alignment = merged.position?.includes('top') ? 8 : merged.position?.includes('middle') ? 5 : 2; break;
        case 'right': alignment = merged.position?.includes('top') ? 9 : merged.position?.includes('middle') ? 6 : 3; break;
      }

      ass += `${styleName},${merged.fontFamily || 'Arial'},${merged.fontSize || 24},${primaryColor},&H000000FF&,&H000000&,&H000000&},${merged.fontWeight === 'bold' ? -1 : 0},${merged.fontStyle === 'italic' ? -1 : 0},0,0,100,100,${merged.letterSpacing || 0},0,1,${merged.padding || 2},${merged.textShadow ? 2 : 0},${alignment},10,10,10,1\n`;
    }

    return styleMap.get(key)!;
  };

  // Default style
  getStyleName(); // Ensure at least one style

  ass += '\n[Events]\n';
  ass += 'Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n';

  // Sort segments
  const sortedSegments = [...segments].sort((a, b) => a.startTime - b.startTime);

  sortedSegments.forEach((segment) => {
    const start = formatASSTime(segment.startTime);
    const end = formatASSTime(segment.endTime);
    const styleName = getStyleName(segment.style);
    const text = segment.text.replace(/\n/g, '\\N');

    ass += `Dialogue: 0,${start},${end},${styleName},,0,0,0,,${text}\n`;
  });

  return ass;
}

/**
 * Format time for ASS (hh:mm:ss.cs)
 */
function formatASSTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const centis = Math.floor((seconds % 1) * 100);

  return `${hours}:${pad(minutes)}:${pad(secs)}.${pad(centis)}`;
} 