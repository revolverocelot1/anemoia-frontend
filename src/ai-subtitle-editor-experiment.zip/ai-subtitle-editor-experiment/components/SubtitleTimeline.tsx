import React, { useRef, useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { useSubtitleStore } from '../../stores/subtitle-store';
import type { SubtitleSegment } from '../../types/subtitle';
import { formatTime } from '../../lib/subtitle-utils';
import { ZoomIn, ZoomOut, Maximize, Grid3X3, Layers, Lock, Unlock, Eye, EyeOff } from 'lucide-react';

interface SubtitleTimelineProps {
  segments: SubtitleSegment[];
  duration: number;
  currentTime: number;
  onTimeChange: (time: number) => void;
  onSegmentClick: (id: string) => void;
  activeSegmentId?: string | null;
  className?: string;
}

export const SubtitleTimeline: React.FC<SubtitleTimelineProps> = ({
  segments,
  duration,
  currentTime,
  onTimeChange,
  onSegmentClick,
  activeSegmentId,
  className = ''
}) => {
  const timelineRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [timelineWidth, setTimelineWidth] = useState(0);
  const [hoveredSegment, setHoveredSegment] = useState<string | null>(null);
  const [hoveredTime, setHoveredTime] = useState<number | null>(null);
  const [isDraggingPlayhead, setIsDraggingPlayhead] = useState(false);
  const [isDraggingSegment, setIsDraggingSegment] = useState<{
    segmentId: string;
    edge: 'start' | 'end' | 'both';
    initialX: number;
    initialStartTime: number;
    initialEndTime: number;
  } | null>(null);
  
  const {
    zoomLevel,
    setZoomLevel,
    scrollPosition,
    setScrollPosition,
    showWaveform,
    toggleWaveform,
    showTimestamps,
    toggleTimestamps,
    snapToGrid,
    toggleSnapToGrid,
    gridSize,
    selectedSegmentIds,
    updateSegment,
    currentProject
  } = useSubtitleStore();
  
  // Calculate timeline dimensions
  useEffect(() => {
    const updateDimensions = () => {
      if (timelineRef.current) {
        setTimelineWidth(timelineRef.current.clientWidth);
      }
    };
    
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    
    const resizeObserver = new ResizeObserver(updateDimensions);
    if (timelineRef.current) {
      resizeObserver.observe(timelineRef.current);
    }
    
    return () => {
      window.removeEventListener('resize', updateDimensions);
      resizeObserver.disconnect();
    };
  }, []);
  
  // Time conversion helpers
  const timeToPixel = useCallback((time: number) => {
    return (time / duration) * timelineWidth * zoomLevel;
  }, [duration, timelineWidth, zoomLevel]);
  
  const pixelToTime = useCallback((pixel: number) => {
    return (pixel / (timelineWidth * zoomLevel)) * duration;
  }, [duration, timelineWidth, zoomLevel]);
  
  // Snap to grid helper
  const snapTime = useCallback((time: number) => {
    if (!snapToGrid) return time;
    return Math.round(time / gridSize) * gridSize;
  }, [snapToGrid, gridSize]);
  
  // Handle timeline click
  const handleTimelineClick = useCallback((e: React.MouseEvent) => {
    if (isDraggingSegment || isDraggingPlayhead) return;
    
    const rect = timelineRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left + scrollPosition;
    const time = pixelToTime(x);
    onTimeChange(snapTime(Math.max(0, Math.min(duration, time))));
  }, [isDraggingSegment, isDraggingPlayhead, scrollPosition, pixelToTime, onTimeChange, snapTime, duration]);
  
  // Handle mouse move for hover time
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const rect = timelineRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left + scrollPosition;
    const time = pixelToTime(x);
    setHoveredTime(Math.max(0, Math.min(duration, time)));
  }, [scrollPosition, pixelToTime, duration]);
  
  // Playhead drag handling
  const handlePlayheadDragStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingPlayhead(true);
  }, []);
  
  const handlePlayheadDrag = useCallback((e: MouseEvent) => {
    if (!isDraggingPlayhead || !timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left + scrollPosition;
    const time = pixelToTime(x);
    onTimeChange(snapTime(Math.max(0, Math.min(duration, time))));
  }, [isDraggingPlayhead, scrollPosition, pixelToTime, onTimeChange, snapTime, duration]);
  
  const handlePlayheadDragEnd = useCallback(() => {
    setIsDraggingPlayhead(false);
  }, []);
  
  // Segment drag handling
  const handleSegmentDragStart = useCallback((e: React.MouseEvent, segmentId: string, edge: 'start' | 'end' | 'both') => {
    e.preventDefault();
    e.stopPropagation();
    
    const segment = segments.find(s => s.id === segmentId);
    if (!segment || !timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    setIsDraggingSegment({
      segmentId,
      edge,
      initialX: e.clientX - rect.left + scrollPosition,
      initialStartTime: segment.startTime,
      initialEndTime: segment.endTime
    });
  }, [segments, scrollPosition]);
  
  const handleSegmentDrag = useCallback((e: MouseEvent) => {
    if (!isDraggingSegment || !timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const currentX = e.clientX - rect.left + scrollPosition;
    const deltaX = currentX - isDraggingSegment.initialX;
    const deltaTime = pixelToTime(deltaX) - pixelToTime(0);
    
    let newStartTime = isDraggingSegment.initialStartTime;
    let newEndTime = isDraggingSegment.initialEndTime;
    
    switch (isDraggingSegment.edge) {
      case 'start':
        newStartTime = snapTime(Math.max(0, Math.min(isDraggingSegment.initialEndTime - 0.1, isDraggingSegment.initialStartTime + deltaTime)));
        break;
      case 'end':
        newEndTime = snapTime(Math.min(duration, Math.max(isDraggingSegment.initialStartTime + 0.1, isDraggingSegment.initialEndTime + deltaTime)));
        break;
      case 'both':
        const segmentDuration = isDraggingSegment.initialEndTime - isDraggingSegment.initialStartTime;
        newStartTime = snapTime(Math.max(0, Math.min(duration - segmentDuration, isDraggingSegment.initialStartTime + deltaTime)));
        newEndTime = newStartTime + segmentDuration;
        break;
    }
    
    // Update segment in store
    if (currentProject && currentProject.activeTrackId) {
      updateSegment(currentProject.activeTrackId, isDraggingSegment.segmentId, {
        startTime: newStartTime,
        endTime: newEndTime
      });
    }
  }, [isDraggingSegment, scrollPosition, pixelToTime, snapTime, duration, currentProject, updateSegment]);
  
  const handleSegmentDragEnd = useCallback(() => {
    setIsDraggingSegment(null);
  }, []);
  
  // Set up global mouse event listeners for dragging
  useEffect(() => {
    if (isDraggingPlayhead) {
      window.addEventListener('mousemove', handlePlayheadDrag);
      window.addEventListener('mouseup', handlePlayheadDragEnd);
      return () => {
        window.removeEventListener('mousemove', handlePlayheadDrag);
        window.removeEventListener('mouseup', handlePlayheadDragEnd);
      };
    }
  }, [isDraggingPlayhead, handlePlayheadDrag, handlePlayheadDragEnd]);
  
  useEffect(() => {
    if (isDraggingSegment) {
      window.addEventListener('mousemove', handleSegmentDrag);
      window.addEventListener('mouseup', handleSegmentDragEnd);
      return () => {
        window.removeEventListener('mousemove', handleSegmentDrag);
        window.removeEventListener('mouseup', handleSegmentDragEnd);
      };
    }
  }, [isDraggingSegment, handleSegmentDrag, handleSegmentDragEnd]);
  
  // Handle scroll
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollPosition(e.currentTarget.scrollLeft);
  }, [setScrollPosition]);
  
  // Auto-scroll to keep playhead in view
  useEffect(() => {
    if (!scrollRef.current || isDraggingPlayhead) return;
    
    const playheadX = timeToPixel(currentTime);
    const scrollLeft = scrollRef.current.scrollLeft;
    const scrollWidth = scrollRef.current.clientWidth;
    
    if (playheadX < scrollLeft + 50) {
      scrollRef.current.scrollLeft = Math.max(0, playheadX - 50);
    } else if (playheadX > scrollLeft + scrollWidth - 50) {
      scrollRef.current.scrollLeft = playheadX - scrollWidth + 50;
    }
  }, [currentTime, timeToPixel, isDraggingPlayhead]);
  
  // Generate time markers
  const timeMarkers = useMemo(() => {
    const markers: JSX.Element[] = [];
    const pixelsPerSecond = timelineWidth * zoomLevel / duration;
    
    // Determine marker interval based on zoom level
    let interval = 1; // 1 second
    if (pixelsPerSecond < 10) interval = 10;
    else if (pixelsPerSecond < 30) interval = 5;
    else if (pixelsPerSecond > 100) interval = 0.5;
    else if (pixelsPerSecond > 200) interval = 0.1;
    
    for (let time = 0; time <= duration; time += interval) {
      const x = timeToPixel(time);
      const isMajor = time % 10 === 0;
      
      markers.push(
        <div
          key={time}
          className="absolute flex flex-col items-center"
          style={{ left: `${x}px` }}
        >
          <div className={`w-px ${isMajor ? 'h-4 bg-gray-500' : 'h-2 bg-gray-600'}`} />
          {showTimestamps && (isMajor || pixelsPerSecond > 50) && (
            <span className="text-xs text-gray-400 mt-1">{formatTime(time)}</span>
          )}
        </div>
      );
    }
    
    return markers;
  }, [duration, timelineWidth, zoomLevel, timeToPixel, showTimestamps]);
  
  // Grid lines
  const gridLines = useMemo(() => {
    if (!snapToGrid) return null;
    
    const lines: JSX.Element[] = [];
    for (let time = 0; time <= duration; time += gridSize) {
      const x = timeToPixel(time);
      lines.push(
        <div
          key={time}
          className="absolute top-0 bottom-0 w-px bg-gray-700/30 pointer-events-none"
          style={{ left: `${x}px` }}
        />
      );
    }
    return lines;
  }, [snapToGrid, duration, gridSize, timeToPixel]);
  
  return (
    <div className={`relative bg-gray-900 rounded-lg overflow-hidden ${className}`}>
      {/* Timeline Header */}
      <div className="bg-gray-800 border-b border-gray-700 px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium text-gray-300">Timeline</span>
            
            {/* Track info */}
            {currentProject && (
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <Layers className="w-3 h-3" />
                <span>{currentProject.tracks.length} tracks</span>
                <span className="text-gray-600">•</span>
                <span>{segments.length} segments</span>
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            {/* Toggle buttons */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleWaveform}
              className={`p-1.5 rounded transition-colors ${
                showWaveform ? 'bg-cyan-600 text-white' : 'bg-gray-700 text-gray-400 hover:text-gray-300'
              }`}
              title="Toggle waveform"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M2 12h4M8 6v12M12 3v18M16 8v8M20 10v4" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleTimestamps}
              className={`p-1.5 rounded transition-colors ${
                showTimestamps ? 'bg-cyan-600 text-white' : 'bg-gray-700 text-gray-400 hover:text-gray-300'
              }`}
              title="Toggle timestamps"
            >
              <span className="text-xs font-mono">00:00</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleSnapToGrid}
              className={`p-1.5 rounded transition-colors ${
                snapToGrid ? 'bg-cyan-600 text-white' : 'bg-gray-700 text-gray-400 hover:text-gray-300'
              }`}
              title="Toggle snap to grid"
            >
              <Grid3X3 className="w-4 h-4" />
            </motion.button>
            
            <div className="w-px h-5 bg-gray-700 mx-1" />
            
            {/* Zoom controls */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setZoomLevel(Math.max(0.1, zoomLevel - 0.2))}
              className="p-1.5 bg-gray-700 hover:bg-gray-600 rounded transition-colors"
              title="Zoom out"
            >
              <ZoomOut className="w-4 h-4" />
            </motion.button>
            
            <div className="text-xs text-gray-400 font-mono w-12 text-center">
              {Math.round(zoomLevel * 100)}%
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setZoomLevel(Math.min(10, zoomLevel + 0.2))}
              className="p-1.5 bg-gray-700 hover:bg-gray-600 rounded transition-colors"
              title="Zoom in"
            >
              <ZoomIn className="w-4 h-4" />
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setZoomLevel(1)}
              className="p-1.5 bg-gray-700 hover:bg-gray-600 rounded transition-colors"
              title="Reset zoom"
            >
              <Maximize className="w-4 h-4" />
            </motion.button>
          </div>
        </div>
      </div>
      
      {/* Timeline Content */}
      <div 
        ref={scrollRef}
        className="relative overflow-x-auto overflow-y-hidden scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-800"
        style={{ height: '150px' }}
        onScroll={handleScroll}
      >
        <div
          ref={timelineRef}
          className="relative h-full cursor-pointer"
          style={{ width: `${timelineWidth * zoomLevel}px`, minWidth: '100%' }}
          onClick={handleTimelineClick}
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHoveredTime(null)}
        >
          {/* Grid lines */}
          {gridLines}
          
          {/* Time markers */}
          <div className="absolute top-0 left-0 right-0 h-6 border-b border-gray-700">
            {timeMarkers}
          </div>
          
          {/* Waveform placeholder */}
          {showWaveform && (
            <div className="absolute top-6 left-0 right-0 bottom-0 opacity-20">
              <svg className="w-full h-full" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="waveGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.1" />
                  </linearGradient>
                </defs>
                {/* Simple waveform visualization */}
                {Array.from({ length: Math.ceil(duration * 10) }).map((_, i) => {
                  const height = Math.random() * 60 + 20;
                  const x = (i / (duration * 10)) * 100;
                  return (
                    <rect
                      key={i}
                      x={`${x}%`}
                      y={`${50 - height / 2}%`}
                      width="0.8%"
                      height={`${height}%`}
                      fill="url(#waveGradient)"
                    />
                  );
                })}
              </svg>
            </div>
          )}
          
          {/* Track lanes */}
          {currentProject?.tracks.map((track, trackIndex) => (
            <div
              key={track.id}
              className="absolute left-0 right-0 border-b border-gray-800"
              style={{
                top: `${30 + trackIndex * 40}px`,
                height: '36px'
              }}
            >
              {/* Track header */}
              <div className="absolute -left-32 top-0 w-32 h-full bg-gray-800 border-r border-gray-700 flex items-center px-2 gap-1">
                <button
                  onClick={() => {
                    // Toggle track visibility
                    const updatedTrack = { ...track, isVisible: !track.isVisible };
                    // Update track in store
                  }}
                  className="p-1 hover:bg-gray-700 rounded transition-colors"
                >
                  {track.isVisible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3 text-gray-500" />}
                </button>
                <button
                  onClick={() => {
                    // Toggle track lock
                    const updatedTrack = { ...track, isLocked: !track.isLocked };
                    // Update track in store
                  }}
                  className="p-1 hover:bg-gray-700 rounded transition-colors"
                >
                  {track.isLocked ? <Lock className="w-3 h-3 text-red-500" /> : <Unlock className="w-3 h-3" />}
                </button>
                <span className="text-xs text-gray-400 truncate flex-1">{track.name}</span>
              </div>
              
              {/* Track segments */}
              {track.segments.map(segment => {
                const startX = timeToPixel(segment.startTime);
                const endX = timeToPixel(segment.endTime);
                const width = endX - startX;
                const isSelected = selectedSegmentIds.includes(segment.id);
                const isActive = segment.id === activeSegmentId;
                const isHovered = segment.id === hoveredSegment;
                
                return (
                  <motion.div
                    key={segment.id}
                    className={`absolute h-8 rounded cursor-pointer select-none ${
                      isActive ? 'ring-2 ring-cyan-500 z-20' : 
                      isSelected ? 'ring-2 ring-blue-500 z-10' : 
                      'hover:ring-2 hover:ring-gray-500'
                    }`}
                    style={{
                      left: `${startX}px`,
                      width: `${Math.max(20, width)}px`,
                      top: '2px',
                      backgroundColor: isActive ? '#06b6d4' : isSelected ? '#3b82f6' : track.style?.backgroundColor || '#4b5563',
                      opacity: track.isVisible ? 1 : 0.3,
                      pointerEvents: track.isLocked ? 'none' : 'auto'
                    }}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: track.isVisible ? 1 : 0.3, scale: 1 }}
                    whileHover={{ scale: 1.02 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSegmentClick(segment.id);
                    }}
                    onMouseEnter={() => setHoveredSegment(segment.id)}
                    onMouseLeave={() => setHoveredSegment(null)}
                    onMouseDown={(e) => handleSegmentDragStart(e, segment.id, 'both')}
                  >
                    {/* Segment content */}
                    <div className="px-2 py-1 h-full flex items-center overflow-hidden">
                      <span className="text-xs text-white truncate">{segment.text}</span>
                    </div>
                    
                    {/* Resize handles */}
                    {!track.isLocked && (
                      <>
                        <div
                          className="absolute left-0 top-0 bottom-0 w-2 cursor-ew-resize hover:bg-white/20"
                          onMouseDown={(e) => handleSegmentDragStart(e, segment.id, 'start')}
                        />
                        <div
                          className="absolute right-0 top-0 bottom-0 w-2 cursor-ew-resize hover:bg-white/20"
                          onMouseDown={(e) => handleSegmentDragStart(e, segment.id, 'end')}
                        />
                      </>
                    )}
                    
                    {/* Hover tooltip */}
                    <AnimatePresence>
                      {isHovered && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          className="absolute -top-16 left-1/2 transform -translate-x-1/2 bg-gray-800 rounded-lg px-3 py-2 pointer-events-none z-50 whitespace-nowrap"
                        >
                          <div className="text-xs text-white font-medium mb-1">{segment.text}</div>
                          <div className="text-xs text-gray-400">
                            {formatTime(segment.startTime)} - {formatTime(segment.endTime)}
                            <span className="ml-2">({formatTime(segment.endTime - segment.startTime)})</span>
                          </div>
                          {segment.confidence && (
                            <div className="text-xs text-gray-500 mt-1">
                              Confidence: {Math.round(segment.confidence * 100)}%
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </div>
          ))}
          
          {/* Playhead */}
          <motion.div
            className="absolute top-0 bottom-0 w-0.5 bg-cyan-500 z-30 cursor-ew-resize"
            style={{ left: `${timeToPixel(currentTime)}px` }}
            animate={{ left: timeToPixel(currentTime) }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            onMouseDown={handlePlayheadDragStart}
          >
            {/* Playhead handle */}
            <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-cyan-500 rounded-full" />
            
            {/* Current time label */}
            <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-cyan-600 text-white text-xs px-2 py-0.5 rounded whitespace-nowrap">
              {formatTime(currentTime)}
            </div>
          </motion.div>
          
          {/* Hover time indicator */}
          <AnimatePresence>
            {hoveredTime !== null && !isDraggingPlayhead && !isDraggingSegment && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute top-0 bottom-0 w-px bg-gray-500 pointer-events-none"
                style={{ left: `${timeToPixel(hoveredTime)}px` }}
              >
                <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-gray-700 text-gray-300 text-xs px-2 py-0.5 rounded whitespace-nowrap">
                  {formatTime(hoveredTime)}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default SubtitleTimeline; 