import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface CreativeLoadingScreenProps {
  isLoading: boolean;
  progress: number;
  status: string;
  type: 'model' | 'transcription';
}

export const CreativeLoadingScreen: React.FC<CreativeLoadingScreenProps> = ({
  isLoading,
  progress,
  status,
  type
}) => {
  const isModelLoading = type === 'model';
  
  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center"
        >
          <div className="relative">
            {/* Background glow effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-full blur-3xl opacity-30"
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 180, 360],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "linear"
              }}
              style={{ width: '400px', height: '400px', marginLeft: '-200px', marginTop: '-200px' }}
            />
            
            {/* Main content */}
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="relative bg-gray-900/90 backdrop-blur-sm p-8 rounded-2xl shadow-2xl border border-gray-700 min-w-[400px]"
            >
              {/* Icon animation */}
              <div className="flex justify-center mb-6">
                {isModelLoading ? (
                  <motion.div
                    className="relative w-24 h-24"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                  >
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <motion.circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="url(#gradient)"
                        strokeWidth="4"
                        strokeLinecap="round"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: progress / 100 }}
                        transition={{ duration: 0.5 }}
                      />
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#06b6d4" />
                          <stop offset="50%" stopColor="#3b82f6" />
                          <stop offset="100%" stopColor="#a855f7" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <motion.div
                        className="text-3xl"
                        animate={{ 
                          scale: [1, 1.2, 1],
                          rotate: [0, 5, -5, 0]
                        }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        🧠
                      </motion.div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div className="relative">
                    {/* Microphone with sound waves */}
                    <motion.div
                      className="text-6xl"
                      animate={{ 
                        scale: [1, 1.1, 1],
                        y: [0, -5, 0]
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      🎤
                    </motion.div>
                    
                    {/* Sound waves */}
                    {[1, 2, 3].map((i) => (
                      <motion.div
                        key={i}
                        className="absolute inset-0 border-2 border-cyan-400 rounded-full"
                        initial={{ scale: 0.8, opacity: 0.6 }}
                        animate={{
                          scale: [0.8, 1.5, 2],
                          opacity: [0.6, 0.3, 0],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: i * 0.4,
                        }}
                        style={{ width: '60px', height: '60px', left: '50%', top: '50%', marginLeft: '-30px', marginTop: '-30px' }}
                      />
                    ))}
                  </motion.div>
                )}
              </div>
              
              {/* Title */}
              <h3 className="text-xl font-semibold text-center mb-4">
                {isModelLoading ? 'Loading AI Model' : 'Transcribing Audio'}
              </h3>
              
              {/* Progress bar */}
              <div className="relative mb-4">
                <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                  />
                </div>
                <div className="mt-2 flex justify-between text-sm">
                  <span className="text-gray-400">{status}</span>
                  <motion.span 
                    className="text-cyan-400"
                    key={progress}
                    initial={{ scale: 1.2 }}
                    animate={{ scale: 1 }}
                  >
                    {Math.round(progress)}%
                  </motion.span>
                </div>
              </div>
              
              {/* Fun facts or tips */}
              <motion.div
                key={Math.floor(progress / 20)}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-center text-sm text-gray-400"
              >
                {getFunFact(type, Math.floor(progress / 20))}
              </motion.div>
              
              {/* Animated dots */}
              <div className="flex justify-center mt-4 space-x-2">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 bg-cyan-400 rounded-full"
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.5, 1, 0.5],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      delay: i * 0.2,
                    }}
                  />
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

function getFunFact(type: 'model' | 'transcription', index: number): string {
  const modelFacts = [
    "💡 Whisper AI can understand over 99 languages!",
    "🚀 The model is processing billions of parameters...",
    "🎯 Whisper was trained on 680,000 hours of audio!",
    "⚡ Almost ready to transcribe at lightning speed!",
    "✨ Preparing state-of-the-art speech recognition..."
  ];
  
  const transcriptionFacts = [
    "🎵 Analyzing audio frequencies and patterns...",
    "🔊 Converting speech waves into text tokens...",
    "📝 Detecting sentence boundaries and punctuation...",
    "🌍 Identifying the language and accent...",
    "🎯 Fine-tuning the transcription accuracy..."
  ];
  
  const facts = type === 'model' ? modelFacts : transcriptionFacts;
  return facts[Math.min(index, facts.length - 1)];
}

export default CreativeLoadingScreen; 