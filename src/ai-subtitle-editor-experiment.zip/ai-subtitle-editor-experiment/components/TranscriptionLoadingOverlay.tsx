import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Mic, Brain, Zap } from 'lucide-react';

interface TranscriptionLoadingOverlayProps {
  isVisible: boolean;
  progress: number;
  status: string;
  isLoadingModel?: boolean;
}

export const TranscriptionLoadingOverlay: React.FC<TranscriptionLoadingOverlayProps> = ({
  isVisible,
  progress,
  status,
  isLoadingModel = false
}) => {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-gray-900 rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl border border-gray-800"
          >
            <div className="text-center">
              {/* Animated Icon */}
              <div className="mb-6 relative">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 w-24 h-24 mx-auto"
                >
                  <div className="w-full h-full rounded-full border-4 border-cyan-500/20 border-t-cyan-500" />
                </motion.div>
                <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                  {isLoadingModel ? (
                    <Brain className="w-12 h-12 text-cyan-500" />
                  ) : (
                    <Mic className="w-12 h-12 text-cyan-500" />
                  )}
                </div>
              </div>

              {/* Title */}
              <h3 className="text-xl font-semibold text-white mb-2">
                {isLoadingModel ? 'Loading AI Model' : 'Transcribing Audio'}
              </h3>

              {/* Status */}
              <p className="text-gray-400 mb-6 text-sm">
                {status || (isLoadingModel ? 'Preparing Whisper AI...' : 'Processing your audio...')}
              </p>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-500">Progress</span>
                  <span className="text-xs text-gray-500">{Math.round(progress)}%</span>
                </div>
                <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden">
                  <motion.div
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                  {/* Shimmer effect */}
                  <motion.div
                    className="absolute top-0 left-0 h-full w-full bg-gradient-to-r from-transparent via-white/10 to-transparent"
                    animate={{ x: ['-100%', '100%'] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                  />
                </div>
              </div>

              {/* Tips */}
              <div className="text-xs text-gray-500">
                {isLoadingModel ? (
                  <div className="flex items-center justify-center gap-2">
                    <Zap className="w-3 h-3" />
                    <span>Using GPU acceleration for faster processing</span>
                  </div>
                ) : (
                  <div>
                    {progress < 30 && "Analyzing audio frequencies..."}
                    {progress >= 30 && progress < 60 && "Detecting speech patterns..."}
                    {progress >= 60 && progress < 90 && "Generating subtitles..."}
                    {progress >= 90 && "Finalizing results..."}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default TranscriptionLoadingOverlay; 