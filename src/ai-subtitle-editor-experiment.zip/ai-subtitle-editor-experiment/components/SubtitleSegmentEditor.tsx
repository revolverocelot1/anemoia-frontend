import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Type, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight,
  Clock, User, Trash2, Copy, Split, Merge, Save, X, Check,
  ChevronUp, ChevronDown, MoreVertical, AlertCircle
} from 'lucide-react';
import { useSubtitleStore } from '../../stores/subtitle-store';
import type { SubtitleSegment } from '../../types/subtitle';
import { formatTime } from '../../lib/subtitle-utils';

interface SubtitleSegmentEditorProps {
  segment: SubtitleSegment;
  trackId: string;
  onClose?: () => void;
  autoFocus?: boolean;
  className?: string;
}

export const SubtitleSegmentEditor: React.FC<SubtitleSegmentEditorProps> = ({
  segment,
  trackId,
  onClose,
  autoFocus = true,
  className = ''
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [editedText, setEditedText] = useState(segment.text);
  const [editedStartTime, setEditedStartTime] = useState(formatTime(segment.startTime));
  const [editedEndTime, setEditedEndTime] = useState(formatTime(segment.endTime));
  const [showFormatting, setShowFormatting] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState(false);
  
  const {
    updateSegment,
    deleteSegment,
    splitSegment,
    mergeSegments,
    selectedSegmentIds,
    getSegmentById,
    activeTrackId
  } = useSubtitleStore();
  
  // Auto-focus on mount
  useEffect(() => {
    if (autoFocus && textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.select();
    }
  }, [autoFocus]);
  
  // Parse time string to seconds
  const parseTime = (timeStr: string): number | null => {
    const parts = timeStr.split(':').map(p => parseFloat(p));
    if (parts.length === 2) {
      // mm:ss format
      const [minutes, seconds] = parts;
      if (isNaN(minutes) || isNaN(seconds)) return null;
      return minutes * 60 + seconds;
    } else if (parts.length === 3) {
      // hh:mm:ss format
      const [hours, minutes, seconds] = parts;
      if (isNaN(hours) || isNaN(minutes) || isNaN(seconds)) return null;
      return hours * 3600 + minutes * 60 + seconds;
    }
    return null;
  };
  
  // Validate times
  const validateTimes = (startStr: string, endStr: string): string | null => {
    const start = parseTime(startStr);
    const end = parseTime(endStr);
    
    if (start === null) return 'Invalid start time format';
    if (end === null) return 'Invalid end time format';
    if (start < 0) return 'Start time cannot be negative';
    if (end <= start) return 'End time must be after start time';
    
    return null;
  };
  
  // Handle save
  const handleSave = useCallback(() => {
    const validationError = validateTimes(editedStartTime, editedEndTime);
    if (validationError) {
      setError(validationError);
      return;
    }
    
    const startTime = parseTime(editedStartTime)!;
    const endTime = parseTime(editedEndTime)!;
    
    updateSegment(trackId, segment.id, {
      text: editedText.trim(),
      startTime,
      endTime
    });
    
    setIsDirty(false);
    setError(null);
    
    if (onClose) {
      onClose();
    }
  }, [segment.id, editedText, editedStartTime, editedEndTime, updateSegment, onClose]);
  
  // Handle delete
  const handleDelete = useCallback(() => {
    if (confirm('Are you sure you want to delete this subtitle?')) {
      deleteSegment(trackId, segment.id);
      if (onClose) {
        onClose();
      }
    }
  }, [trackId, segment.id, deleteSegment, onClose]);
  
  // Handle split
  const handleSplit = useCallback(() => {
    const cursorPosition = textareaRef.current?.selectionStart || editedText.length / 2;
    const splitRatio = cursorPosition / editedText.length;
    const splitTime = segment.startTime + (segment.endTime - segment.startTime) * splitRatio;
    
    splitSegment(trackId, segment.id, splitTime);
    
    if (onClose) {
      onClose();
    }
  }, [trackId, segment, editedText.length, splitSegment, onClose]);
  
  // Handle merge with next
  const handleMergeNext = useCallback(() => {
    if (!activeTrackId) return;
    
    // Find next segment
    const track = useSubtitleStore.getState().currentProject?.tracks.find(t => t.id === activeTrackId);
    if (!track) return;
    
    const sortedSegments = [...track.segments].sort((a, b) => a.startTime - b.startTime);
    const currentIndex = sortedSegments.findIndex(s => s.id === segment.id);
    
    if (currentIndex >= 0 && currentIndex < sortedSegments.length - 1) {
      const nextSegment = sortedSegments[currentIndex + 1];
      mergeSegments(trackId, [segment.id, nextSegment.id]);
    }
  }, [segment.id, trackId, activeTrackId, mergeSegments]);
  
  // Apply text formatting
  const applyFormatting = useCallback((format: string) => {
    if (!textareaRef.current) return;
    
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const selectedText = editedText.substring(start, end);
    
    let formattedText = '';
    switch (format) {
      case 'bold':
        formattedText = `<b>${selectedText}</b>`;
        break;
      case 'italic':
        formattedText = `<i>${selectedText}</i>`;
        break;
      case 'underline':
        formattedText = `<u>${selectedText}</u>`;
        break;
      default:
        return;
    }
    
    const newText = editedText.substring(0, start) + formattedText + editedText.substring(end);
    setEditedText(newText);
    setIsDirty(true);
    
    // Restore focus and selection
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(start, start + formattedText.length);
      }
    }, 0);
  }, [editedText]);
  
  // Handle keyboard shortcuts
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case 's':
          e.preventDefault();
          handleSave();
          break;
        case 'b':
          e.preventDefault();
          applyFormatting('bold');
          break;
        case 'i':
          e.preventDefault();
          applyFormatting('italic');
          break;
        case 'u':
          e.preventDefault();
          applyFormatting('underline');
          break;
      }
    } else if (e.key === 'Escape' && onClose) {
      onClose();
    } else if (e.key === 'Enter' && e.shiftKey) {
      e.preventDefault();
      handleSave();
    }
  }, [handleSave, applyFormatting, onClose]);
  
  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [editedText]);
  
  // Track changes
  useEffect(() => {
    const hasTextChanged = editedText !== segment.text;
    const hasStartChanged = parseTime(editedStartTime) !== segment.startTime;
    const hasEndChanged = parseTime(editedEndTime) !== segment.endTime;
    
    setIsDirty(hasTextChanged || hasStartChanged || hasEndChanged);
  }, [editedText, editedStartTime, editedEndTime, segment]);
  
  return (
    <motion.div
      className={`bg-black/95 backdrop-blur-md rounded-xl shadow-2xl border border-gray-800/50 ${className}`}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800/50 bg-gradient-to-r from-gray-900/50 to-gray-800/50">
        <div className="flex items-center gap-3">
          <Type className="w-5 h-5 text-cyan-400" />
          <h3 className="text-lg font-semibold text-white">Edit Subtitle</h3>
          {isDirty && (
            <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded-md font-medium">
              Unsaved
            </span>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowFormatting(!showFormatting)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
            title="Text formatting"
          >
            <Bold className="w-4 h-4 text-gray-400" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
            title="Advanced options"
          >
            <MoreVertical className="w-4 h-4 text-gray-400" />
          </motion.button>
          
          {onClose && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onClose}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
            >
              <X className="w-4 h-4 text-gray-400" />
            </motion.button>
          )}
        </div>
      </div>
      
      {/* Formatting Toolbar */}
      <AnimatePresence>
        {showFormatting && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-b border-gray-700 overflow-hidden"
          >
            <div className="p-3 flex items-center gap-2">
              <button
                onClick={() => applyFormatting('bold')}
                className="p-2 hover:bg-gray-800 rounded transition-colors"
                title="Bold (Ctrl+B)"
              >
                <Bold className="w-4 h-4 text-gray-300" />
              </button>
              
              <button
                onClick={() => applyFormatting('italic')}
                className="p-2 hover:bg-gray-800 rounded transition-colors"
                title="Italic (Ctrl+I)"
              >
                <Italic className="w-4 h-4 text-gray-300" />
              </button>
              
              <button
                onClick={() => applyFormatting('underline')}
                className="p-2 hover:bg-gray-800 rounded transition-colors"
                title="Underline (Ctrl+U)"
              >
                <Underline className="w-4 h-4 text-gray-300" />
              </button>
              
              <div className="w-px h-6 bg-gray-700 mx-1" />
              
              <span className="text-xs text-gray-500">
                Use HTML tags for formatting: &lt;b&gt;, &lt;i&gt;, &lt;u&gt;
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Main Content */}
      <div className="p-4 space-y-4">
        {/* Text Editor */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Subtitle Text
          </label>
          <textarea
            ref={textareaRef}
            value={editedText}
            onChange={(e) => {
              setEditedText(e.target.value);
              setIsDirty(true);
            }}
            onKeyDown={handleKeyDown}
            className="w-full bg-gray-900/50 backdrop-blur-sm text-white px-4 py-3 rounded-lg border border-gray-700/50 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none resize-none transition-all duration-200"
            style={{ minHeight: '80px' }}
            placeholder="Enter subtitle text..."
          />
          <div className="mt-1 flex items-center justify-between">
            <span className="text-xs text-gray-500">
              {editedText.length} characters
            </span>
            <span className="text-xs text-gray-500">
              Press Shift+Enter to save
            </span>
          </div>
        </div>
        
        {/* Timing Controls */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Clock className="w-4 h-4 inline mr-1" />
              Start Time
            </label>
            <input
              type="text"
              value={editedStartTime}
              onChange={(e) => {
                setEditedStartTime(e.target.value);
                setIsDirty(true);
                setError(null);
              }}
              className="w-full bg-gray-900/50 backdrop-blur-sm text-white px-3 py-2 rounded-lg border border-gray-700/50 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-200"
              placeholder="00:00.000"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Clock className="w-4 h-4 inline mr-1" />
              End Time
            </label>
            <input
              type="text"
              value={editedEndTime}
              onChange={(e) => {
                setEditedEndTime(e.target.value);
                setIsDirty(true);
                setError(null);
              }}
              className="w-full bg-gray-900/50 backdrop-blur-sm text-white px-3 py-2 rounded-lg border border-gray-700/50 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-200"
              placeholder="00:00.000"
            />
          </div>
        </div>
        
        {/* Duration Info */}
        <div className="text-sm text-gray-400">
          Duration: {((parseTime(editedEndTime) || 0) - (parseTime(editedStartTime) || 0)).toFixed(2)}s
        </div>
        
        {/* Error Message */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="p-3 bg-red-900/20 border border-red-700 rounded-lg flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
              <span className="text-sm text-red-400">{error}</span>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Advanced Options */}
        <AnimatePresence>
          {showAdvanced && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-3 overflow-hidden"
            >
              <div className="pt-3 border-t border-gray-700">
                <h4 className="text-sm font-medium text-gray-300 mb-3">Advanced Options</h4>
                
                {/* Speaker Assignment */}
                <div className="mb-3">
                  <label className="block text-sm text-gray-400 mb-1">
                    <User className="w-4 h-4 inline mr-1" />
                    Speaker
                  </label>
                  <input
                    type="text"
                    value={segment.speaker || ''}
                    onChange={(e) => {
                      updateSegment(trackId, segment.id, { speaker: e.target.value });
                    }}
                    className="w-full bg-gray-800 text-white px-3 py-2 rounded border border-gray-700 focus:border-cyan-500 outline-none"
                    placeholder="Speaker name (optional)"
                  />
                </div>
                
                {/* Confidence Score */}
                {segment.confidence !== undefined && (
                  <div className="text-sm text-gray-400">
                    Confidence: {(segment.confidence * 100).toFixed(1)}%
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Actions */}
      <div className="flex items-center justify-between p-4 border-t border-gray-700 bg-gray-800/50">
        <div className="flex items-center gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDelete}
            className="p-2 hover:bg-red-600/20 rounded-lg transition-colors group"
            title="Delete subtitle"
          >
            <Trash2 className="w-4 h-4 text-gray-400 group-hover:text-red-500" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSplit}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
            title="Split at cursor"
          >
            <Split className="w-4 h-4 text-gray-400" />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleMergeNext}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
            title="Merge with next"
          >
            <Merge className="w-4 h-4 text-gray-400" />
          </motion.button>
        </div>
        
        <div className="flex items-center gap-3">
          {onClose && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onClose}
              className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
            >
              Cancel
            </motion.button>
          )}
          
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSave}
            disabled={!isDirty}
            className={`px-5 py-2.5 rounded-lg font-medium transition-all duration-200 flex items-center gap-2 ${
              isDirty
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white shadow-lg shadow-cyan-500/25'
                : 'bg-gray-800 text-gray-500 cursor-not-allowed'
            }`}
          >
            <Save className="w-4 h-4" />
            Save Changes
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

export default SubtitleSegmentEditor; 