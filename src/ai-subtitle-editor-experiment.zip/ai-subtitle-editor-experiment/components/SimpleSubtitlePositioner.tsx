import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useSubtitleStore } from '../../stores/subtitle-store';

interface SimpleSubtitlePositionerProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  isEnabled: boolean;
  onToggle: () => void;
}

export default function SimpleSubtitlePositioner({
  videoRef,
  isEnabled,
  onToggle
}: SimpleSubtitlePositionerProps) {
  const currentProject = useSubtitleStore(state => state.currentProject);
  const updateStyle = useSubtitleStore(state => state.updateStyle);
  const playbackTime = useSubtitleStore(state => state.playbackTime);
  const segments = useSubtitleStore(state => state.getSegmentsInTimeRange(0, Infinity));
  
  const [position, setPosition] = useState({ x: 50, y: 85 }); // Percentage
  const [size, setSize] = useState({ width: 80, height: 20 }); // Percentage
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [resizeHandle, setResizeHandle] = useState('');
  
  const containerRef = useRef<HTMLDivElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  
  // Get current subtitle
  const currentSegment = segments.find(
    seg => playbackTime >= seg.startTime && playbackTime <= seg.endTime
  );
  const currentText = currentSegment?.text || 'Sample Subtitle Text';
  
  const style = currentProject?.style || {
    fontSize: 24,
    fontFamily: 'Arial',
    fontColor: '#FFFFFF',
    backgroundColor: '#000000',
    backgroundOpacity: 0.75,
    padding: 10,
    borderRadius: 4
  };

  // Handle dragging
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    const target = e.target as HTMLElement;
    
    if (target.classList.contains('resize-handle')) {
      setIsResizing(true);
      setResizeHandle(target.dataset.handle || '');
    } else {
      setIsDragging(true);
    }
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    if (isDragging) {
      // Keep box within bounds
      const newX = Math.max(size.width / 2, Math.min(100 - size.width / 2, x));
      const newY = Math.max(size.height / 2, Math.min(100 - size.height / 2, y));
      setPosition({ x: newX, y: newY });
    } else if (isResizing && resizeHandle) {
      // Handle resizing
      const minSize = 20; // Minimum 20% size
      const maxSize = 95; // Maximum 95% size
      
      if (resizeHandle.includes('right')) {
        const newWidth = Math.max(minSize, Math.min(maxSize, (x - position.x) * 2));
        setSize(prev => ({ ...prev, width: newWidth }));
      }
      if (resizeHandle.includes('left')) {
        const newWidth = Math.max(minSize, Math.min(maxSize, (position.x - x) * 2));
        setSize(prev => ({ ...prev, width: newWidth }));
      }
      if (resizeHandle.includes('bottom')) {
        const newHeight = Math.max(10, Math.min(50, (y - position.y) * 2));
        setSize(prev => ({ ...prev, height: newHeight }));
      }
      if (resizeHandle.includes('top')) {
        const newHeight = Math.max(10, Math.min(50, (position.y - y) * 2));
        setSize(prev => ({ ...prev, height: newHeight }));
      }
    }
  }, [isDragging, isResizing, resizeHandle, position, size]);

  const handleMouseUp = useCallback(() => {
    if (isDragging || isResizing) {
      // Update style based on final position
      let positionStr = '';
      
      if (position.y < 33) positionStr = 'top';
      else if (position.y > 67) positionStr = 'bottom';
      else positionStr = 'middle';
      
      if (position.x < 33) positionStr += '-left';
      else if (position.x > 67) positionStr += '-right';
      else positionStr += '-center';
      
      updateStyle({ 
        position: positionStr as any,
        marginX: Math.round(100 - size.width) / 2,
        marginY: Math.round(100 - size.height) / 2
      });
    }
    
    setIsDragging(false);
    setIsResizing(false);
    setResizeHandle('');
  }, [isDragging, isResizing, position, size, updateStyle]);

  useEffect(() => {
    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isResizing, handleMouseMove, handleMouseUp]);

  if (!isEnabled || !currentProject) return null;

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 overflow-hidden"
      style={{ pointerEvents: 'auto' }}
    >
      {/* Subtitle box */}
      <div
        ref={boxRef}
        className="absolute"
        style={{
          left: `${position.x}%`,
          top: `${position.y}%`,
          width: `${size.width}%`,
          height: `${size.height}%`,
          transform: 'translate(-50%, -50%)',
          cursor: isDragging ? 'grabbing' : 'grab',
          userSelect: 'none',
          minHeight: '60px'
        }}
        onMouseDown={handleMouseDown}
      >
        {/* Subtitle content */}
        <div
          className="h-full flex items-center justify-center p-4 relative"
          style={{
            backgroundColor: `${style.backgroundColor}${Math.round((style.backgroundOpacity || 0.75) * 255).toString(16).padStart(2, '0')}`,
            borderRadius: `${style.borderRadius}px`,
            border: '2px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.5)'
          }}
        >
          <div
            style={{
              fontFamily: style.fontFamily,
              fontSize: `${style.fontSize}px`,
              color: style.fontColor,
              textAlign: 'center',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              maxWidth: '100%',
              overflow: 'hidden'
            }}
          >
            {currentText}
          </div>
          
          {/* Resize handles */}
          <div
            className="resize-handle absolute -top-1 -left-1 w-3 h-3 bg-white rounded-full cursor-nw-resize"
            data-handle="top-left"
          />
          <div
            className="resize-handle absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full cursor-ne-resize"
            data-handle="top-right"
          />
          <div
            className="resize-handle absolute -bottom-1 -left-1 w-3 h-3 bg-white rounded-full cursor-sw-resize"
            data-handle="bottom-left"
          />
          <div
            className="resize-handle absolute -bottom-1 -right-1 w-3 h-3 bg-white rounded-full cursor-se-resize"
            data-handle="bottom-right"
          />
        </div>
      </div>

      {/* Info overlay */}
      <div className="absolute top-4 left-4 bg-black/75 text-white p-3 rounded pointer-events-none">
        <div className="text-sm space-y-1">
          <div>Position: {Math.round(position.x)}%, {Math.round(position.y)}%</div>
          <div>Size: {Math.round(size.width)}% × {Math.round(size.height)}%</div>
          <div className="text-xs text-gray-400">Drag to move, corners to resize</div>
        </div>
      </div>

      {/* Close button */}
      <button
        onClick={onToggle}
        className="absolute top-4 right-4 bg-red-600 hover:bg-red-700 text-white p-2 rounded transition-colors"
        title="Close positioner"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
} 