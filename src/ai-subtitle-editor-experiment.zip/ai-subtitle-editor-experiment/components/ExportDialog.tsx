import React, { useState, useEffect } from 'react';
import { Zap, Cloud, Cpu, AlertCircle, Check } from 'lucide-react';
import { hybridVideoExporter } from '../../lib/video-export-server';
import type { SubtitleProject } from '../../types/subtitle';

interface ExportDialogProps {
  isOpen: boolean;
  onClose: () => void;
  project: SubtitleProject;
  onExport: (method: 'auto' | 'webcodecs' | 'server' | 'ffmpeg') => void;
}

interface ExportMethod {
  id: 'auto' | 'webcodecs' | 'server' | 'ffmpeg';
  name: string;
  description: string;
  icon: React.ReactNode;
  speedup: string;
  available: boolean;
  recommended?: boolean;
}

export default function ExportDialog({ isOpen, onClose, project, onExport }: ExportDialogProps) {
  const [selectedMethod, setSelectedMethod] = useState<ExportMethod['id']>('auto');
  const [estimates, setEstimates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const exportMethods: ExportMethod[] = [
    {
      id: 'auto',
      name: 'Auto (Recommended)',
      description: 'Automatically choose the fastest available method',
      icon: <Zap className="w-5 h-5" />,
      speedup: 'Optimal',
      available: true,
      recommended: true
    },
    {
      id: 'server',
      name: 'Cloud GPU Rendering',
      description: 'Ultra-fast processing using cloud GPUs (requires internet)',
      icon: <Cloud className="w-5 h-5" />,
      speedup: '~20x faster',
      available: false // Will be updated based on availability check
    },
    {
      id: 'webcodecs',
      name: 'WebCodecs (Browser)',
      description: 'Fast local processing using modern browser APIs',
      icon: <Cpu className="w-5 h-5" />,
      speedup: '~3x faster',
      available: 'VideoDecoder' in window
    },
    {
      id: 'ffmpeg',
      name: 'FFmpeg (Classic)',
      description: 'Reliable fallback method, works everywhere',
      icon: <Cpu className="w-5 h-5" />,
      speedup: '1x (baseline)',
      available: true
    }
  ];
  
  useEffect(() => {
    if (!isOpen) return;
    
    const checkAvailability = async () => {
      setLoading(true);
      try {
        // Get performance estimates
        const subtitleCount = project.tracks.reduce((sum, t) => sum + t.segments.length, 0);
        const estimates = await hybridVideoExporter.getPerformanceEstimates(
          project.videoDuration,
          subtitleCount
        );
        setEstimates(estimates);
        
        // Update method availability based on estimates
        exportMethods[1].available = estimates.some(e => e.method.includes('Server'));
        
      } catch (error) {
        console.error('Failed to get estimates:', error);
      } finally {
        setLoading(false);
      }
    };
    
    checkAvailability();
  }, [isOpen, project]);
  
  if (!isOpen) return null;
  
  const formatTime = (seconds: number): string => {
    if (seconds < 60) return `${Math.round(seconds)}s`;
    const minutes = Math.floor(seconds / 60);
    const secs = Math.round(seconds % 60);
    return `${minutes}m ${secs}s`;
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 max-w-2xl w-full">
        <h2 className="text-2xl font-semibold mb-4">Choose Export Method</h2>
        
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <>
            <div className="space-y-3 mb-6">
              {exportMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedMethod(method.id)}
                  disabled={!method.available}
                  className={`
                    w-full p-4 rounded-lg border-2 transition-all text-left
                    ${selectedMethod === method.id
                      ? 'border-blue-500 bg-blue-500/10'
                      : 'border-gray-700 hover:border-gray-600'
                    }
                    ${!method.available ? 'opacity-50 cursor-not-allowed' : ''}
                  `}
                >
                  <div className="flex items-start gap-3">
                    <div className={`
                      p-2 rounded-lg
                      ${selectedMethod === method.id ? 'bg-blue-500/20' : 'bg-gray-700'}
                    `}>
                      {method.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{method.name}</h3>
                        {method.recommended && (
                          <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full">
                            Recommended
                          </span>
                        )}
                        {!method.available && (
                          <span className="text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded-full">
                            Not Available
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-400 mt-1">{method.description}</p>
                      <div className="flex items-center gap-4 mt-2 text-sm">
                        <span className="text-blue-400">Speed: {method.speedup}</span>
                        {method.id !== 'auto' && estimates.length > 0 && (
                          <span className="text-gray-500">
                            Est. time: {formatTime(
                              estimates.find(e => 
                                e.method.toLowerCase().includes(method.id)
                              )?.estimatedTime || project.videoDuration * 2
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                    {selectedMethod === method.id && (
                      <Check className="w-5 h-5 text-blue-500" />
                    )}
                  </div>
                </button>
              ))}
            </div>
            
            {/* Performance comparison */}
            {estimates.length > 0 && (
              <div className="bg-gray-900 rounded-lg p-4 mb-6">
                <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-yellow-500" />
                  Performance Estimates for Your Video
                </h4>
                <div className="space-y-2">
                  {estimates.map((est, idx) => (
                    <div key={idx} className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">{est.method}:</span>
                      <div className="flex items-center gap-3">
                        <span>{formatTime(est.estimatedTime)}</span>
                        <span className="text-green-400 text-xs">
                          {est.speedup}x faster
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="flex justify-end gap-3">
              <button
                onClick={onClose}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onExport(selectedMethod);
                  onClose();
                }}
                disabled={!exportMethods.find(m => m.id === selectedMethod)?.available}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 
                         disabled:cursor-not-allowed rounded-lg transition-colors"
              >
                Export with {exportMethods.find(m => m.id === selectedMethod)?.name}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
} 