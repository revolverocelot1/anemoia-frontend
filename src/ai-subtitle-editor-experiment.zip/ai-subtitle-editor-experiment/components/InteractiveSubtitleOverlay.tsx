import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Move, Maximize2, Type, Palette } from 'lucide-react';
import type { SubtitleSegment } from '../../types/subtitle';

interface InteractiveSubtitleOverlayProps {
  segments: SubtitleSegment[];
  currentTime: number;
  videoWidth: number;
  videoHeight: number;
  style?: {
    fontSize?: number;
    fontFamily?: string;
    color?: string;
    backgroundColor?: string;
    backgroundOpacity?: number;
    strokeColor?: string;
    strokeWidth?: number;
    position?: { x: number; y: number };
    padding?: number;
    borderRadius?: number;
  };
  onStyleChange?: (style: any) => void;
}

export const InteractiveSubtitleOverlay: React.FC<InteractiveSubtitleOverlayProps> = React.memo(({
  segments,
  currentTime,
  videoWidth,
  videoHeight,
  style = {},
  onStyleChange
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [position, setPosition] = useState(style.position || { x: 50, y: 85 });
  const [fontSize, setFontSize] = useState(style.fontSize || 24);
  const [backgroundColor, setBackgroundColor] = useState(style.backgroundColor || '#000000');
  const [backgroundOpacity, setBackgroundOpacity] = useState(style.backgroundOpacity ?? 0.75);
  const [textColor, setTextColor] = useState(style.color || '#FFFFFF');
  const [padding, setPadding] = useState(style.padding || 12);
  const [borderRadius, setBorderRadius] = useState(style.borderRadius || 4);
  const [showBackground, setShowBackground] = useState(true);
  
  // Sync with prop changes
  useEffect(() => {
    if (style.fontSize !== undefined) setFontSize(style.fontSize);
    if (style.color !== undefined) setTextColor(style.color);
    if (style.backgroundColor !== undefined) setBackgroundColor(style.backgroundColor);
    if (style.backgroundOpacity !== undefined) setBackgroundOpacity(style.backgroundOpacity);
    if (style.padding !== undefined) setPadding(style.padding);
    if (style.borderRadius !== undefined) setBorderRadius(style.borderRadius);
    if (style.position !== undefined) setPosition(style.position);
  }, [style]);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const dragStartPos = useRef({ x: 0, y: 0 });
  
  // Get current subtitle
  const currentSegment = segments.find(
      segment => currentTime >= segment.startTime && currentTime <= segment.endTime
    );
  
  // Update parent with style changes
  const previousStyleRef = useRef<any>({});
  
  useEffect(() => {
    const newStyle = {
      fontSize,
      color: textColor,
      backgroundColor,
      backgroundOpacity,
      position,
      padding,
      borderRadius
    };
    
    // Only call onStyleChange if the style has actually changed
    const hasChanged = JSON.stringify(newStyle) !== JSON.stringify(previousStyleRef.current);
    
    if (onStyleChange && hasChanged) {
      previousStyleRef.current = newStyle;
      onStyleChange(newStyle);
    }
  }, [fontSize, textColor, backgroundColor, backgroundOpacity, position, padding, borderRadius]);
  
  // Handle dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isDragging && !isResizing) return;
    
    // Get video element bounds
    const videoContainer = containerRef.current?.parentElement;
    if (!videoContainer) return;
    
    const videoBounds = videoContainer.getBoundingClientRect();
    const startMouseX = e.clientX;
    const startMouseY = e.clientY;
    const startPosX = position.x;
    const startPosY = position.y;
    
    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - startMouseX;
      const deltaY = e.clientY - startMouseY;
      
      // Convert pixel movement to percentage of video dimensions
      const newX = startPosX + (deltaX / videoBounds.width) * 100;
      const newY = startPosY + (deltaY / videoBounds.height) * 100;
      
      // Constrain within video bounds (0-100%)
      setPosition({
        x: Math.max(10, Math.min(90, newX)), // Keep 10% margin from edges
        y: Math.max(10, Math.min(90, newY))
      });
    };
    
    const handleMouseUp = () => {
      setIsDragging(false);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };
  
  if (!currentSegment) return null;
  
  return (
    <>
      {/* Controls Panel */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: showControls ? 1 : 0, y: showControls ? 0 : -20 }}
        className="absolute top-4 left-4 bg-gray-900 rounded-lg p-4 shadow-xl"
        style={{ 
          pointerEvents: showControls ? 'auto' : 'none',
          zIndex: showControls ? 50 : -1
        }}
      >
        <h3 className="text-white font-semibold mb-3">Subtitle Style</h3>
        
        <div className="space-y-3">
          {/* Font Size */}
          <div>
            <label className="text-gray-300 text-sm">Font Size</label>
            <input
              type="range"
              min="12"
              max="48"
              value={fontSize}
              onChange={(e) => setFontSize(Number(e.target.value))}
              className="w-full"
            />
            <span className="text-gray-400 text-xs">{fontSize}px</span>
          </div>
          
          {/* Text Color */}
          <div>
            <label className="text-gray-300 text-sm">Text Color</label>
            <div className="flex gap-2 items-center">
              <input
                type="color"
                value={textColor}
                onChange={(e) => setTextColor(e.target.value)}
                className="w-8 h-8 rounded cursor-pointer"
              />
              <input
                type="text"
                value={textColor}
                onChange={(e) => setTextColor(e.target.value)}
                className="bg-gray-800 text-white px-2 py-1 rounded text-sm flex-1"
              />
            </div>
          </div>
          
          {/* Background Toggle */}
          <div>
            <label className="text-gray-300 text-sm flex items-center gap-2">
              <input
                type="checkbox"
                checked={showBackground}
                onChange={(e) => setShowBackground(e.target.checked)}
                className="rounded"
              />
              Show Background
            </label>
          </div>
          
          {/* Background Settings */}
          {showBackground && (
            <>
              <div>
                <label className="text-gray-300 text-sm">Background Color</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="color"
                    value={backgroundColor}
                    onChange={(e) => setBackgroundColor(e.target.value)}
                    className="w-8 h-8 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={backgroundColor}
                    onChange={(e) => setBackgroundColor(e.target.value)}
                    className="bg-gray-800 text-white px-2 py-1 rounded text-sm flex-1"
                  />
                </div>
              </div>
              
              <div>
                <label className="text-gray-300 text-sm">Background Opacity</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={backgroundOpacity * 100}
                  onChange={(e) => setBackgroundOpacity(Number(e.target.value) / 100)}
                  className="w-full"
                />
                <span className="text-gray-400 text-xs">{Math.round(backgroundOpacity * 100)}%</span>
              </div>
              
              <div>
                <label className="text-gray-300 text-sm">Padding</label>
                <input
                  type="range"
                  min="0"
                  max="32"
                  value={padding}
                  onChange={(e) => setPadding(Number(e.target.value))}
                  className="w-full"
                />
                <span className="text-gray-400 text-xs">{padding}px</span>
              </div>
              
              <div>
                <label className="text-gray-300 text-sm">Border Radius</label>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={borderRadius}
                  onChange={(e) => setBorderRadius(Number(e.target.value))}
                  className="w-full"
                />
                <span className="text-gray-400 text-xs">{borderRadius}px</span>
              </div>
            </>
          )}
          
          {/* Position Controls */}
          <div className="pt-2 border-t border-gray-700">
            <button
              onClick={() => setIsDragging(!isDragging)}
              className={`px-3 py-1 rounded text-sm flex items-center gap-2 ${
                isDragging ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300'
              }`}
            >
              <Move className="w-4 h-4" />
              {isDragging ? 'Click to place' : 'Move subtitle'}
            </button>
          </div>
        </div>
      </motion.div>
      
      {/* Control Toggle Button */}
      <button
        onClick={() => setShowControls(!showControls)}
        className="absolute top-4 right-4 bg-gray-900 hover:bg-gray-800 text-white p-2 rounded-lg shadow-lg"
        style={{ zIndex: 45 }}
      >
        <Palette className="w-5 h-5" />
      </button>
      
      {/* Subtitle Display */}
      <motion.div
        ref={containerRef}
        className="absolute"
        style={{
          left: `${position.x}%`,
          top: `${position.y}%`,
          transform: 'translate(-50%, -50%)',
          cursor: isDragging ? 'move' : 'default',
          pointerEvents: isDragging || showControls ? 'auto' : 'none',
          zIndex: showControls ? 45 : 10
        }}
        onMouseDown={isDragging ? handleMouseDown : undefined}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div
          className="text-center"
          style={{
            fontSize: `${fontSize}px`,
            color: textColor,
            backgroundColor: showBackground && backgroundOpacity > 0 ? `${backgroundColor}${Math.round(backgroundOpacity * 255).toString(16).padStart(2, '0')}` : 'transparent',
            padding: showBackground && backgroundOpacity > 0 ? `${padding}px ${padding * 1.5}px` : 0,
            borderRadius: showBackground && backgroundOpacity > 0 ? `${borderRadius}px` : 0,
            textShadow: (!showBackground || backgroundOpacity === 0) ? '2px 2px 4px rgba(0,0,0,0.8)' : 'none',
            backdropFilter: showBackground && backgroundOpacity > 0 ? 'blur(4px)' : 'none',
            WebkitBackdropFilter: showBackground && backgroundOpacity > 0 ? 'blur(4px)' : 'none'
          }}
        >
          <div style={{ opacity: showBackground ? 1 : 1 }}>
            {currentSegment.text}
          </div>
        </div>
        
        {/* Position indicator when dragging */}
        {isDragging && (
          <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
            X: {Math.round(position.x)}% Y: {Math.round(position.y)}%
          </div>
        )}
        </motion.div>
    </>
  );
});

InteractiveSubtitleOverlay.displayName = 'InteractiveSubtitleOverlay'; 