import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, FileVideo, Loader2, AlertCircle, CheckCircle } from 'lucide-react';

interface BurnProgressModalProps {
  isOpen: boolean;
  progress: number;
  status: string;
  format: 'webm' | 'mp4';
  onCancel: () => void;
}

export const BurnProgressModal: React.FC<BurnProgressModalProps> = ({
  isOpen,
  progress,
  status,
  format,
  onCancel
}) => {
  // Determine if there's an error
  const isError = progress === -1;
  const isComplete = progress === 100;
  
  // Calculate estimated time remaining
  const getEstimatedTime = () => {
    if (progress <= 0 || progress >= 100) return null;
    if (progress < 20) return 'Calculating...';
    
    // Simple estimation based on progress
    const secondsPerPercent = 0.5; // Adjust based on testing
    const remainingPercent = 100 - progress;
    const remainingSeconds = Math.ceil(remainingPercent * secondsPerPercent);
    
    if (remainingSeconds < 60) return `${remainingSeconds}s`;
    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    return `${minutes}m ${seconds}s`;
  };
  
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[60]"
            onClick={isError ? onCancel : undefined}
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md z-[61]"
          >
            <div className="bg-gray-900 rounded-lg shadow-2xl border border-gray-800 p-6">
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <FileVideo className="w-5 h-5 text-purple-500" />
                  {isComplete ? 'Export Complete' : `Exporting to ${format.toUpperCase()}`}
                </h3>
                {(isError || isComplete) && (
                  <button
                    onClick={onCancel}
                    className="p-1 hover:bg-gray-800 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-gray-400" />
                  </button>
                )}
              </div>
              
              {/* Progress */}
              <div className="space-y-4">
                {/* Status and Progress */}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400 flex-1 mr-2">
                    {isError ? (
                      <span className="text-red-400 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4" />
                        {status}
                      </span>
                    ) : isComplete ? (
                      <span className="text-green-400 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        {status}
                      </span>
                    ) : (
                      status
                    )}
                  </span>
                  {!isError && (
                    <span className="text-2xl font-bold text-white">{Math.round(progress)}%</span>
                  )}
                </div>
                
                {/* Progress bar */}
                {!isError && (
                  <div className="relative h-3 bg-gray-800 rounded-full overflow-hidden">
                    <motion.div
                      className={`absolute inset-y-0 left-0 rounded-full ${
                        isComplete 
                          ? 'bg-gradient-to-r from-green-500 to-green-600' 
                          : 'bg-gradient-to-r from-purple-500 to-pink-500'
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      transition={{ duration: 0.3 }}
                    />
                    
                    {/* Animated shimmer */}
                    {!isComplete && progress > 0 && progress < 100 && (
                      <motion.div
                        className="absolute inset-y-0 w-32 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                        animate={{ x: [-128, 512] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      />
                    )}
                  </div>
                )}
                
                {/* Stats */}
                {!isError && !isComplete && (
                  <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-800">
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Format</div>
                      <div className="text-sm font-medium text-white uppercase">{format}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Quality</div>
                      <div className="text-sm font-medium text-white">High</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Est. Time</div>
                      <div className="text-sm font-medium text-white">
                        {getEstimatedTime() || '...'}
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Processing indicator */}
                {!isError && !isComplete && progress > 0 && progress < 100 && (
                  <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing with hardware acceleration...
                  </div>
                )}
                
                {/* Success message */}
                {isComplete && (
                  <div className="bg-green-900/20 border border-green-700 rounded-lg p-3 mt-4">
                    <p className="text-sm text-green-400">
                      Your video has been successfully exported with burned subtitles!
                    </p>
                  </div>
                )}
              </div>
              
              {/* Actions */}
              <div className="mt-6 flex justify-end gap-3">
                {isError || isComplete ? (
                  <button
                    onClick={onCancel}
                    className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
                  >
                    Close
                  </button>
                ) : (
                  <button
                    onClick={onCancel}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                  >
                    Cancel Export
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default BurnProgressModal; 