import React, { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mic, MicOff, Download, Play, Pause, RefreshCw, 
  ChevronDown, Globe, Zap, AlertCircle, CheckCircle,
  Settings, X, Upload, Loader, Check
} from 'lucide-react';
import { useSubtitleStore } from '../../stores/subtitle-store';
import { WHISPER_MODELS, type WhisperModel } from '../../config/whisper-models';
import { whisperLoader } from '../../lib/whisper-loader';
import type { SubtitleSegment } from '../../types/subtitle';
import type { ProgressMessage, ResultMessage, ErrorMessage } from '../../workers/whisper.worker';
import CompactLoadingBar from './CompactLoadingBar';
import TranscriptionLoadingOverlay from './TranscriptionLoadingOverlay';
import type { SubtitleState } from '../../types/subtitle';
import debounce from 'lodash/debounce';

interface TranscriptionPanelProps {
  audioBuffer?: AudioBuffer | null;
  onTranscriptionComplete?: (segments: SubtitleSegment[]) => void;
  className?: string;
}

export const TranscriptionPanel: React.FC<TranscriptionPanelProps> = ({
  audioBuffer,
  onTranscriptionComplete,
  className = ''
}) => {
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [status, setStatus] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState<string>('whisper-base');
  const [isModelLoaded, setIsModelLoaded] = useState<boolean>(false);
  const [isLoadingModel, setIsLoadingModel] = useState<boolean>(false);
  const [language, setLanguage] = useState<string>('auto');
  const [task, setTask] = useState<'transcribe' | 'translate'>('transcribe');
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [downloadedModels, setDownloadedModels] = useState<Set<string>>(new Set());
  const [showModelLoadedModal, setShowModelLoadedModal] = useState(false);
  
  // Use store selectors
  const {
    currentProject,
    activeTrackId,
    importSegments,
    selectedModel: storeSelectedModel,
    setSelectedModel: storeSetSelectedModel,
    isTranscribing: storeIsTranscribing,
    setIsTranscribing: storeSetIsTranscribing
  } = useSubtitleStore();
  
  // Create ref for worker handler to avoid re-renders
  const workerHandlerRef = useRef<((event: MessageEvent) => void) | null>(null);
  
  // Initialize worker
  useEffect(() => {
    workerHandlerRef.current = handleWorkerMessage;
    
    // Check cached models
    checkCachedModels();
    
    return () => {
      if (workerHandlerRef.current) {
        whisperLoader.removeMessageListener(workerHandlerRef.current);
      }
    };
  }, []);
  
  // Check which models are cached
  const checkCachedModels = async (): Promise<void> => {
    try {
      const cache = await caches.open('transformers-cache');
      const keys = await cache.keys();
      const cached = new Set<string>();
      
      keys.forEach((request: Request) => {
        WHISPER_MODELS.forEach((model: WhisperModel) => {
          if (request.url.includes(model.id)) {
            cached.add(model.id);
          }
        });
      });
      
      setDownloadedModels(cached);
    } catch (error: unknown) {
      console.error('Failed to check cached models:', error);
    }
  };
  
  // Handle worker messages
  const handleWorkerMessage = useCallback((event: MessageEvent<any>) => {
    const message = event.data as ProgressMessage | ResultMessage | ErrorMessage;
    
    switch (message.type) {
      case 'progress':
        setProgress(message.progress);
        setStatus(message.status);
        
        // Check if model loading is complete
        if (message.progress === 100 && message.status.toLowerCase().includes('successfully')) {
          setIsModelLoaded(true);
          setIsLoadingModel(false);
        }
        break;
        
      case 'result':
        handleTranscriptionResult(message);
        break;
        
      case 'error':
        setError(message.error);
        setIsTranscribing(false);
        storeSetIsTranscribing(false);
        setIsLoadingModel(false);
        break;
    }
  }, [storeSetIsTranscribing]);
  
  // Initialize and check model loading
  useEffect(() => {
    // Check if model is already loaded
    if (whisperLoader.isModelLoaded(selectedModel)) {
      setIsModelLoaded(true);
      console.log('[TranscriptionPanel] Model already loaded:', selectedModel);
    } else {
      const currentLoadedModel = whisperLoader.getLoadedModel();
      if (currentLoadedModel) {
        setSelectedModel(currentLoadedModel);
        setIsModelLoaded(true);
        console.log('[TranscriptionPanel] Using preloaded model:', currentLoadedModel);
      }
    }
  }, [selectedModel]);
  
  // Handle transcription result
  const handleTranscriptionResult = useCallback((result: ResultMessage) => {
    setIsTranscribing(false);
    storeSetIsTranscribing(false);
    setProgress(100);
    
    console.log('[TranscriptionPanel] Transcription result:', result);
    
    // Import segments to active track
    if (result.segments && result.segments.length > 0) {
      const { currentProject, activeTrackId, addSegments } = useSubtitleStore.getState();
      
      if (currentProject && activeTrackId) {
        // Format segments properly for the store
        const segments = result.segments.map((seg, index) => ({
          id: `segment-${Date.now()}-${index}`,
          text: seg.text.trim(),
          startTime: seg.start || 0,
          endTime: seg.end || seg.start + 1,
          style: {},
          confidence: seg.confidence || 0.9
        }));
        
        console.log('[TranscriptionPanel] Importing', segments.length, 'segments to track:', activeTrackId);
        
        // Import segments
        addSegments(activeTrackId, segments);
        
        if (onTranscriptionComplete) {
          onTranscriptionComplete(segments);
        }
        
        // Show success message
        setStatus(`Transcription complete! ${segments.length} segments created`);
        
        // Clear progress after a delay
        setTimeout(() => {
          setProgress(0);
          setStatus('');
        }, 3000);
        
      } else {
        setError('Cannot import segments - no active project or track');
        setStatus('Transcription complete but could not import segments');
      }
    } else {
      setError('No segments were generated from the transcription');
      setStatus('Transcription failed');
    }
  }, [onTranscriptionComplete, storeSetIsTranscribing]);
  
  // Load model
  const loadModel = useCallback(async () => {
    if (isLoadingModel || whisperLoader.isModelLoaded(selectedModel)) return;
    
    setIsLoadingModel(true);
    setError(null);
    setStatus('Loading model...');
    setProgress(0);
    
    try {
      await whisperLoader.loadModel(selectedModel);
      setIsModelLoaded(true);
      setStatus('Model loaded successfully');
      setProgress(100);
      
      // Clear status after delay
      setTimeout(() => {
        setStatus('');
        setProgress(0);
      }, 2000);
    } catch (error: any) {
      console.error('[TranscriptionPanel] Model load error:', error);
      setError(`Failed to load model: ${error.message || error}`);
      setIsModelLoaded(false);
    } finally {
      setIsLoadingModel(false);
    }
  }, [selectedModel, isLoadingModel]);
  
  // Ensure project and track exist
  const ensureProjectAndTrack = useCallback(() => {
    const store = useSubtitleStore.getState();
    
    // If no project, create one
    if (!store.currentProject) {
      console.log('[TranscriptionPanel] Creating new project');
      store.createProject({
        name: 'Transcription Project',
        videoUrl: undefined,
        videoName: 'Transcription'
      });
    }
    
    const updatedStore = useSubtitleStore.getState();
    if (!updatedStore.currentProject) {
      console.error('[TranscriptionPanel] Failed to create project');
      return false;
    }
    
    const project = updatedStore.currentProject;
    
    // If no tracks, create one
    if (!project.tracks || project.tracks.length === 0) {
      console.log('[TranscriptionPanel] Creating new track');
      const newTrackId = `track-${Date.now()}`;
      useSubtitleStore.setState((state) => {
        if (state.currentProject) {
          const newTrack = {
            id: newTrackId,
            name: 'Track 1',
            language: language === 'auto' ? 'en' : language,
            segments: [],
            isVisible: true,
            isLocked: false,
            style: {}
          };
          state.currentProject.tracks.push(newTrack);
          state.activeTrackId = newTrackId;
          state.currentProject.activeTrackId = newTrackId;
        }
      });
    }
    
    const finalStore = useSubtitleStore.getState();
    if (!finalStore.activeTrackId && finalStore.currentProject?.tracks && finalStore.currentProject.tracks.length > 0) {
      const firstTrack = finalStore.currentProject.tracks[0];
      console.log('[TranscriptionPanel] Setting active track:', firstTrack.id);
      useSubtitleStore.setState((state) => {
        state.activeTrackId = firstTrack.id;
        if (state.currentProject) {
          state.currentProject.activeTrackId = firstTrack.id;
        }
      });
    }
    
    if (finalStore.currentProject && finalStore.activeTrackId) {
      console.log('[TranscriptionPanel] Project and track ready:', {
        projectId: finalStore.currentProject.id,
        projectName: finalStore.currentProject.name,
        activeTrackId: finalStore.activeTrackId,
        tracksCount: finalStore.currentProject.tracks?.length || 0
      });
      return true;
    }
    
    console.error('[TranscriptionPanel] Failed to ensure project and track');
    return false;
  }, [language]);

  // Start transcription - REAL TRANSCRIPTION ONLY
  const startTranscription = useCallback(async () => {
    if (!audioBuffer) {
      setError('No audio available for transcription. Please select a video with audio.');
      return;
    }
    
    if (!whisperLoader.isModelLoaded(selectedModel)) {
      setError('Please load the model first');
      return;
    }
    
    // Ensure project and track exist
    const ready = ensureProjectAndTrack();
    if (!ready) {
      setError('Failed to create project or track for transcription');
      return;
    }
    
    setIsTranscribing(true);
    storeSetIsTranscribing(true);
    setError(null);
    setProgress(0);
    setStatus('Preparing audio for transcription...');
    
    try {
      // Convert AudioBuffer to Float32Array for the worker
      const audioData = audioBuffer.getChannelData(0);
      
      console.log('[TranscriptionPanel] Starting transcription with:', {
        sampleRate: audioBuffer.sampleRate,
        duration: audioBuffer.duration,
        channels: audioBuffer.numberOfChannels,
        dataLength: audioData.length,
        model: selectedModel,
        language: language
      });
      
      // Send to worker for REAL transcription
      whisperLoader.transcribe(audioData, {
        language: language === 'auto' ? undefined : language,
        task: task,
        return_timestamps: true,
        chunk_length_s: 30,
        stride_length_s: 5
      });
      
      setStatus('Processing audio with Whisper AI...');
    } catch (error: any) {
      console.error('[TranscriptionPanel] Transcription error:', error);
      setError(`Failed to start transcription: ${error.message || error}`);
      setIsTranscribing(false);
      storeSetIsTranscribing(false);
    }
  }, [audioBuffer, selectedModel, language, task, storeSetIsTranscribing, ensureProjectAndTrack]);
  
  // Cancel transcription
  const cancelTranscription = useCallback(() => {
    whisperLoader.cancelTranscription();
    setIsTranscribing(false);
    storeSetIsTranscribing(false);
    setProgress(0);
    setStatus('Transcription cancelled');
  }, [storeSetIsTranscribing]);
  
  // Get model info
  const getModelInfo = (modelId: string): WhisperModel | undefined => {
    return WHISPER_MODELS.find(m => m.id === modelId);
  };
  
  const selectedModelInfo = getModelInfo(selectedModel);
  
  return (
    <>
      {/* Model Loaded Confirmation Modal */}
      <AnimatePresence>
        {showModelLoadedModal && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none"
          >
            <motion.div
              initial={{ y: 20 }}
              animate={{ y: 0 }}
              exit={{ y: 20 }}
              className="bg-green-900/95 backdrop-blur-sm text-white p-8 rounded-2xl shadow-2xl flex flex-col items-center gap-4 max-w-md pointer-events-auto"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              >
                <CheckCircle className="w-20 h-20 text-green-400" />
              </motion.div>
              <h3 className="text-2xl font-bold">Model Loaded Successfully!</h3>
              <p className="text-center text-green-200">
                {selectedModel} is ready for transcription
              </p>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: "100%" }}
                transition={{ duration: 3 }}
                className="h-1 bg-green-400 rounded-full"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Compact Loading Bar */}
      <CompactLoadingBar
        isLoading={isLoadingModel || isTranscribing}
        progress={progress}
        status={status}
        type={isLoadingModel ? 'model' : 'transcription'}
        error={error}
      />
      
      <div className={`bg-gray-900 rounded-lg p-6 ${className}`}>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <Mic className="w-5 h-5 text-cyan-500" />
            AI Transcription
          </h3>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-400" />
          </motion.button>
        </div>
        
        {/* Model Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Whisper Model
          </label>
          <div className="relative">
            <select
              value={selectedModel}
              onChange={(e) => {
                setSelectedModel(e.target.value);
              }}
              className="w-full bg-gray-800 text-white px-4 py-2 pr-10 rounded-lg border border-gray-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none appearance-none"
              disabled={isTranscribing || isLoadingModel}
            >
              {WHISPER_MODELS.map((model) => (
                <option key={model.id} value={model.id}>
                  {model.name} ({model.size})
                  {downloadedModels.has(model.id) ? ' ✓' : ''}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          </div>
          
          {selectedModelInfo && (
            <div className="mt-2 text-xs text-gray-500">
              {selectedModelInfo.description || `${selectedModelInfo.name} model for speech recognition`}
              {selectedModelInfo.quantized && (
                <span className="ml-2 text-yellow-500">
                  <Zap className="w-3 h-3 inline mr-1" />
                  Quantized (faster)
                </span>
              )}
            </div>
          )}
        </div>
        
        {/* Settings Panel */}
        <AnimatePresence>
          {showSettings && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6 p-4 bg-gray-800 rounded-lg"
            >
              {/* Language Selection */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Language
                </label>
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-gray-400" />
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="flex-1 bg-gray-700 text-white px-3 py-1.5 rounded border border-gray-600 focus:border-cyan-500 outline-none text-sm"
                    disabled={isTranscribing}
                  >
                    <option value="auto">Auto-detect</option>
                    <option value="en">English</option>
                    <option value="es">Spanish</option>
                    <option value="fr">French</option>
                    <option value="de">German</option>
                    <option value="it">Italian</option>
                    <option value="pt">Portuguese</option>
                    <option value="ru">Russian</option>
                    <option value="ja">Japanese</option>
                    <option value="ko">Korean</option>
                    <option value="zh">Chinese</option>
                  </select>
                </div>
              </div>
              
              {/* Task Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Task
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setTask('transcribe')}
                    className={`flex-1 px-3 py-1.5 rounded text-sm transition-colors ${
                      task === 'transcribe'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    }`}
                    disabled={isTranscribing}
                  >
                    Transcribe
                  </button>
                  <button
                    onClick={() => setTask('translate')}
                    className={`flex-1 px-3 py-1.5 rounded text-sm transition-colors ${
                      task === 'translate'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    }`}
                    disabled={isTranscribing}
                  >
                    Translate to English
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Action Buttons */}
        <div className="flex gap-3 mb-6">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={loadModel}
            disabled={isLoadingModel || isTranscribing}
            className={`flex-1 ${
              isLoadingModel
                ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                : isModelLoaded
                ? 'bg-green-600 hover:bg-green-700 text-white shadow-lg'
                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg'
            } px-4 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2`}
          >
            {isLoadingModel ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                Loading Model...
              </>
            ) : isModelLoaded ? (
              <>
                <CheckCircle className="w-5 h-5" />
                Model Loaded
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                Load Model
              </>
            )}
          </motion.button>
          
          {!isTranscribing ? (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={startTranscription}
              disabled={!audioBuffer || !isModelLoaded || isLoadingModel}
              className={`flex-1 ${
                !audioBuffer || !isModelLoaded
                  ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white shadow-lg'
              } px-4 py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2`}
            >
              <Play className="w-5 h-5" />
              Transcribe
            </motion.button>
          ) : (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={cancelTranscription}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2 shadow-lg"
            >
              <X className="w-5 h-5" />
              Cancel
            </motion.button>
          )}
        </div>
        
        {/* Status hints */}
        {!audioBuffer && (
          <div className="mb-4 p-3 bg-blue-900/20 border border-blue-700 rounded-lg">
            <p className="text-sm text-blue-400">
              💡 Load a video file first to enable AI transcription
            </p>
          </div>
        )}
        
        {audioBuffer && !isModelLoaded && !isLoadingModel && (
          <div className="mb-4 p-3 bg-yellow-900/20 border border-yellow-700 rounded-lg">
            <p className="text-sm text-yellow-400">
              ⚡ Load the AI model before transcribing
            </p>
          </div>
        )}
        
        {/* Progress Bar */}
        {(isTranscribing || isLoadingModel || progress > 0) && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">{status}</span>
              <span className="text-sm text-gray-400">{Math.round(progress)}%</span>
            </div>
            <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden">
              <motion.div
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-500 to-cyan-600"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>
        )}
        
        {/* Error Display */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-4 p-3 bg-red-900/20 border border-red-700 rounded-lg flex items-start gap-2"
            >
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-400">{error}</p>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Info */}
        {!audioBuffer && !isTranscribing && (
          <div className="text-center py-8 text-gray-500">
            <MicOff className="w-12 h-12 mx-auto mb-3 text-gray-700" />
            <p className="text-sm">No audio available</p>
            <p className="text-xs mt-1">Load a video file to enable transcription</p>
          </div>
        )}
      </div>
      
      {/* Loading Overlay */}
      <TranscriptionLoadingOverlay
        isVisible={isTranscribing || isLoadingModel}
        progress={progress}
        status={status}
        isLoadingModel={isLoadingModel}
      />
    </>
  );
};

export default TranscriptionPanel; 