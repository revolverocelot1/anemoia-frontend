import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { Maximize2, Minimize2, Move, X, Lock, Unlock, PictureInPicture2 } from 'lucide-react';
import VideoPreview from './VideoPreview';

interface ResizableVideoContainerProps {
  videoUrl?: string;
  videoFile?: File;
  onTimeUpdate?: (time: number) => void;
  onDurationChange?: (duration: number) => void;
  onClose?: () => void;
  className?: string;
  videoRef?: React.RefObject<HTMLVideoElement>;
  showPositioner?: boolean;
  onPositionerToggle?: () => void;
}

export const ResizableVideoContainer: React.FC<ResizableVideoContainerProps> = ({
  videoUrl,
  videoFile,
  onTimeUpdate,
  onDurationChange,
  onClose,
  className = '',
  videoRef,
  showPositioner,
  onPositionerToggle
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDocked, setIsDocked] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [isPiPMode, setIsPiPMode] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  
  // Position and size for floating mode
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [size, setSize] = useState({ width: 640, height: 360 });
  const [lastDockedSize, setLastDockedSize] = useState({ width: '100%', height: '100%' });
  
  // Resize handle refs
  const resizeStartX = useRef(0);
  const resizeStartY = useRef(0);
  const resizeStartWidth = useRef(0);
  const resizeStartHeight = useRef(0);
  const resizeEdge = useRef<string>('');
  
  // Local state only - store integration could be added later
  
  // Handle drag
  const handleDragStart = useCallback(() => {
    if (!isLocked && !isDocked) {
      setIsDragging(true);
    }
  }, [isLocked, isDocked]);
  
  const handleDrag = useCallback((event: any, info: PanInfo) => {
    if (!isLocked && !isDocked) {
      setPosition({
        x: position.x + info.delta.x,
        y: position.y + info.delta.y
      });
    }
  }, [isLocked, isDocked, position]);
  
  const handleDragEnd = useCallback(() => {
    setIsDragging(false);
    
    // Snap to edges if close
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;
    const snapThreshold = 20;
    
    let newX = position.x;
    let newY = position.y;
    
    if (position.x < snapThreshold) newX = 0;
    if (position.x + size.width > windowWidth - snapThreshold) newX = windowWidth - size.width;
    if (position.y < snapThreshold) newY = 0;
    if (position.y + size.height > windowHeight - snapThreshold) newY = windowHeight - size.height;
    
    if (newX !== position.x || newY !== position.y) {
      setPosition({ x: newX, y: newY });
    }
  }, [position, size]);
  
  // Handle resize
  const handleResizeStart = useCallback((e: React.MouseEvent, edge: string) => {
    if (!isLocked && !isDocked) {
      e.preventDefault();
      e.stopPropagation();
      setIsResizing(true);
      resizeStartX.current = e.clientX;
      resizeStartY.current = e.clientY;
      resizeStartWidth.current = size.width;
      resizeStartHeight.current = size.height;
      resizeEdge.current = edge;
    }
  }, [isLocked, isDocked, size]);
  
  const handleResizeMove = useCallback((e: MouseEvent) => {
    if (!isResizing) return;
    
    const deltaX = e.clientX - resizeStartX.current;
    const deltaY = e.clientY - resizeStartY.current;
    const edge = resizeEdge.current;
    
    let newWidth = resizeStartWidth.current;
    let newHeight = resizeStartHeight.current;
    let newX = position.x;
    let newY = position.y;
    
    // Calculate new dimensions based on resize edge
    if (edge.includes('right')) {
      newWidth = Math.max(320, resizeStartWidth.current + deltaX);
    }
    if (edge.includes('left')) {
      newWidth = Math.max(320, resizeStartWidth.current - deltaX);
      newX = position.x + (resizeStartWidth.current - newWidth);
    }
    if (edge.includes('bottom')) {
      newHeight = Math.max(180, resizeStartHeight.current + deltaY);
    }
    if (edge.includes('top')) {
      newHeight = Math.max(180, resizeStartHeight.current - deltaY);
      newY = position.y + (resizeStartHeight.current - newHeight);
    }
    
    // Maintain aspect ratio if shift is held
    if (e.shiftKey) {
      const aspectRatio = 16 / 9;
      if (edge.includes('right') || edge.includes('left')) {
        newHeight = newWidth / aspectRatio;
      } else {
        newWidth = newHeight * aspectRatio;
      }
    }
    
    setSize({ width: newWidth, height: newHeight });
    setPosition({ x: newX, y: newY });
  }, [isResizing, position]);
  
  const handleResizeEnd = useCallback(() => {
    setIsResizing(false);
    resizeEdge.current = '';
  }, []);
  
  // Set up resize event listeners
  useEffect(() => {
    if (isResizing) {
      window.addEventListener('mousemove', handleResizeMove);
      window.addEventListener('mouseup', handleResizeEnd);
      return () => {
        window.removeEventListener('mousemove', handleResizeMove);
        window.removeEventListener('mouseup', handleResizeEnd);
      };
    }
  }, [isResizing, handleResizeMove, handleResizeEnd]);
  
  // Toggle docked/floating
  const toggleDocked = useCallback(() => {
    if (isDocked) {
      // Store current docked size
      if (containerRef.current) {
        setLastDockedSize({
          width: containerRef.current.style.width || '100%',
          height: containerRef.current.style.height || '100%'
        });
      }
      // Center the floating window
      setPosition({
        x: (window.innerWidth - size.width) / 2,
        y: (window.innerHeight - size.height) / 2
      });
    }
    setIsDocked(!isDocked);
    setIsMinimized(false);
  }, [isDocked, size]);
  
  // Toggle minimize
  const toggleMinimize = useCallback(() => {
    setIsMinimized(!isMinimized);
  }, [isMinimized]);
  
  // Toggle lock
  const toggleLock = useCallback(() => {
    setIsLocked(!isLocked);
  }, [isLocked]);
  
  // Toggle PiP mode
  const togglePiP = useCallback(() => {
    if (!isPiPMode) {
      // Move to bottom right corner
      setPosition({
        x: window.innerWidth - 320 - 20,
        y: window.innerHeight - 180 - 20
      });
      setSize({ width: 320, height: 180 });
      setIsDocked(false);
      setIsMinimized(false);
    }
    setIsPiPMode(!isPiPMode);
  }, [isPiPMode]);
  
  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isDocked) {
        setIsDocked(true);
      }
    };
    
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isDocked]);
  
  // Render resize handles
  const renderResizeHandles = () => {
    if (isDocked || isLocked || isMinimized) return null;
    
    const handles = [
      { edge: 'top', className: 'top-0 left-4 right-4 h-1 cursor-ns-resize' },
      { edge: 'right', className: 'right-0 top-4 bottom-4 w-1 cursor-ew-resize' },
      { edge: 'bottom', className: 'bottom-0 left-4 right-4 h-1 cursor-ns-resize' },
      { edge: 'left', className: 'left-0 top-4 bottom-4 w-1 cursor-ew-resize' },
      { edge: 'top-left', className: 'top-0 left-0 w-4 h-4 cursor-nw-resize' },
      { edge: 'top-right', className: 'top-0 right-0 w-4 h-4 cursor-ne-resize' },
      { edge: 'bottom-left', className: 'bottom-0 left-0 w-4 h-4 cursor-sw-resize' },
      { edge: 'bottom-right', className: 'bottom-0 right-0 w-4 h-4 cursor-se-resize' }
    ];
    
    return handles.map(({ edge, className }) => (
      <div
        key={edge}
        className={`absolute ${className} hover:bg-cyan-500/50 transition-colors`}
        onMouseDown={(e) => handleResizeStart(e, edge)}
      />
    ));
  };
  
  const containerStyles = isDocked
    ? { 
        width: '100%', 
        height: '100%',
        minHeight: '400px',
        position: 'relative' as const
      }
    : {
        width: `${size.width}px`,
        height: isMinimized ? '40px' : `${size.height}px`,
        position: 'fixed' as const,
        left: `${position.x}px`,
        top: `${position.y}px`,
        zIndex: 50
      };
  
  console.log('[ResizableVideoContainer] Render state:', {
    isDocked,
    containerStyles,
    videoUrl,
    videoFile,
    dimensions: isDocked ? 'full' : `${size.width}x${size.height}`
  });
  
  return (
    <motion.div
      ref={containerRef}
      className={`${isDocked ? 'relative' : 'fixed'} bg-gray-900 rounded-lg overflow-hidden shadow-2xl ${
        isDragging ? 'cursor-move' : ''
      } ${isResizing ? 'select-none' : ''} ${isPiPMode ? 'ring-2 ring-cyan-500' : ''} ${className}`}
      style={containerStyles}
      drag={!isDocked && !isLocked && !isResizing}
      dragMomentum={false}
      onDragStart={handleDragStart}
      onDrag={handleDrag}
      onDragEnd={handleDragEnd}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ 
        opacity: 1, 
        scale: 1,
        transition: { type: 'spring', stiffness: 300, damping: 30 }
      }}
      exit={{ opacity: 0, scale: 0.9 }}
    >
      {/* Header Bar */}
      <div className={`absolute top-0 left-0 right-0 h-10 bg-gray-800 flex items-center justify-between px-3 ${
        !isDocked && !isLocked ? 'cursor-move' : ''
      }`}>
        <div className="flex items-center gap-2">
          <Move className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-300">Video Preview</span>
          {isPiPMode && (
            <span className="text-xs text-cyan-400 ml-2">[PiP Mode]</span>
          )}
        </div>
        
        <div className="flex items-center gap-1">
          {/* Lock/Unlock */}
          {!isDocked && (
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={toggleLock}
              className={`p-1.5 rounded transition-colors ${
                isLocked ? 'bg-red-600 text-white' : 'hover:bg-gray-700 text-gray-400'
              }`}
              title={isLocked ? 'Unlock' : 'Lock position'}
            >
              {isLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
            </motion.button>
          )}
          
          {/* PiP Mode */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={togglePiP}
            className={`p-1.5 rounded transition-colors ${
              isPiPMode ? 'bg-cyan-600 text-white' : 'hover:bg-gray-700 text-gray-400'
            }`}
            title="Picture-in-Picture mode"
          >
            <PictureInPicture2 className="w-3 h-3" />
          </motion.button>
          
          {/* Minimize */}
          {!isDocked && (
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={toggleMinimize}
              className="p-1.5 hover:bg-gray-700 rounded transition-colors"
              title={isMinimized ? 'Restore' : 'Minimize'}
            >
              <Minimize2 className="w-3 h-3 text-gray-400" />
            </motion.button>
          )}
          
          {/* Dock/Float */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleDocked}
            className="p-1.5 hover:bg-gray-700 rounded transition-colors"
            title={isDocked ? 'Float' : 'Dock'}
          >
            <Maximize2 className="w-3 h-3 text-gray-400" />
          </motion.button>
          
          {/* Close */}
          {onClose && (
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="p-1.5 hover:bg-red-600 rounded transition-colors"
              title="Close"
            >
              <X className="w-3 h-3 text-gray-400" />
            </motion.button>
          )}
        </div>
      </div>
      
      {/* Video Content */}
      <AnimatePresence>
        {!isMinimized && (
          <motion.div
            className="absolute top-10 left-0 right-0 bottom-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <VideoPreview
              videoUrl={videoUrl}
              videoFile={videoFile}
              onTimeUpdate={onTimeUpdate}
              onDurationChange={onDurationChange}
              showControls={!isPiPMode || !isDocked}
              className="w-full h-full"
              videoRef={videoRef}
              showPositioner={showPositioner}
              onPositionerToggle={onPositionerToggle}
            />
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Minimized View */}
      {isMinimized && !isDocked && (
        <div className="flex items-center justify-center h-full text-gray-400 text-sm">
          <span>Video Minimized</span>
        </div>
      )}
      
      {/* Resize Handles */}
      {renderResizeHandles()}
      
      {/* Size indicator while resizing */}
      <AnimatePresence>
        {isResizing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded"
          >
            {Math.round(size.width)} × {Math.round(size.height)}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default ResizableVideoContainer; 