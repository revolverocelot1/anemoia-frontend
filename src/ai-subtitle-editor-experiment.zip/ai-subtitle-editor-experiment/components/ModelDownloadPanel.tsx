import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Download, Trash2, HardDrive, Cloud, CheckCircle, 
  AlertCircle, Info, RefreshCw, Zap, Globe 
} from 'lucide-react';
import { WHISPER_MODELS } from '../../config/whisper-models';
import type { WhisperModel } from '../../config/whisper-models';

interface ModelDownloadPanelProps {
  onModelSelect?: (modelId: string) => void;
  className?: string;
}

interface ModelStatus {
  id: string;
  isDownloaded: boolean;
  isDownloading: boolean;
  downloadProgress: number;
  size: number;
  error?: string;
}

export const ModelDownloadPanel: React.FC<ModelDownloadPanelProps> = ({
  onModelSelect,
  className = ''
}) => {
  const [modelStatuses, setModelStatuses] = useState<Map<string, ModelStatus>>(new Map());
  const [totalCacheSize, setTotalCacheSize] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Check model cache status
  const checkModelStatus = useCallback(async () => {
    setIsRefreshing(true);
    
    try {
      const cache = await caches.open('transformers-cache');
      const keys = await cache.keys();
      const statuses = new Map<string, ModelStatus>();
      let totalSize = 0;
      
      // Initialize all models as not downloaded
      WHISPER_MODELS.forEach(model => {
        statuses.set(model.id, {
          id: model.id,
          isDownloaded: false,
          isDownloading: false,
          downloadProgress: 0,
          size: 0
        });
      });
      
      // Check which models are cached
      for (const request of keys) {
        for (const model of WHISPER_MODELS) {
          if (request.url.includes(model.id) || request.url.includes(model.modelPath)) {
            const response = await cache.match(request);
            if (response) {
              const blob = await response.blob();
              const size = blob.size;
              
              statuses.set(model.id, {
                id: model.id,
                isDownloaded: true,
                isDownloading: false,
                downloadProgress: 100,
                size: size
              });
              
              totalSize += size;
            }
          }
        }
      }
      
      setModelStatuses(statuses);
      setTotalCacheSize(totalSize);
    } catch (error) {
      console.error('Failed to check model cache:', error);
    } finally {
      setIsRefreshing(false);
    }
  }, []);
  
  // Initial check
  useEffect(() => {
    checkModelStatus();
  }, [checkModelStatus]);
  
  // Download model
  const downloadModel = async (modelId: string) => {
    const model = WHISPER_MODELS.find(m => m.id === modelId);
    if (!model) return;
    
    // Update status to downloading
    setModelStatuses(prev => {
      const newMap = new Map(prev);
      newMap.set(modelId, {
        ...newMap.get(modelId)!,
        isDownloading: true,
        downloadProgress: 0,
        error: undefined
      });
      return newMap;
    });
    
    try {
      // Create a dummy worker to trigger model download
      const worker = new Worker(
        new URL('../../workers/whisper.worker.ts', import.meta.url),
        { type: 'module' }
      );
      
      // Listen for progress updates
      worker.onmessage = (event) => {
        if (event.data.type === 'progress') {
          setModelStatuses(prev => {
            const newMap = new Map(prev);
            newMap.set(modelId, {
              ...newMap.get(modelId)!,
              downloadProgress: event.data.progress
            });
            return newMap;
          });
        }
      };
      
      // Request model load
      worker.postMessage({
        type: 'load-model',
        model: modelId,
        options: { cache: true }
      });
      
      // Wait for completion
      await new Promise<void>((resolve, reject) => {
        worker.onmessage = (event) => {
          if (event.data.type === 'progress' && event.data.progress === 100) {
            resolve();
          } else if (event.data.type === 'error') {
            reject(new Error(event.data.error));
          }
        };
        
        // Timeout after 10 minutes
        setTimeout(() => reject(new Error('Download timeout')), 600000);
      });
      
      // Terminate worker
      worker.terminate();
      
      // Refresh status
      await checkModelStatus();
      
    } catch (error) {
      setModelStatuses(prev => {
        const newMap = new Map(prev);
        newMap.set(modelId, {
          ...newMap.get(modelId)!,
          isDownloading: false,
          error: error instanceof Error ? error.message : 'Download failed'
        });
        return newMap;
      });
    }
  };
  
  // Delete model from cache
  const deleteModel = async (modelId: string) => {
    try {
      const cache = await caches.open('transformers-cache');
      const keys = await cache.keys();
      
      // Find and delete all cache entries for this model
      for (const request of keys) {
        if (request.url.includes(modelId)) {
          await cache.delete(request);
        }
      }
      
      // Refresh status
      await checkModelStatus();
    } catch (error) {
      console.error('Failed to delete model:', error);
    }
  };
  
  // Clear all cache
  const clearAllCache = async () => {
    if (!confirm('Are you sure you want to delete all downloaded models?')) {
      return;
    }
    
    try {
      await caches.delete('transformers-cache');
      await checkModelStatus();
    } catch (error) {
      console.error('Failed to clear cache:', error);
    }
  };
  
  // Format file size
  const formatSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  };
  
  return (
    <div className={`bg-gray-900 rounded-lg p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <HardDrive className="w-5 h-5 text-cyan-500" />
          Model Management
        </h3>
        
        <div className="flex items-center gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={checkModelStatus}
            disabled={isRefreshing}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-4 h-4 text-gray-400 ${isRefreshing ? 'animate-spin' : ''}`} />
          </motion.button>
          
          {totalCacheSize > 0 && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={clearAllCache}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-sm rounded-lg transition-colors"
            >
              Clear All
            </motion.button>
          )}
        </div>
      </div>
      
      {/* Cache Stats */}
      <div className="bg-gray-800 rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-400">Total Cache Size</span>
          <span className="text-lg font-semibold text-white">{formatSize(totalCacheSize)}</span>
        </div>
        <div className="text-xs text-gray-500">
          Downloaded models are cached locally for faster loading
        </div>
      </div>
      
      {/* Model List */}
      <div className="space-y-3">
        {WHISPER_MODELS.map(model => {
          const status = modelStatuses.get(model.id);
          const isDownloaded = status?.isDownloaded || false;
          const isDownloading = status?.isDownloading || false;
          const progress = status?.downloadProgress || 0;
          const error = status?.error;
          
          return (
            <motion.div
              key={model.id}
              className="bg-gray-800 rounded-lg p-4 hover:bg-gray-750 transition-colors"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-white">{model.name}</h4>
                    {model.quantized && (
                      <span className="text-xs bg-yellow-600/20 text-yellow-500 px-2 py-0.5 rounded">
                        <Zap className="w-3 h-3 inline mr-1" />
                        Quantized
                      </span>
                    )}
                    {model.language !== 'Multilingual' && (
                      <span className="text-xs bg-blue-600/20 text-blue-400 px-2 py-0.5 rounded">
                        {model.language}
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span>{model.size}</span>
                    {isDownloaded && status && (
                      <span className="text-green-400">
                        <CheckCircle className="w-3 h-3 inline mr-1" />
                        Cached ({formatSize(status.size)})
                      </span>
                    )}
                  </div>
                  
                  {model.description && (
                    <p className="text-xs text-gray-500 mt-2">{model.description}</p>
                  )}
                  
                  {error && (
                    <div className="mt-2 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {error}
                    </div>
                  )}
                </div>
                
                <div className="flex items-center gap-2 ml-4">
                  {!isDownloaded && !isDownloading && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => downloadModel(model.id)}
                      className="p-2 bg-cyan-600 hover:bg-cyan-700 rounded-lg transition-colors"
                      title="Download model"
                    >
                      <Download className="w-4 h-4 text-white" />
                    </motion.button>
                  )}
                  
                  {isDownloaded && (
                    <>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => onModelSelect?.(model.id)}
                        className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-white text-sm rounded-lg transition-colors"
                      >
                        Select
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => deleteModel(model.id)}
                        className="p-2 hover:bg-red-600/20 rounded-lg transition-colors group"
                        title="Delete model"
                      >
                        <Trash2 className="w-4 h-4 text-gray-400 group-hover:text-red-500" />
                      </motion.button>
                    </>
                  )}
                </div>
              </div>
              
              {/* Download Progress */}
              <AnimatePresence>
                {isDownloading && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-3"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-400">Downloading...</span>
                      <span className="text-xs text-gray-400">{progress}%</span>
                    </div>
                    <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-cyan-500"
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
      
      {/* Info */}
      <div className="mt-6 p-4 bg-blue-900/20 border border-blue-700 rounded-lg">
        <div className="flex items-start gap-2">
          <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-300">
            <p className="font-medium mb-1">Model Information</p>
            <ul className="text-xs space-y-1 text-blue-200">
              <li>• Models are downloaded on first use and cached locally</li>
              <li>• Larger models provide better accuracy but are slower</li>
              <li>• English-only models are faster for English content</li>
              <li>• Quantized models trade some accuracy for better performance</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModelDownloadPanel; 