import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useSubtitleStore } from '../../stores/subtitle-store';

interface InteractiveSubtitlePositionerProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  isEnabled: boolean;
  onToggle: () => void;
}

export default function InteractiveSubtitlePositioner({
  videoRef,
  isEnabled,
  onToggle
}: InteractiveSubtitlePositionerProps) {
  const currentProject = useSubtitleStore(state => state.currentProject);
  const updateStyle = useSubtitleStore(state => state.updateStyle);
  const playbackTime = useSubtitleStore(state => state.playbackTime);
  const segments = useSubtitleStore(state => state.getSegmentsInTimeRange(0, Infinity));
  
  const style = currentProject?.style || {
    position: 'bottom-center',
    fontSize: 24,
    fontFamily: 'Arial',
    fontColor: '#FFFFFF',
    backgroundColor: '#000000',
    backgroundOpacity: 0.75,
    padding: 10,
    borderRadius: 4
  };

  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 50, y: 85 }); // Percentage positions
  const containerRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLDivElement>(null);

  // Get current subtitle text
  const currentSegment = segments.find(
    seg => playbackTime >= seg.startTime && playbackTime <= seg.endTime
  );
  const sampleText = currentSegment?.text || 'Sample Subtitle Text';

  // Initialize position from style
  useEffect(() => {
    if (!style.position) return;
    
    const pos = style.position.toString();
    let x = 50, y = 85;
    
    if (pos.includes('left')) x = 15;
    else if (pos.includes('right')) x = 85;
    else x = 50;
    
    if (pos.includes('top')) y = 15;
    else if (pos.includes('middle')) y = 50;
    else y = 85;
    
    setPosition({ x, y });
  }, [style.position]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging || !containerRef.current || !subtitleRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const subtitleRect = subtitleRef.current.getBoundingClientRect();
    
    // Calculate position as percentage, ensuring subtitle stays within bounds
    let x = ((e.clientX - rect.left) / rect.width) * 100;
    let y = ((e.clientY - rect.top) / rect.height) * 100;
    
    // Constrain to keep subtitle fully within video bounds
    const subtitleWidthPercent = (subtitleRect.width / rect.width) * 100;
    const subtitleHeightPercent = (subtitleRect.height / rect.height) * 100;
    
    x = Math.max(subtitleWidthPercent / 2, Math.min(100 - subtitleWidthPercent / 2, x));
    y = Math.max(subtitleHeightPercent / 2, Math.min(100 - subtitleHeightPercent / 2, y));
    
    setPosition({ x, y });
  }, [isDragging]);

  const handleMouseUp = useCallback(() => {
    if (!isDragging) return;
    
    setIsDragging(false);
    
    // Determine position based on coordinates
    let positionStr = '';
    
    if (position.y < 33) positionStr = 'top';
    else if (position.y > 67) positionStr = 'bottom';
    else positionStr = 'middle';
    
    if (position.x < 33) positionStr += '-left';
    else if (position.x > 67) positionStr += '-right';
    else positionStr += '-center';
    
    updateStyle({ position: positionStr as any });
  }, [isDragging, position, updateStyle]);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  if (!isEnabled || !currentProject) return null;

  // Calculate subtitle styles
  const subtitleStyles: React.CSSProperties = {
    position: 'absolute',
    left: `${position.x}%`,
    top: `${position.y}%`,
    transform: 'translate(-50%, -50%)',
    fontFamily: style.fontFamily,
    fontSize: `${style.fontSize}px`,
    color: style.fontColor,
    backgroundColor: `${style.backgroundColor}${Math.round((style.backgroundOpacity || 0.75) * 255).toString(16).padStart(2, '0')}`,
    padding: `${style.padding}px`,
    borderRadius: `${style.borderRadius}px`,
    cursor: isDragging ? 'grabbing' : 'grab',
    userSelect: 'none',
    maxWidth: '90%',
    textAlign: 'center',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
    border: '2px dashed rgba(255, 255, 255, 0.5)',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.5)'
  };

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 overflow-hidden"
      style={{ pointerEvents: 'auto' }}
    >
      {/* Subtitle preview */}
      <div
        ref={subtitleRef}
        style={subtitleStyles}
        onMouseDown={handleMouseDown}
      >
        {sampleText}
      </div>

      {/* Grid guides */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Thirds */}
        <div className="absolute top-1/3 left-0 right-0 h-px bg-white/20" />
        <div className="absolute top-2/3 left-0 right-0 h-px bg-white/20" />
        <div className="absolute top-0 bottom-0 left-1/3 w-px bg-white/20" />
        <div className="absolute top-0 bottom-0 left-2/3 w-px bg-white/20" />
        
        {/* Center lines */}
        <div className="absolute top-1/2 left-0 right-0 h-px bg-cyan-500/30" />
        <div className="absolute top-0 bottom-0 left-1/2 w-px bg-cyan-500/30" />
      </div>

      {/* Position info */}
      <div className="absolute bottom-4 left-4 bg-black/75 text-white px-3 py-2 rounded pointer-events-none text-sm">
        <div>Position: {Math.round(position.x)}%, {Math.round(position.y)}%</div>
        <div className="text-xs text-gray-400 mt-1">Drag subtitle to reposition</div>
      </div>

      {/* Close button */}
      <button
        onClick={onToggle}
        className="absolute top-4 right-4 bg-black/75 text-white p-2 rounded hover:bg-black/90 transition-colors"
        title="Close positioner"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
} 