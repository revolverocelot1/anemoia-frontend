import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Cpu, FileAudio, CheckCircle, AlertCircle } from 'lucide-react';

interface CompactLoadingBarProps {
  isLoading: boolean;
  progress: number;
  status: string;
  type: 'model' | 'transcription';
  error?: string | null;
}

export const CompactLoadingBar: React.FC<CompactLoadingBarProps> = ({
  isLoading,
  progress,
  status,
  type,
  error
}) => {
  const getIcon = () => {
    if (error) return <AlertCircle className="w-5 h-5 text-red-500" />;
    if (progress >= 100) return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (type === 'model') return <Cpu className="w-5 h-5 text-blue-500" />;
    return <FileAudio className="w-5 h-5 text-purple-500" />;
  };

  const getColorClass = () => {
    if (error) return 'from-red-500 to-red-600';
    if (progress >= 100) return 'from-green-500 to-green-600';
    if (type === 'model') return 'from-blue-500 to-blue-600';
    return 'from-purple-500 to-purple-600';
  };

  return (
    <AnimatePresence>
      {(isLoading || progress > 0) && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed top-4 right-4 z-50 bg-gray-900 rounded-lg shadow-xl border border-gray-800 p-4 min-w-[320px]"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="relative">
              {isLoading && progress < 100 && (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0"
                >
                  <Loader2 className="w-5 h-5 text-gray-400" />
                </motion.div>
              )}
              {getIcon()}
            </div>
            
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-white">
                {type === 'model' ? 'Loading Model' : 'Transcribing Audio'}
              </h4>
              <p className="text-xs text-gray-400 truncate">{status || 'Processing...'}</p>
            </div>
            
            <div className="text-right">
              <span className="text-lg font-bold text-white">{Math.round(progress)}%</span>
            </div>
          </div>
          
          {/* Progress bar */}
          <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden">
            <motion.div
              className={`absolute inset-y-0 left-0 bg-gradient-to-r ${getColorClass()} rounded-full`}
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
            
            {/* Animated shimmer effect */}
            {isLoading && progress < 100 && (
              <motion.div
                className="absolute inset-y-0 w-20 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                animate={{ x: [-80, 400] }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              />
            )}
          </div>
          
          {/* Stats */}
          {type === 'transcription' && progress > 0 && progress < 100 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-3 pt-3 border-t border-gray-800"
            >
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-gray-500">Speed</span>
                  <p className="text-white font-medium">
                    {progress > 0 ? `${(progress / 10).toFixed(1)}x` : '0x'}
                  </p>
                </div>
                <div>
                  <span className="text-gray-500">Chunks</span>
                  <p className="text-white font-medium">
                    {Math.floor(progress / 10)}/10
                  </p>
                </div>
                <div>
                  <span className="text-gray-500">ETA</span>
                  <p className="text-white font-medium">
                    {progress > 0 ? `${Math.ceil((100 - progress) / 5)}s` : '...'}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
          
          {/* Error state */}
          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-3 p-2 bg-red-500/10 border border-red-500/20 rounded text-xs text-red-400"
            >
              {error}
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CompactLoadingBar; 