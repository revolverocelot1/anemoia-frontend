import React, { useRef, useEffect, useCallback, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, 
  Maximize2, Settings, ChevronUp, ChevronDown, RotateCcw,
  FastForward, Rewind, Camera
} from 'lucide-react';
import { useSubtitleStore } from '../../stores/subtitle-store';
import { formatTime } from '../../lib/subtitle-utils';
import { InteractiveSubtitleOverlay } from './InteractiveSubtitleOverlay';
import InteractiveSubtitlePositioner from './InteractiveSubtitlePositioner';
import debounce from 'lodash/debounce';

interface VideoPreviewProps {
  videoUrl?: string;
  videoFile?: File;
  onTimeUpdate?: (time: number) => void;
  onDurationChange?: (duration: number) => void;
  onError?: (error: Error) => void;
  className?: string;
  showControls?: boolean;
  autoPlay?: boolean;
  videoRef?: React.RefObject<HTMLVideoElement>;
  showPositioner?: boolean;
  onPositionerToggle?: () => void;
}

export const VideoPreview: React.FC<VideoPreviewProps> = React.memo(({
  videoUrl,
  videoFile,
  onTimeUpdate,
  onDurationChange,
  onError,
  className = '',
  showControls = true,
  autoPlay = false,
  videoRef: externalVideoRef,
  showPositioner = false,
  onPositionerToggle
}) => {
  console.log('[VideoPreview] Component render:', { videoUrl, videoFile, showControls });
  
  const internalVideoRef = useRef<HTMLVideoElement>(null);
  const videoRef = externalVideoRef || internalVideoRef;
  const containerRef = useRef<HTMLDivElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);
  
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [buffered, setBuffered] = useState<Array<{ start: number; end: number }>>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [showStats, setShowStats] = useState(false);
  const [fps, setFps] = useState(0);
  const [videoDimensions, setVideoDimensions] = useState({ width: 0, height: 0 });
  
  const {
    playbackTime,
    setPlaybackTime,
    isPlaying,
    setIsPlaying,
    playbackRate,
    setPlaybackRate,
    volume,
    setVolume,
    videoDuration,
    setVideoDuration,
    videoWidth,
    videoHeight,
    setVideoSize,
    currentProject,
    activeTrackId,
    subtitleStyle,
    updateStyle
  } = useSubtitleStore();

  // Get current track segments
  const currentTrack = currentProject?.tracks.find(t => t.id === activeTrackId);
  const segments = currentTrack?.segments || [];

  // Debug logging
  console.log('[VideoPreview] Subtitle rendering check:', {
    hasProject: !!currentProject,
    activeTrackId,
    currentTrack: currentTrack ? { id: currentTrack.id, segmentCount: currentTrack.segments.length } : null,
    segments: segments.length,
    videoDimensions,
    showPositioner,
    playbackTime,
    currentSegment: segments.find(s => playbackTime >= s.startTime && playbackTime <= s.endTime)
  });

  // Video source URL
  const videoSrc = videoFile ? URL.createObjectURL(videoFile) : videoUrl;
  console.log('[VideoPreview] Video source:', videoSrc);
  
  // Debounced updateStyle to prevent infinite loops
  const debouncedUpdateStyle = useCallback(
    debounce((newStyle: any) => {
      updateStyle(newStyle);
    }, 300),
    [updateStyle]
  );

  // Initialize video
  useEffect(() => {
    if (!videoRef.current || !videoSrc) {
      console.log('[VideoPreview] No video ref or source:', { hasRef: !!videoRef.current, videoSrc });
      return;
    }
    
    const video = videoRef.current;
    console.log('[VideoPreview] Initializing video element with source:', videoSrc);
    
    // Set video attributes
    video.crossOrigin = 'anonymous';
    video.preload = 'auto';
    
    // Load video
    video.src = videoSrc;
    video.playbackRate = playbackRate;
    video.volume = volume;
    
    // Error handler
    const handleVideoError = (e: Event) => {
      console.error('[VideoPreview] Video error:', e);
      if (onError) {
        onError(new Error('Failed to load video'));
      }
    };
    
    video.addEventListener('error', handleVideoError);
    
    // Auto-play if requested
    if (autoPlay) {
      video.play().catch(err => {
        console.warn('Auto-play failed:', err);
      });
    }
    
    // Cleanup
    return () => {
      video.removeEventListener('error', handleVideoError);
      if (videoFile && videoSrc) {
        URL.revokeObjectURL(videoSrc);
      }
    };
  }, [videoSrc, autoPlay, playbackRate, volume, videoFile, onError]);

  // Handle loaded metadata
  const handleLoadedMetadata = useCallback(() => {
    if (!videoRef.current) return;
    
    const video = videoRef.current;
    const duration = video.duration;
    const width = video.videoWidth;
    const height = video.videoHeight;
    
    console.log('[VideoPreview] Video metadata loaded:', { duration, width, height });
    
    setVideoDuration(duration);
    setVideoSize(width, height);
    setVideoDimensions({ width, height });
    setIsLoading(false);
    
    if (onDurationChange) {
      onDurationChange(duration);
    }
    
    // Calculate FPS
    const fps = video.getVideoPlaybackQuality ? 
      Math.round(video.getVideoPlaybackQuality().totalVideoFrames / video.currentTime) : 
      30;
    setFps(fps || 30);
  }, [setVideoDuration, setVideoSize, onDurationChange]);

  // Throttle time updates to prevent performance issues
  const lastTimeUpdateRef = useRef<number>(0);
  
  // Handle time update
  const handleTimeUpdate = useCallback(() => {
    if (!videoRef.current) return;
    
    const time = videoRef.current.currentTime;
    const now = Date.now();
    
    // Throttle updates to 30fps (approximately every 33ms)
    if (now - lastTimeUpdateRef.current < 33) return;
    
    lastTimeUpdateRef.current = now;
    setPlaybackTime(time);
    
    if (onTimeUpdate) {
      onTimeUpdate(time);
    }
  }, [setPlaybackTime, onTimeUpdate]);

  // Handle buffer update
  const handleProgress = useCallback(() => {
    if (!videoRef.current) return;
    
    const video = videoRef.current;
    const bufferedRanges: Array<{ start: number; end: number }> = [];
    
    for (let i = 0; i < video.buffered.length; i++) {
      bufferedRanges.push({
        start: video.buffered.start(i),
        end: video.buffered.end(i)
      });
    }
    
    setBuffered(bufferedRanges);
  }, []);

  // Handle play/pause
  const togglePlayback = useCallback(() => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
  }, [isPlaying]);

  // Skip forward/backward
  const skip = useCallback((seconds: number) => {
    if (!videoRef.current) return;
    
    const newTime = Math.max(0, Math.min(videoDuration, playbackTime + seconds));
    videoRef.current.currentTime = newTime;
    setPlaybackTime(newTime);
  }, [playbackTime, videoDuration, setPlaybackTime]);

  // Frame step
  const frameStep = useCallback((forward: boolean) => {
    if (!videoRef.current || !fps) return;
    
    const frameTime = 1 / fps;
    skip(forward ? frameTime : -frameTime);
  }, [fps, skip]);

  // Seek to position
  const seekTo = useCallback((time: number) => {
    if (!videoRef.current) return;
    
    videoRef.current.currentTime = time;
    setPlaybackTime(time);
  }, [setPlaybackTime]);

  // Progress bar click
  const handleProgressClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    
    const rect = progressBarRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const time = percentage * videoDuration;
    
    seekTo(Math.max(0, Math.min(videoDuration, time)));
  }, [videoDuration, seekTo]);

  // Volume control
  const handleVolumeChange = useCallback((newVolume: number) => {
    if (!videoRef.current) return;
    
    const clampedVolume = Math.max(0, Math.min(1, newVolume));
    videoRef.current.volume = clampedVolume;
    setVolume(clampedVolume);
  }, [setVolume]);

  // Speed control
  const handleSpeedChange = useCallback((speed: number) => {
    if (!videoRef.current) return;
    
    videoRef.current.playbackRate = speed;
    setPlaybackRate(speed);
    setShowSpeedMenu(false);
  }, [setPlaybackRate]);

  // Fullscreen toggle
  const toggleFullscreen = useCallback(async () => {
    if (!containerRef.current) return;
    
    try {
      if (!isFullscreen) {
        await containerRef.current.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch (error) {
      console.error('Fullscreen error:', error);
    }
  }, [isFullscreen]);

  // Fullscreen change handler
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Keyboard shortcuts (local to video)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Only handle if video is focused
      if (!containerRef.current?.contains(document.activeElement)) return;
      
      switch (e.key) {
        case 'k':
        case ' ':
          e.preventDefault();
          togglePlayback();
          break;
        case 'j':
          e.preventDefault();
          skip(-10);
          break;
        case 'l':
          e.preventDefault();
          skip(10);
          break;
        case 'ArrowLeft':
          e.preventDefault();
          skip(e.shiftKey ? -10 : -5);
          break;
        case 'ArrowRight':
          e.preventDefault();
          skip(e.shiftKey ? 10 : 5);
          break;
        case ',':
          e.preventDefault();
          frameStep(false);
          break;
        case '.':
          e.preventDefault();
          frameStep(true);
          break;
        case 'm':
          e.preventDefault();
          handleVolumeChange(volume > 0 ? 0 : 1);
          break;
        case 'f':
          e.preventDefault();
          toggleFullscreen();
          break;
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePlayback, skip, frameStep, handleVolumeChange, toggleFullscreen, volume]);

  // Error handling
  const handleError = useCallback((e: Event) => {
    const video = e.target as HTMLVideoElement;
    const error = video.error;
    
    let errorMessage = 'Unknown video error';
    if (error) {
      switch (error.code) {
        case error.MEDIA_ERR_ABORTED:
          errorMessage = 'Video playback aborted';
          break;
        case error.MEDIA_ERR_NETWORK:
          errorMessage = 'Network error while loading video';
          break;
        case error.MEDIA_ERR_DECODE:
          errorMessage = 'Video decode error';
          break;
        case error.MEDIA_ERR_SRC_NOT_SUPPORTED:
          errorMessage = 'Video format not supported';
          break;
      }
    }
    
    setVideoError(errorMessage);
    setIsLoading(false);
    
    if (onError) {
      onError(new Error(errorMessage));
    }
  }, [onError]);

  // Speed options
  const speedOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

  return (
    <div 
      ref={containerRef}
      className={`relative bg-black rounded-lg overflow-hidden group ${className}`}
      tabIndex={0}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline
        preload="auto"
        onLoadedMetadata={handleLoadedMetadata}
        onTimeUpdate={handleTimeUpdate}
        onProgress={handleProgress}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onError={(e) => handleError(e.nativeEvent)}
        onLoadStart={() => setIsLoading(true)}
        onCanPlay={() => setIsLoading(false)}
      />
      
      {/* Interactive Subtitle Overlay */}
      {segments.length > 0 && videoDimensions.width > 0 && !showPositioner && (
        <InteractiveSubtitleOverlay 
          segments={segments}
          currentTime={playbackTime}
          videoWidth={videoDimensions.width}
          videoHeight={videoDimensions.height}
          style={{
            fontSize: subtitleStyle?.fontSize || 24,
            fontFamily: subtitleStyle?.fontFamily || 'Arial',
            color: subtitleStyle?.fontColor || '#FFFFFF',
            backgroundColor: subtitleStyle?.backgroundColor || '#000000',
            backgroundOpacity: subtitleStyle?.backgroundOpacity ?? 0.75,
            padding: subtitleStyle?.padding || 10,
            borderRadius: subtitleStyle?.borderRadius || 4,
            position: subtitleStyle?.position === 'bottom' ? { x: 50, y: 85 } :
                     subtitleStyle?.position === 'top' ? { x: 50, y: 15 } :
                     subtitleStyle?.position === 'center' ? { x: 50, y: 50 } :
                     { x: 50, y: 85 }
          }}
          onStyleChange={debouncedUpdateStyle}
        />
      )}
      
      {/* Interactive Subtitle Positioner */}
      {showPositioner && (
        <InteractiveSubtitlePositioner
          videoRef={videoRef}
          isEnabled={showPositioner}
          onToggle={onPositionerToggle || (() => {})}
        />
      )}
      
      {/* Loading Spinner */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/50"
          >
            <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin" />
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Error Display */}
      <AnimatePresence>
        {videoError && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/80"
          >
            <div className="text-center">
              <div className="text-red-500 text-4xl mb-4">⚠️</div>
              <p className="text-white text-lg">{videoError}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Controls */}
      {showControls && !videoError && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        >
          {/* Progress Bar */}
          <div 
            ref={progressBarRef}
            className="relative h-1 bg-gray-700 rounded-full mb-4 cursor-pointer group/progress"
            onClick={handleProgressClick}
          >
            {/* Buffered ranges */}
            {buffered.map((range, index) => {
              const start = (range.start / videoDuration) * 100;
              const width = ((range.end - range.start) / videoDuration) * 100;
              return (
                <div
                  key={index}
                  className="absolute top-0 h-full bg-gray-600 rounded-full"
                  style={{ left: `${start}%`, width: `${width}%` }}
                />
              );
            })}
            
            {/* Progress */}
            <div 
              className="absolute top-0 h-full bg-cyan-500 rounded-full transition-all duration-100"
              style={{ width: `${(playbackTime / videoDuration) * 100}%` }}
            >
              <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-cyan-500 rounded-full opacity-0 group-hover/progress:opacity-100 transition-opacity" />
            </div>
            
            {/* Time tooltip */}
            <div className="absolute -top-8 left-0 bg-gray-800 px-2 py-1 rounded text-xs text-white opacity-0 group-hover/progress:opacity-100 transition-opacity pointer-events-none"
                 style={{ left: `${(playbackTime / videoDuration) * 100}%`, transform: 'translateX(-50%)' }}>
              {formatTime(playbackTime)}
            </div>
          </div>
          
          {/* Control Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {/* Play/Pause */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={togglePlayback}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </motion.button>
              
              {/* Skip buttons */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => skip(-10)}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <SkipBack className="w-4 h-4" />
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => skip(10)}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <SkipForward className="w-4 h-4" />
              </motion.button>
              
              {/* Frame step */}
              <div className="flex items-center gap-1 ml-2">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => frameStep(false)}
                  className="p-1 hover:bg-white/20 rounded transition-colors"
                  title="Previous frame"
                >
                  <ChevronDown className="w-4 h-4 rotate-90" />
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => frameStep(true)}
                  className="p-1 hover:bg-white/20 rounded transition-colors"
                  title="Next frame"
                >
                  <ChevronUp className="w-4 h-4 rotate-90" />
                </motion.button>
              </div>
              
              {/* Volume */}
              <div className="relative group/volume ml-2">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setShowVolumeSlider(!showVolumeSlider)}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  {volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </motion.button>
                
                <AnimatePresence>
                  {showVolumeSlider && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-gray-800 rounded-lg p-2"
                    >
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={volume}
                        onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                        className="h-24 w-2 appearance-none bg-gray-600 rounded-full outline-none slider-vertical"
                        style={{ writingMode: 'vertical-lr' as any }}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              
              {/* Time display */}
              <div className="text-sm text-gray-300 ml-4">
                {formatTime(playbackTime)} / {formatTime(videoDuration)}
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* Speed control */}
              <div className="relative">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                  className="px-3 py-1 hover:bg-white/20 rounded transition-colors text-sm"
                >
                  {playbackRate}x
                </motion.button>
                
                <AnimatePresence>
                  {showSpeedMenu && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="absolute bottom-full mb-2 right-0 bg-gray-800 rounded-lg py-2 min-w-[100px]"
                    >
                      {speedOptions.map(speed => (
                        <button
                          key={speed}
                          onClick={() => handleSpeedChange(speed)}
                          className={`w-full px-4 py-1 text-sm hover:bg-white/20 transition-colors text-left ${
                            playbackRate === speed ? 'text-cyan-400' : ''
                          }`}
                        >
                          {speed}x
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              
              {/* Stats toggle */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowStats(!showStats)}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
                title="Toggle stats"
              >
                <Camera className="w-4 h-4" />
              </motion.button>
              
              {/* Fullscreen */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={toggleFullscreen}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <Maximize2 className="w-4 h-4" />
              </motion.button>
            </div>
          </div>
        </motion.div>
      )}
      
      {/* Video Stats */}
      <AnimatePresence>
        {showStats && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute top-4 right-4 bg-black/70 rounded-lg p-3 text-xs font-mono"
          >
            <div>Resolution: {videoWidth}x{videoHeight}</div>
            <div>FPS: {fps}</div>
            <div>Duration: {formatTime(videoDuration)}</div>
            <div>Current: {formatTime(playbackTime)}</div>
            <div>Speed: {playbackRate}x</div>
            <div>Volume: {Math.round(volume * 100)}%</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
});

VideoPreview.displayName = 'VideoPreview';

export default VideoPreview; 