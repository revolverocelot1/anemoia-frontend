import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Type, Palette, AlignLeft, AlignCenter, AlignRight, 
  Square, Circle, Maximize2, Minimize2, Eye, EyeOff,
  RotateCcw, Save, ChevronDown, Plus, Minus
} from 'lucide-react';
import { HexColorPicker } from 'react-colorful';
import { useSubtitleStore } from '../../stores/subtitle-store';
import { SubtitlePreview } from './SubtitleOverlay';
import type { SubtitleStyle } from '../../types/subtitle';
import { DEFAULT_SUBTITLE_STYLE } from '../../types/subtitle';

interface SubtitleStyleControlsProps {
  onStyleChange?: (style: Partial<SubtitleStyle>) => void;
  showPreview?: boolean;
  className?: string;
}

// Font options
const FONT_FAMILIES = [
  { value: 'Arial', label: 'Arial' },
  { value: 'Helvetica', label: 'Helvetica' },
  { value: 'Times New Roman', label: 'Times New Roman' },
  { value: 'Georgia', label: 'Georgia' },
  { value: 'Courier New', label: 'Courier New' },
  { value: 'Verdana', label: 'Verdana' },
  { value: 'Trebuchet MS', label: 'Trebuchet MS' },
  { value: 'Comic Sans MS', label: 'Comic Sans' },
  { value: 'Impact', label: 'Impact' },
  { value: 'Roboto', label: 'Roboto' },
  { value: 'Open Sans', label: 'Open Sans' },
  { value: 'Lato', label: 'Lato' },
  { value: 'Montserrat', label: 'Montserrat' },
  { value: 'Inter', label: 'Inter' }
];

const FONT_WEIGHTS = [
  { value: 300, label: 'Light' },
  { value: 400, label: 'Normal' },
  { value: 500, label: 'Medium' },
  { value: 600, label: 'Semibold' },
  { value: 700, label: 'Bold' },
  { value: 900, label: 'Black' }
];

export const SubtitleStyleControls: React.FC<SubtitleStyleControlsProps> = ({
  onStyleChange,
  showPreview = true,
  className = ''
}) => {
  const subtitleStyle = useSubtitleStore(state => state.subtitleStyle);
  const updateStoreStyle = useSubtitleStore(state => state.updateStyle);
  const [localStyle, setLocalStyle] = useState<SubtitleStyle>({
    ...DEFAULT_SUBTITLE_STYLE,
    ...subtitleStyle
  });
  
  const [showColorPicker, setShowColorPicker] = useState<string | null>(null);
  const [previewText, setPreviewText] = useState('Sample subtitle text\nWith multiple lines');
  const [activeTab, setActiveTab] = useState<'text' | 'background' | 'position'>('text');
  
  // Update style
  const updateStyle = useCallback((updates: Partial<SubtitleStyle>) => {
    const newStyle = { ...localStyle, ...updates };
    setLocalStyle(newStyle);
    updateStoreStyle(updates);
    onStyleChange?.(updates);
  }, [localStyle, updateStoreStyle, onStyleChange]);
  
  // Reset to defaults
  const resetStyle = useCallback(() => {
    setLocalStyle(DEFAULT_SUBTITLE_STYLE);
    updateStoreStyle(DEFAULT_SUBTITLE_STYLE);
    onStyleChange?.(DEFAULT_SUBTITLE_STYLE);
  }, [updateStoreStyle, onStyleChange]);
  
  // Color picker component
  const ColorPickerButton: React.FC<{
    color: string;
    onChange: (color: string) => void;
    label: string;
    id: string;
  }> = ({ color, onChange, label, id }) => (
    <div className="relative">
      <label className="block text-sm text-gray-400 mb-1">{label}</label>
      <button
        onClick={() => setShowColorPicker(showColorPicker === id ? null : id)}
        className="w-full h-10 rounded-lg border border-gray-600 flex items-center gap-2 px-3 hover:border-cyan-500 transition-colors"
        style={{ backgroundColor: color }}
      >
        <span className="text-white drop-shadow">{color}</span>
      </button>
      
      <AnimatePresence>
        {showColorPicker === id && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute top-full mt-2 z-50 bg-gray-800 rounded-lg shadow-xl p-3 border border-gray-700"
          >
            <HexColorPicker color={color} onChange={onChange} />
            <button
              onClick={() => setShowColorPicker(null)}
              className="mt-2 w-full px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white transition-colors"
            >
              Done
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
  
  return (
    <div className={`bg-black/95 backdrop-blur-md rounded-xl border border-gray-800/50 shadow-xl ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800/50 bg-gradient-to-r from-gray-900/50 to-gray-800/50">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Palette className="w-5 h-5 text-cyan-400" />
          Subtitle Style
        </h3>
        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={resetStyle}
          className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          title="Reset to defaults"
        >
          <RotateCcw className="w-4 h-4 text-gray-400" />
        </motion.button>
      </div>
      
      {/* Tabs */}
      <div className="flex border-b border-gray-700">
        {(['text', 'background', 'position'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
              activeTab === tab
                ? 'text-cyan-500 border-b-2 border-cyan-500'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>
      
      {/* Content */}
      <div className="p-4">
        <AnimatePresence mode="wait">
          {/* Text Tab */}
          {activeTab === 'text' && (
            <motion.div
              key="text"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              {/* Font Family */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Font Family</label>
                <select
                  value={localStyle.fontFamily}
                  onChange={(e) => updateStyle({ fontFamily: e.target.value })}
                  className="w-full bg-gray-800 text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-cyan-500 outline-none"
                >
                  {FONT_FAMILIES.map(font => (
                    <option key={font.value} value={font.value}>
                      {font.label}
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Font Size */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Font Size: {localStyle.fontSize}px
                </label>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateStyle({ fontSize: Math.max(12, (localStyle.fontSize || 24) - 2) })}
                    className="p-2 hover:bg-gray-800 rounded transition-colors"
                  >
                    <Minus className="w-4 h-4 text-gray-400" />
                  </button>
                  <input
                    type="range"
                    min="12"
                    max="72"
                    value={localStyle.fontSize}
                    onChange={(e) => updateStyle({ fontSize: parseInt(e.target.value) })}
                    className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <button
                    onClick={() => updateStyle({ fontSize: Math.min(72, (localStyle.fontSize || 24) + 2) })}
                    className="p-2 hover:bg-gray-800 rounded transition-colors"
                  >
                    <Plus className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </div>
              
              {/* Font Weight */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Font Weight</label>
                <select
                  value={localStyle.fontWeight}
                  onChange={(e) => updateStyle({ fontWeight: parseInt(e.target.value) })}
                  className="w-full bg-gray-800 text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-cyan-500 outline-none"
                >
                  {FONT_WEIGHTS.map(weight => (
                    <option key={weight.value} value={weight.value}>
                      {weight.label}
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Font Style */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Font Style</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => updateStyle({ fontStyle: localStyle.fontStyle === 'italic' ? 'normal' : 'italic' })}
                    className={`flex-1 px-3 py-2 rounded-lg transition-colors ${
                      localStyle.fontStyle === 'italic'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                    }`}
                  >
                    Italic
                  </button>
                </div>
              </div>
              
              {/* Text Color */}
              <ColorPickerButton
                color={localStyle.fontColor || '#FFFFFF'}
                onChange={(color) => updateStyle({ fontColor: color })}
                label="Text Color"
                id="text-color"
              />
              
              {/* Text Shadow */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Text Shadow</label>
                <input
                  type="text"
                  value={localStyle.textShadow || ''}
                  onChange={(e) => updateStyle({ textShadow: e.target.value })}
                  placeholder="2px 2px 4px rgba(0,0,0,0.8)"
                  className="w-full bg-gray-800 text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-cyan-500 outline-none"
                />
              </div>
              
              {/* Text Stroke */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Text Stroke</label>
                <input
                  type="text"
                  value={localStyle.textStroke || ''}
                  onChange={(e) => updateStyle({ textStroke: e.target.value })}
                  placeholder="1px black"
                  className="w-full bg-gray-800 text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-cyan-500 outline-none"
                />
              </div>
            </motion.div>
          )}
          
          {/* Background Tab */}
          {activeTab === 'background' && (
            <motion.div
              key="background"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              {/* Background Color */}
              <ColorPickerButton
                color={localStyle.backgroundColor || '#000000'}
                onChange={(color) => updateStyle({ backgroundColor: color })}
                label="Background Color"
                id="bg-color"
              />
              
              {/* Background Opacity */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Background Opacity: {Math.round((localStyle.backgroundOpacity ?? 0.8) * 100)}%
                  {localStyle.backgroundOpacity === 0 && ' (No Background)'}
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={(localStyle.backgroundOpacity ?? 0.8) * 100}
                  onChange={(e) => updateStyle({ backgroundOpacity: parseInt(e.target.value) / 100 })}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>0% (None)</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>
              
              {/* Padding */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Padding: {localStyle.padding}px
                </label>
                <input
                  type="range"
                  min="0"
                  max="40"
                  value={localStyle.padding}
                  onChange={(e) => updateStyle({ padding: parseInt(e.target.value) })}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>
              
              {/* Border Radius */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Border Radius: {localStyle.borderRadius}px
                </label>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={localStyle.borderRadius}
                  onChange={(e) => updateStyle({ borderRadius: parseInt(e.target.value) })}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>
            </motion.div>
          )}
          
          {/* Position Tab */}
          {activeTab === 'position' && (
            <motion.div
              key="position"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              {/* Visual Position Selector */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">Position Selector</label>
                <div className="bg-gray-800 rounded-lg p-4 relative aspect-video">
                  <div className="grid grid-cols-3 grid-rows-3 h-full gap-2">
                    {[
                      'top-left', 'top-center', 'top-right',
                      'middle-left', 'middle-center', 'middle-right',
                      'bottom-left', 'bottom-center', 'bottom-right'
                    ].map((pos) => {
                      const [vPos, hPos] = pos.split('-');
                      const isActive = localStyle.position === pos || 
                        (localStyle.position === vPos && localStyle.alignment === hPos);
                      
                      return (
                    <button
                      key={pos}
                          onClick={() => {
                            const [vertical, horizontal] = pos.split('-');
                            updateStyle({ 
                              position: pos as any,
                              alignment: horizontal as any
                            });
                          }}
                          className={`relative rounded-lg transition-all ${
                            isActive
                              ? 'bg-cyan-600 shadow-lg scale-105'
                              : 'bg-gray-700 hover:bg-gray-600'
                          }`}
                        >
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className={`w-8 h-1 bg-white rounded ${isActive ? 'opacity-100' : 'opacity-50'}`} />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  
                  {/* Preview text on the grid */}
                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                    <div 
                      className="text-white text-xs bg-black/50 px-2 py-1 rounded"
                      style={{
                        position: 'absolute',
                        ...(() => {
                          const pos = localStyle.position || 'bottom-center';
                          const align = localStyle.alignment || 'center';
                          const marginX = (localStyle as any).marginX || 10;
                          const marginY = (localStyle as any).marginY || 10;
                          
                          const style: any = {};
                          
                          // Vertical position
                          if (pos.includes('top')) style.top = `${marginY}%`;
                          else if (pos.includes('middle')) style.top = '50%';
                          else style.bottom = `${marginY}%`;
                          
                          // Horizontal position
                          if (pos.includes('left') || align === 'left') style.left = `${marginX}%`;
                          else if (pos.includes('right') || align === 'right') style.right = `${marginX}%`;
                          else { style.left = '50%'; style.transform = 'translateX(-50%)'; }
                          
                          if (pos.includes('middle')) {
                            style.transform = style.transform 
                              ? `${style.transform} translateY(-50%)` 
                              : 'translateY(-50%)';
                          }
                          
                          return style;
                        })()
                      }}
                    >
                      Preview Text
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Margin Controls */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Horizontal Margin: {(localStyle as any).marginX || 10}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={(localStyle as any).marginX || 10}
                  onChange={(e) => updateStyle({ marginX: parseInt(e.target.value) } as any)}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Vertical Margin: {(localStyle as any).marginY || 10}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={(localStyle as any).marginY || 10}
                  onChange={(e) => updateStyle({ marginY: parseInt(e.target.value) } as any)}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>
              
              {/* Alignment */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">Text Alignment</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => updateStyle({ alignment: 'left' })}
                    className={`p-2 rounded-lg transition-colors ${
                      localStyle.alignment === 'left'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                    }`}
                    title="Align left"
                  >
                    <AlignLeft className="w-4 h-4 mx-auto" />
                  </button>
                  
                  <button
                    onClick={() => updateStyle({ alignment: 'center' })}
                    className={`p-2 rounded-lg transition-colors ${
                      localStyle.alignment === 'center'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                    }`}
                    title="Align center"
                  >
                    <AlignCenter className="w-4 h-4 mx-auto" />
                  </button>
                  
                  <button
                    onClick={() => updateStyle({ alignment: 'right' })}
                    className={`p-2 rounded-lg transition-colors ${
                      localStyle.alignment === 'right'
                        ? 'bg-cyan-600 text-white'
                        : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                    }`}
                    title="Align right"
                  >
                    <AlignRight className="w-4 h-4 mx-auto" />
                  </button>
                </div>
              </div>
              
              {/* Line Height */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Line Height: {localStyle.lineHeight}
                </label>
                <input
                  type="range"
                  min="1"
                  max="3"
                  step="0.1"
                  value={localStyle.lineHeight}
                  onChange={(e) => updateStyle({ lineHeight: parseFloat(e.target.value) })}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>
              
              {/* Letter Spacing */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  Letter Spacing: {localStyle.letterSpacing}px
                </label>
                <input
                  type="range"
                  min="-2"
                  max="10"
                  value={localStyle.letterSpacing}
                  onChange={(e) => updateStyle({ letterSpacing: parseInt(e.target.value) })}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Preview */}
      {showPreview && (
        <div className="border-t border-gray-700 p-4">
          <div className="mb-3">
            <label className="block text-sm text-gray-400 mb-2">Preview Text</label>
            <textarea
              value={previewText}
              onChange={(e) => setPreviewText(e.target.value)}
              className="w-full bg-gray-800 text-white px-3 py-2 rounded-lg border border-gray-700 focus:border-cyan-500 outline-none resize-none"
              rows={2}
              placeholder="Enter preview text..."
            />
          </div>
          
          <div className="bg-gray-800 rounded-lg overflow-hidden">
            <div className="h-48 relative bg-gradient-to-br from-gray-900 to-gray-800">
              <SubtitlePreview
                text={previewText}
                style={localStyle}
                className="h-full"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubtitleStyleControls; 