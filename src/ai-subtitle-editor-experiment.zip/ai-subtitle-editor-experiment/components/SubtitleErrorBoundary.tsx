import React, { Component, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class SubtitleErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // In production, you might want to send this to an error reporting service
    if (process.env.NODE_ENV === 'production') {
      // Log error to service
    } else {
      console.error('Subtitle editor error:', error, errorInfo);
    }
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    // Optionally reload the page or reset state
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center p-8">
          <div className="max-w-2xl w-full bg-gray-800 rounded-lg shadow-2xl p-8">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h1 className="text-2xl font-bold">Something went wrong</h1>
            </div>
            
            <div className="bg-gray-900 rounded-lg p-4 mb-6">
              <p className="text-gray-300 mb-2">An error occurred in the subtitle editor:</p>
              <pre className="text-sm text-red-400 overflow-auto">
                {this.state.error?.message || 'Unknown error'}
              </pre>
            </div>

            <div className="flex gap-4">
              <button
                onClick={this.handleReset}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
              >
                Reload Editor
              </button>
              <button
                onClick={() => window.history.back()}
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
              >
                Go Back
              </button>
            </div>

            <p className="text-sm text-gray-400 mt-6">
              Your work has been automatically saved. You can safely reload the page.
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
} 