import React, { useState } from 'react';

interface ExportMenuProps {
  onExportSRT: () => void;
  onExportVTT: () => void;
  onExportOverlay: () => void;
  onExportEmbed?: () => void;
  isExporting: boolean;
  hasSegments: boolean;
}

export function ExportMenu({
  onExportSRT,
  onExportVTT,
  onExportOverlay,
  onExportEmbed,
  isExporting,
  hasSegments
}: ExportMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  if (!hasSegments) return null;
  
  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={isExporting}
        className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
      >
        {isExporting ? 'Exporting...' : 'Export'}
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      
      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-64 bg-gray-800 rounded-lg shadow-xl overflow-hidden z-50">
          <div className="p-2">
            <h3 className="text-sm font-semibold text-gray-400 px-2 py-1">Subtitle Files</h3>
            
            <button
              onClick={() => {
                onExportSRT();
                setIsOpen(false);
              }}
              className="w-full px-3 py-2 text-left hover:bg-gray-700 rounded flex items-center justify-between"
            >
              <span>Export as SRT</span>
              <span className="text-xs text-gray-500">Universal format</span>
            </button>
            
            <button
              onClick={() => {
                onExportVTT();
                setIsOpen(false);
              }}
              className="w-full px-3 py-2 text-left hover:bg-gray-700 rounded flex items-center justify-between"
            >
              <span>Export as WebVTT</span>
              <span className="text-xs text-gray-500">With styles</span>
            </button>
            
            <div className="border-t border-gray-700 my-2"></div>
            
            <h3 className="text-sm font-semibold text-gray-400 px-2 py-1">Video Export</h3>
            
            <button
              onClick={() => {
                onExportOverlay();
                setIsOpen(false);
              }}
              className="w-full px-3 py-2 text-left hover:bg-gray-700 rounded"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-medium">Burn Subtitles</span>
                <span className="text-xs bg-red-600 px-2 py-0.5 rounded">PERMANENT</span>
              </div>
              <p className="text-xs text-gray-400">
                Permanently burn subtitles into the video - cannot be removed
              </p>
            </button>
            
            {onExportEmbed && (
              <button
                onClick={() => {
                  onExportEmbed();
                  setIsOpen(false);
                }}
                className="w-full px-3 py-2 text-left hover:bg-gray-700 rounded mt-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium">Embed Subtitles</span>
                  <span className="text-xs bg-blue-600 px-2 py-0.5 rounded">FLEXIBLE</span>
                </div>
                <p className="text-xs text-gray-400">
                  Add subtitle track to video - can be toggled on/off by viewers
                </p>
              </button>
            )}
          </div>
        </div>
      )}
      
      {/* Click outside to close */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setIsOpen(false)}
        />
      )}
    </div>
  );
} 