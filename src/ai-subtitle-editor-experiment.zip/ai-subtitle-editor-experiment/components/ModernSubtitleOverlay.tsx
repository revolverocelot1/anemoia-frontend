import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { SubtitleSegment, SubtitleStyle } from '../../types/subtitle';
import { useSubtitleStore } from '../../stores/subtitle-store';

interface ModernSubtitleOverlayProps {
  currentTime: number;
  segments: SubtitleSegment[];
  globalStyle?: Partial<SubtitleStyle>;
  isPreview?: boolean;
}

interface AnimatedWord {
  word: string;
  index: number;
  startTime: number;
  endTime: number;
}

export function ModernSubtitleOverlay({
  currentTime,
  segments,
  globalStyle = {},
  isPreview = false
}: ModernSubtitleOverlayProps) {
  const [activeSegment, setActiveSegment] = useState<SubtitleSegment | null>(null);
  const [animatedWords, setAnimatedWords] = useState<AnimatedWord[]>([]);
  
  // Find active segment
  useEffect(() => {
    const active = segments.find(
      segment => currentTime >= segment.startTime && currentTime <= segment.endTime
    );
    setActiveSegment(active || null);
  }, [currentTime, segments]);
  
  // Split text into animated words
  useEffect(() => {
    if (!activeSegment) {
      setAnimatedWords([]);
      return;
    }
    
    const words = activeSegment.text.split(' ');
    const segmentDuration = activeSegment.endTime - activeSegment.startTime;
    const wordDuration = segmentDuration / words.length;
    
    const animated = words.map((word, index) => ({
      word,
      index,
      startTime: activeSegment.startTime + (index * wordDuration),
      endTime: activeSegment.startTime + ((index + 1) * wordDuration)
    }));
    
    setAnimatedWords(animated);
  }, [activeSegment]);
  
  // Merge styles
  const style = useMemo(() => ({
    ...globalStyle,
    ...(activeSegment?.style || {})
  }), [globalStyle, activeSegment]);
  
  // Calculate position
  const getPosition = () => {
    const position = style.position || 'bottom-center';
    const positions: Record<string, any> = {
      'top-left': { top: '10%', left: '5%' },
      'top-center': { top: '10%', left: '50%', transform: 'translateX(-50%)' },
      'top-right': { top: '10%', right: '5%' },
      'middle-left': { top: '50%', left: '5%', transform: 'translateY(-50%)' },
      'middle-center': { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' },
      'middle-right': { top: '50%', right: '5%', transform: 'translateY(-50%)' },
      'bottom-left': { bottom: '10%', left: '5%' },
      'bottom-center': { bottom: '10%', left: '50%', transform: 'translateX(-50%)' },
      'bottom-right': { bottom: '10%', right: '5%' },
    };
    
    return positions[position] || positions['bottom-center'];
  };
  
  const getTextAlign = () => {
    const alignment = style.alignment || 'center';
    return alignment;
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.03,
        delayChildren: 0.1
      }
    },
    exit: {
      opacity: 0,
      transition: {
        duration: 0.2
      }
    }
  };
  
  const wordVariants = {
    hidden: {
      opacity: 0,
      y: 20,
      scale: 0.8,
      filter: 'blur(10px)'
    },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      filter: 'blur(0px)',
      transition: {
        duration: 0.4,
        ease: 'easeOut' // Use string easing instead of array
      }
    },
    exit: {
      opacity: 0,
      y: -10,
      transition: {
        duration: 0.2
      }
    }
  };
  
  // Highlight effect for current word
  const getWordStyle = (word: AnimatedWord) => {
    const isActive = currentTime >= word.startTime && currentTime < word.endTime;
    const isPast = currentTime >= word.endTime;
    const highlightColor = '#FFD700'; // Default highlight color
    
    return {
      display: 'inline-block',
      margin: '0 0.15em',
      transition: 'all 0.3s ease',
      transform: isActive ? 'scale(1.1)' : 'scale(1)',
      color: isActive 
        ? highlightColor
        : isPast 
          ? style.fontColor || '#FFFFFF'
          : style.fontColor || '#FFFFFF',
      opacity: isPast ? 0.8 : 1,
      textShadow: isActive 
        ? `0 0 20px ${highlightColor}, ${style.textShadow || '2px 2px 4px rgba(0,0,0,0.8)'}`
        : style.textShadow || '2px 2px 4px rgba(0,0,0,0.8)'
    };
  };
  
  if (!activeSegment) return null;
  
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={activeSegment.id}
        className="modern-subtitle-overlay"
        style={{
          position: 'absolute',
          ...getPosition(),
          zIndex: 1000,
          maxWidth: '90%',
          pointerEvents: isPreview ? 'none' : 'auto'
        }}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        exit="exit"
      >
        <div
          style={{
            fontFamily: style.fontFamily || 'Arial, sans-serif',
            fontSize: `${style.fontSize || 24}px`,
            fontWeight: style.fontWeight || 'bold',
            fontStyle: style.fontStyle || 'normal',
            textAlign: getTextAlign(),
            lineHeight: 1.2,
            padding: `${style.padding || 10}px`,
            borderRadius: `${style.borderRadius || 8}px`,
            backgroundColor: style.backgroundOpacity === 0 
              ? 'transparent' 
              : `rgba(0, 0, 0, ${style.backgroundOpacity || 0.7})`,
            backdropFilter: style.backgroundOpacity === 0 ? 'none' : 'blur(8px)',
            boxShadow: style.backgroundOpacity === 0 
              ? 'none' 
              : '0 4px 20px rgba(0, 0, 0, 0.5)',
          }}
        >
          {/* Render each word with animation */}
          {animatedWords.map((word, index) => (
            <motion.span
              key={`${activeSegment.id}-${index}`}
              custom={index}
              variants={wordVariants}
              style={getWordStyle(word)}
            >
              {word.word}
            </motion.span>
          ))}
        </div>
        
        {/* Optional progress bar */}
        <motion.div
          className="subtitle-progress"
          style={{
            position: 'absolute',
            bottom: -4,
            left: 0,
            right: 0,
            height: 3,
            backgroundColor: 'rgba(255, 255, 255, 0.2)',
            borderRadius: 1.5,
            overflow: 'hidden'
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            style={{
              height: '100%',
              backgroundColor: '#FFD700',
              borderRadius: 1.5
            }}
            initial={{ width: '0%' }}
            animate={{
              width: `${((currentTime - activeSegment.startTime) / (activeSegment.endTime - activeSegment.startTime)) * 100}%`
            }}
            transition={{ duration: 0.1, ease: 'linear' }}
          />
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// Export a wrapper component that can be used in the video container
export function ModernSubtitleWrapper() {
  const allSegments = useSubtitleStore(state => state.getAllSegments());
  const playbackTime = useSubtitleStore(state => state.playbackTime);
  const tracks = useSubtitleStore(state => state.tracks);
  const style = useSubtitleStore(state => state.style);
  
  const visibleSegments = allSegments.filter((s: SubtitleSegment) => {
    const track = tracks.find(t => t.id === s.trackId);
    return track?.isVisible;
  });
  
  return (
    <ModernSubtitleOverlay
      currentTime={playbackTime}
      segments={visibleSegments}
      globalStyle={style}
    />
  );
} 