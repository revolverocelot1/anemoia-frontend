import React, { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSubtitleStore } from '../../stores/subtitle-store';
import type { SubtitleSegment, SubtitleStyle } from '../../types/subtitle';
import { DEFAULT_SUBTITLE_STYLE } from '../../types/subtitle';

interface SubtitleOverlayProps {
  videoElement?: HTMLVideoElement | null;
  segments?: SubtitleSegment[];
  currentTime?: number;
  style?: Partial<SubtitleStyle>;
  isEditing?: boolean;
  onSegmentClick?: (segment: SubtitleSegment) => void;
  className?: string;
}

export const SubtitleOverlay: React.FC<SubtitleOverlayProps> = ({
  videoElement,
  segments: propSegments,
  currentTime: propCurrentTime,
  style: propStyle,
  isEditing = false,
  onSegmentClick,
  className = ''
}) => {
  const overlayRef = useRef<HTMLDivElement>(null);
  const [activeSegments, setActiveSegments] = useState<SubtitleSegment[]>([]);
  const [overlaySize, setOverlaySize] = useState({ width: 0, height: 0 });
  
  const {
    currentProject,
    playbackTime,
    subtitleStyle,
    activeTrackId,
    getSegmentsInTimeRange
  } = useSubtitleStore();
  
  // Use prop values or store values
  const currentTime = propCurrentTime ?? playbackTime;
  const segments = propSegments ?? (currentProject ? getSegmentsInTimeRange(0, Infinity) : []);
  const style = { ...DEFAULT_SUBTITLE_STYLE, ...subtitleStyle, ...propStyle };
  
  // Update overlay size
  useEffect(() => {
    const updateSize = () => {
      if (overlayRef.current) {
        const rect = overlayRef.current.getBoundingClientRect();
        setOverlaySize({ width: rect.width, height: rect.height });
      }
    };
    
    updateSize();
    window.addEventListener('resize', updateSize);
    
    const resizeObserver = new ResizeObserver(updateSize);
    if (overlayRef.current) {
      resizeObserver.observe(overlayRef.current);
    }
    
    return () => {
      window.removeEventListener('resize', updateSize);
      resizeObserver.disconnect();
    };
  }, []);
  
  // Update active segments based on current time
  useEffect(() => {
    const active = segments.filter(segment => 
      currentTime >= segment.startTime && currentTime <= segment.endTime
    );
    setActiveSegments(active);
  }, [currentTime, segments]);
  
  // Calculate position based on style
  const getPositionStyle = useCallback((position?: string, alignment?: string) => {
    let pos = position || style.position || 'bottom';
    let align = alignment || style.alignment || 'center';
    
    // Handle compound position values (e.g., 'bottom-center', 'top-left')
    if (typeof pos === 'string' && pos.includes('-')) {
      const [vPos, hPos] = pos.split('-');
      pos = vPos;
      align = hPos || align;
    }
    
    const marginX = (style as any).marginX || 10;
    const marginY = (style as any).marginY || 10;
    
    const baseStyle: React.CSSProperties = {
      position: 'absolute',
      maxWidth: '80%',
      pointerEvents: isEditing ? 'auto' : 'none'
    };
    
    // Horizontal positioning
    switch (align) {
      case 'left':
        baseStyle.left = `${marginX}%`;
        baseStyle.textAlign = 'left';
        break;
      case 'right':
        baseStyle.right = `${marginX}%`;
        baseStyle.textAlign = 'right';
        break;
      case 'center':
      default:
        baseStyle.left = '50%';
        baseStyle.transform = 'translateX(-50%)';
        baseStyle.textAlign = 'center';
        break;
    }
    
    // Vertical positioning
    switch (pos) {
      case 'top':
        baseStyle.top = `${marginY}%`;
        break;
      case 'middle':
      case 'center':
        baseStyle.top = '50%';
        baseStyle.transform = baseStyle.transform 
          ? `${baseStyle.transform} translateY(-50%)` 
          : 'translateY(-50%)';
        break;
      case 'bottom':
      default:
        baseStyle.bottom = `${marginY}%`;
        break;
    }
    
    return baseStyle;
  }, [style, isEditing]);
  
  // Apply text styles
  const getTextStyle = useCallback((segmentStyle?: Partial<SubtitleStyle>) => {
    const mergedStyle = { ...style, ...segmentStyle };
    
    return {
      fontFamily: mergedStyle.fontFamily,
      fontSize: `${mergedStyle.fontSize}px`,
      fontWeight: mergedStyle.fontWeight,
      fontStyle: mergedStyle.fontStyle,
      color: mergedStyle.fontColor,
      backgroundColor: mergedStyle.backgroundColor + Math.round((mergedStyle.backgroundOpacity || 0.8) * 255).toString(16).padStart(2, '0'),
      textShadow: mergedStyle.textShadow,
      WebkitTextStroke: mergedStyle.textStroke,
      padding: `${mergedStyle.padding}px`,
      borderRadius: `${mergedStyle.borderRadius}px`,
      lineHeight: mergedStyle.lineHeight,
      letterSpacing: `${mergedStyle.letterSpacing}px`,
      textAlign: mergedStyle.alignment as any,
      display: 'inline-block',
      whiteSpace: 'pre-wrap',
      wordWrap: 'break-word' as const,
      userSelect: (isEditing ? 'text' : 'none') as any
    };
  }, [style, isEditing]);
  
  // Handle subtitle click in edit mode
  const handleSegmentClick = useCallback((segment: SubtitleSegment) => {
    if (isEditing && onSegmentClick) {
      onSegmentClick(segment);
    }
  }, [isEditing, onSegmentClick]);
  
  // Render karaoke effect if needed
  const renderKaraokeText = useCallback((segment: SubtitleSegment) => {
    const progress = (currentTime - segment.startTime) / (segment.endTime - segment.startTime);
    const words = segment.text.split(' ');
    const wordsPerProgress = Math.floor(words.length * progress);
    
    return (
      <span>
        {words.map((word, index) => (
          <span
            key={index}
            style={{
              color: index < wordsPerProgress ? style.fontColor : style.fontColor + '80',
              transition: 'color 0.3s ease'
            }}
          >
            {word}{index < words.length - 1 ? ' ' : ''}
          </span>
        ))}
      </span>
    );
  }, [currentTime, style.fontColor]);
  
  // Render subtitle with effects
  const renderSubtitle = useCallback((segment: SubtitleSegment) => {
    const duration = segment.endTime - segment.startTime;
    const elapsed = currentTime - segment.startTime;
    const fadeInDuration = Math.min(0.3, duration * 0.1);
    const fadeOutDuration = Math.min(0.3, duration * 0.1);
    
    let opacity = 1;
    if (elapsed < fadeInDuration) {
      opacity = elapsed / fadeInDuration;
    } else if (elapsed > duration - fadeOutDuration) {
      opacity = (duration - elapsed) / fadeOutDuration;
    }
  
  return (
    <motion.div
        key={segment.id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ 
          opacity: opacity,
          y: 0,
          transition: { duration: 0.3 }
        }}
        exit={{ 
          opacity: 0,
          y: -10,
          transition: { duration: 0.3 }
        }}
        style={{
          ...getPositionStyle(segment.style?.position, segment.style?.alignment),
          zIndex: 10
        }}
        onClick={() => handleSegmentClick(segment)}
        className={isEditing ? 'cursor-pointer hover:ring-2 hover:ring-cyan-500 rounded' : ''}
      >
        <div style={getTextStyle(segment.style)}>
          {segment.style?.fontStyle === 'italic' && segment.text.includes(' ') 
            ? renderKaraokeText(segment)
            : segment.text
          }
        </div>
        
        {/* Edit mode indicators */}
        {isEditing && (
          <div className="absolute -top-6 left-0 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 hover:opacity-100 transition-opacity">
            {segment.startTime.toFixed(2)}s - {segment.endTime.toFixed(2)}s
      </div>
        )}
      </motion.div>
    );
  }, [currentTime, getPositionStyle, getTextStyle, handleSegmentClick, renderKaraokeText, isEditing]);
  
  return (
    <div 
      ref={overlayRef}
      className={`absolute inset-0 pointer-events-none ${className}`}
      style={{ zIndex: 5 }}
    >
      <AnimatePresence mode="wait">
        {activeSegments.map(segment => renderSubtitle(segment))}
      </AnimatePresence>
      
      {/* Safe area guides in edit mode */}
      {isEditing && (
        <>
          {/* Title safe area (90% of screen) */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute inset-[5%] border border-dashed border-yellow-500/30 rounded">
              <span className="absolute -top-6 left-2 text-xs text-yellow-500/50">Title Safe</span>
            </div>
          </div>
          
          {/* Action safe area (80% of screen) */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute inset-[10%] border border-dashed border-red-500/30 rounded">
              <span className="absolute -top-6 left-2 text-xs text-red-500/50">Action Safe</span>
            </div>
          </div>
          
          {/* Grid lines */}
          <div className="absolute inset-0 pointer-events-none">
            {/* Horizontal thirds */}
            <div className="absolute top-1/3 left-0 right-0 h-px bg-gray-600/20" />
            <div className="absolute top-2/3 left-0 right-0 h-px bg-gray-600/20" />
            
            {/* Vertical thirds */}
            <div className="absolute top-0 bottom-0 left-1/3 w-px bg-gray-600/20" />
            <div className="absolute top-0 bottom-0 left-2/3 w-px bg-gray-600/20" />
            
            {/* Center cross */}
            <div className="absolute top-1/2 left-0 right-0 h-px bg-cyan-500/20" />
            <div className="absolute top-0 bottom-0 left-1/2 w-px bg-cyan-500/20" />
          </div>
        </>
      )}
      
      {/* Position indicators */}
      {isEditing && activeSegments.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-gray-500 text-sm bg-gray-900/80 px-4 py-2 rounded">
            No subtitles at current time
          </div>
        </div>
      )}
    </div>
  );
};

// Standalone preview component for style editor
export const SubtitlePreview: React.FC<{
  text: string;
  style: Partial<SubtitleStyle>;
  position?: string;
  alignment?: string;
  className?: string;
}> = ({ text, style, position, alignment, className = '' }) => {
  const mergedStyle = { ...DEFAULT_SUBTITLE_STYLE, ...style };
  
  const getPositionStyle = () => {
    let pos = position || mergedStyle.position || 'bottom';
    let align = alignment || mergedStyle.alignment || 'center';
    
    // Handle compound position values (e.g., 'bottom-center', 'top-left')
    if (typeof pos === 'string' && pos.includes('-')) {
      const [vPos, hPos] = pos.split('-');
      pos = vPos;
      align = hPos || align;
    }
    
    const marginX = (mergedStyle as any).marginX || 10;
    const marginY = (mergedStyle as any).marginY || 10;
    
    const baseStyle: React.CSSProperties = {
      position: 'absolute',
      maxWidth: '80%'
    };
    
    // Horizontal positioning
    switch (align) {
      case 'left':
        baseStyle.left = `${marginX}%`;
        baseStyle.textAlign = 'left';
        break;
      case 'right':
        baseStyle.right = `${marginX}%`;
        baseStyle.textAlign = 'right';
        break;
      case 'center':
      default:
        baseStyle.left = '50%';
        baseStyle.transform = 'translateX(-50%)';
        baseStyle.textAlign = 'center';
        break;
    }
    
    // Vertical positioning
    switch (pos) {
      case 'top':
        baseStyle.top = `${marginY}%`;
        break;
      case 'middle':
      case 'center':
        baseStyle.top = '50%';
        baseStyle.transform = baseStyle.transform 
          ? `${baseStyle.transform} translateY(-50%)` 
          : 'translateY(-50%)';
        break;
      case 'bottom':
      default:
        baseStyle.bottom = `${marginY}%`;
        break;
    }
    
    return baseStyle;
  };
  
  const getTextStyle = () => ({
    fontFamily: mergedStyle.fontFamily,
    fontSize: `${mergedStyle.fontSize}px`,
    fontWeight: mergedStyle.fontWeight,
    fontStyle: mergedStyle.fontStyle,
    color: mergedStyle.fontColor,
    backgroundColor: mergedStyle.backgroundColor + Math.round((mergedStyle.backgroundOpacity || 0.8) * 255).toString(16).padStart(2, '0'),
    textShadow: mergedStyle.textShadow,
    WebkitTextStroke: mergedStyle.textStroke,
    padding: `${mergedStyle.padding}px`,
    borderRadius: `${mergedStyle.borderRadius}px`,
    lineHeight: mergedStyle.lineHeight,
    letterSpacing: `${mergedStyle.letterSpacing}px`,
    textAlign: mergedStyle.alignment as any,
    display: 'inline-block',
    whiteSpace: 'pre-wrap',
    wordWrap: 'break-word' as const
  });
  
  return (
    <div className={`relative w-full h-full bg-gray-900 ${className}`}>
      <div style={getPositionStyle()}>
        <div style={getTextStyle()}>
          {text || 'Sample subtitle text'}
        </div>
      </div>
    </div>
  );
};

export default SubtitleOverlay; 