/// <reference lib="webworker" />

// Simple test worker to debug WASM loading issues

self.addEventListener('message', async (event) => {
  const { type } = event.data;
  
  console.log('[SimpleWorker] Received message:', type);
  
  if (type === 'test-load') {
    try {
      // Step 1: Test basic import
      self.postMessage({ type: 'status', message: 'Testing import...' });
      const transformers = await import('@huggingface/transformers');
      self.postMessage({ type: 'status', message: 'Import successful' });
      
      // Step 2: Configure environment
      const { env, pipeline } = transformers;
      
      // Try multiple WASM path configurations
      self.postMessage({ type: 'status', message: 'Configuring environment...' });
      
      env.allowLocalModels = false;
      env.useBrowserCache = true;
      env.allowRemoteModels = true;
      
      // Method 1: Direct assignment
      (env as any).onnx = {
        wasm: {
          wasmPaths: self.location.origin + '/ort-wasm/',
          numThreads: 1
        }
      };
      
      // Method 2: Backends configuration
      if (env.backends?.onnx) {
        self.postMessage({ type: 'status', message: 'Found backends.onnx' });
        if (env.backends.onnx.wasm) {
          env.backends.onnx.wasm.wasmPaths = self.location.origin + '/ort-wasm/';
          env.backends.onnx.wasm.numThreads = 1;
        }
      }
      
      // Method 3: Try setting on globalThis
      (globalThis as any).onnxruntime = {
        env: {
          wasm: {
            wasmPaths: self.location.origin + '/ort-wasm/'
          }
        }
      };
      
      self.postMessage({ 
        type: 'status', 
        message: 'Environment configured',
        details: {
          env: JSON.stringify({
            allowLocalModels: env.allowLocalModels,
            backends: env.backends ? 'exists' : 'missing',
            onnx: (env as any).onnx
          })
        }
      });
      
      // Step 3: Try to create a simple pipeline
      self.postMessage({ type: 'status', message: 'Creating pipeline...' });
      
      const pipe = await pipeline(
        'automatic-speech-recognition',
        'onnx-community/whisper-tiny',
        {
          progress_callback: (progress: any) => {
            self.postMessage({ 
              type: 'progress', 
              progress: progress.progress || 0,
              status: progress.status || 'Loading...'
            });
          }
        }
      );
      
      self.postMessage({ type: 'success', message: 'Pipeline created successfully!' });
      
    } catch (error: any) {
      console.error('[SimpleWorker] Error:', error);
      self.postMessage({ 
        type: 'error', 
        error: error.message,
        stack: error.stack,
        details: error
      });
    }
  }
});

export {}; 