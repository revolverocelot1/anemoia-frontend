import React, { useState, useRef, useEffect, useCallback, Suspense, useMemo, useReducer } from 'react';
import { useSubtitleStore } from '../stores/subtitle-store';
import { useAutoSave } from '../hooks/useAutoSave';
import { useSubtitleKeyboardShortcuts } from '../hooks/useSubtitleKeyboardShortcuts';
import VideoPreview from '../components/subtitle/VideoPreview';
import { SubtitleTimeline } from '../components/subtitle/SubtitleTimeline';
import { ResizableVideoContainer } from '../components/subtitle/ResizableVideoContainer';
import { SubtitleOverlay } from '../components/subtitle/SubtitleOverlay';
import { TranscriptionPanel } from '../components/subtitle/TranscriptionPanel';
import { ModelDownloadPanel } from '../components/subtitle/ModelDownloadPanel';
import { SubtitleSegmentEditor } from '../components/subtitle/SubtitleSegmentEditor';
import { SubtitleStyleControls } from '../components/subtitle/SubtitleStyleControls';
import SubtitleErrorBoundary from '../components/subtitle/SubtitleErrorBoundary';
import BurnProgressModal from '../components/subtitle/BurnProgressModal';
import { exportToSRT, exportToWebVTT, importFromSRT, importFromWebVTT } from '../lib/subtitle-utils';
import { 
  splitSegment, 
  mergeSegments, 
  shiftSegments, 
  scaleSegments,
  fixOverlaps,
  autoFixSegments,
  calculateReadingSpeed,
  findGaps
} from '../lib/subtitle-operations';
import { extractAudioFromVideo } from '../lib/audio-extraction';
import { videoExporter } from '../lib/video-export';
import { hybridVideoExporter } from '../lib/video-export-server';
import type { SubtitleSegment, SubtitleTrack, SubtitleProject } from '../types/subtitle';
import { ChevronDown, Zap, Cloud, Cpu } from 'lucide-react';

// Loading component
const LoadingSpinner = () => (
  <div className="flex items-center justify-center p-8">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
  </div>
);

export default function SubtitlePageEnhanced() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);
  
  // Granular selectors with shallow for stability
  const currentProject = useSubtitleStore(state => state.currentProject);
  const activeTrackId = useSubtitleStore(state => state.activeTrackId);
  const selectedSegmentId = useSubtitleStore(state => state.selectedSegmentId);
  const playbackTime = useSubtitleStore(state => state.playbackTime);
  const isPlaying = useSubtitleStore(state => state.isPlaying);
  
  // Get tracks with a stable empty array reference
  const tracks = useSubtitleStore(state => state.currentProject?.tracks) || [];
  
  const currentTrack = useMemo(() => tracks.find(t => t.id === activeTrackId) || null, [tracks, activeTrackId]);
  
  const segments = useMemo(() => currentTrack?.segments ?? [], [currentTrack]);
  
  const createProject = useSubtitleStore(state => state.createProject);
  const addSegment = useSubtitleStore(state => state.addSegment);
  const updateSegment = useSubtitleStore(state => state.updateSegment);
  const deleteSegment = useSubtitleStore(state => state.deleteSegment);
  const setPlaybackTime = useSubtitleStore(state => state.setPlaybackTime);
  const setIsPlaying = useSubtitleStore(state => state.setIsPlaying);
  const selectSegment = useSubtitleStore(state => state.selectSegment);
  const addTrack = useSubtitleStore(state => state.addTrack);
  const setActiveTrack = useSubtitleStore(state => state.setActiveTrack);
  const updateTrack = useSubtitleStore(state => state.updateTrack);
  const setVideoUrl = useSubtitleStore(state => state.setVideoUrl);
  const setVideoDuration = useSubtitleStore(state => state.setVideoDuration);
  
  // Local state - no changes
  const [videoDuration, setLocalVideoDuration] = useState(0);
  const [videoUrl, setLocalVideoUrl] = useState<string | null>(null);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [showModelManager, setShowModelManager] = useState(false);
  const [selectedSegments, setSelectedSegments] = useState<Set<string>>(new Set());
  const [isExporting, setIsExporting] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isBurning, setIsBurning] = useState(false);
  const [burnProgress, setBurnProgress] = useState(0);
  const [burnStatus, setBurnStatus] = useState('');
  const [burnFormat, setBurnFormat] = useState<'webm' | 'mp4'>('webm');
  const [needsTrackSetup, setNeedsTrackSetup] = useState(false);
  const [showStyleSettings, setShowStyleSettings] = useState(false);
  
  // Setup auto-save
  useAutoSave();
  
  // Setup keyboard shortcuts
  useSubtitleKeyboardShortcuts({ enabled: true });
  
  // Use global state directly, memoized for performance
  const selectedSegment = useMemo(() => 
    segments.find((s: SubtitleSegment) => s.id === selectedSegmentId) || null,
    [segments, selectedSegmentId]
  );
  
  // Handle project and track setup after project creation
  useEffect(() => {
    // Only run if we need to setup tracks and project exists with no tracks
    if (!needsTrackSetup || !currentProject || currentProject.tracks.length > 0) {
      return;
    }
    
    console.log('[SubtitlePageEnhanced] Setting up default track');
    
    // Use the addTrack action instead of direct state manipulation
    addTrack({
      name: 'Track 1',
      language: 'en',
      segments: [],
      isVisible: true,
      isLocked: false,
      style: {}
    });
    
    setNeedsTrackSetup(false);
  }, [needsTrackSetup, currentProject?.tracks.length, addTrack]); // Include addTrack in dependencies
  
  // Remove this problematic effect that causes infinite loops
  // Set active track when first track is created
  // useEffect(() => {
  //   if (currentProject && currentProject.tracks.length > 0 && !activeTrackId) {
  //     const firstTrack = currentProject.tracks[0];
  //     console.log('[SubtitlePageEnhanced] Setting active track:', firstTrack.id);
  //     setActiveTrack(firstTrack.id);
  //   }
  // }, [currentProject, activeTrackId, setActiveTrack]);
  
  // Debug logging for project and track state - Remove segments.length from dependencies
  useEffect(() => {
    console.log('[SubtitlePageEnhanced] State update:', {
      hasProject: !!currentProject,
      projectId: currentProject?.id,
      activeTrackId: activeTrackId,
      currentTrack: currentTrack ? { id: currentTrack.id, name: currentTrack.name } : null,
      segmentsCount: segments.length
    });
  }, [currentProject?.id, activeTrackId, currentTrack?.id]);
  
  // Handle video file selection
  const handleVideoSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setLocalVideoUrl(url);
      
      // Create new project if none exists
      if (!currentProject) {
        const projectName = file.name.replace(/\.[^/.]+$/, '');
        console.log('[SubtitlePageEnhanced] Creating new project:', projectName);
        
        // Create project synchronously using createProject action
        useSubtitleStore.getState().createProject({
          name: projectName,
          videoUrl: url,
          videoName: file.name
        });
        
        // Flag that we need to set up a track
        setNeedsTrackSetup(true);
      } else {
        // If project exists, just update the video URL
        setVideoUrl(url);
      }
    }
  }, [currentProject, setVideoUrl]);
  
  // Extract audio when video is loaded
  useEffect(() => {
    if (videoUrl && videoRef.current) {
      const extractAudio = async () => {
        try {
          console.log('Extracting audio from video...');
          const buffer = await extractAudioFromVideo(videoRef.current!);
          if (buffer) {
            console.log('Audio extracted successfully:', {
              duration: buffer.duration,
              sampleRate: buffer.sampleRate,
              channels: buffer.numberOfChannels
            });
            setAudioBuffer(buffer);
          } else {
            console.error('Failed to extract audio - no buffer returned');
          }
        } catch (error) {
          console.error('Audio extraction error:', error);
        }
      };
      
      // Wait for video to be ready
      if (videoRef.current.readyState >= 2) {
        extractAudio();
      } else {
        videoRef.current.addEventListener('loadeddata', extractAudio, { once: true });
      }
    }
  }, [videoUrl]);
  
  // Handle subtitle import
  const handleImport = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && currentProject && activeTrackId) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        let importedSegments: SubtitleSegment[] = [];
        
        if (file.name.endsWith('.srt')) {
          importedSegments = importFromSRT(content);
        } else if (file.name.endsWith('.vtt')) {
          importedSegments = importFromWebVTT(content);
        }
        
        // Add imported segments
        importedSegments.forEach(segment => {
          addSegment(currentProject.id, activeTrackId, segment);
        });
      };
      reader.readAsText(file);
    }
  }, [currentProject, activeTrackId, addSegment]);
  
  // Handle export
  const handleExport = useCallback(async (format: 'srt' | 'vtt') => {
    if (!segments.length) return;
    
    setIsExporting(true);
    try {
      let content: string;
      let filename: string;
      
      if (format === 'srt') {
        content = exportToSRT(segments);
        filename = `${currentProject?.name || 'subtitles'}.srt`;
      } else {
        content = exportToWebVTT(segments, currentProject?.style);
        filename = `${currentProject?.name || 'subtitles'}.vtt`;
      }
      
      // Create download
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  }, [segments, currentProject]);
  
  // Batch operations
  const handleBatchOperation = useCallback(async (operation: string) => {
    if (!currentProject || !activeTrackId) return;
    
    setIsProcessing(true);
    try {
      const selected = Array.from(selectedSegments)
        .map(id => segments.find((s: SubtitleSegment) => s.id === id))
        .filter(Boolean) as SubtitleSegment[];
      
      const targetSegments = selected.length > 0 ? selected : segments;
      
      switch (operation) {
        case 'fix-overlaps':
          const fixed = fixOverlaps(targetSegments);
          fixed.forEach(segment => {
            updateSegment(currentProject.id, activeTrackId, segment.id, segment);
          });
          break;
          
        case 'auto-fix':
          const autoFixed = autoFixSegments(targetSegments);
          autoFixed.forEach(segment => {
            updateSegment(currentProject.id, activeTrackId, segment.id, segment);
          });
          break;
          
        case 'merge-selected':
          if (selected.length > 1) {
            const merged = mergeSegments(selected);
            if (merged) {
              // Delete old segments
              selected.forEach(s => deleteSegment(currentProject.id, activeTrackId, s.id));
              // Add merged segment
              addSegment(currentProject.id, activeTrackId, merged);
            }
          }
          break;
          
        case 'shift-time':
          const offset = parseFloat(prompt('Enter time offset in seconds (negative to shift left):') || '0');
          if (offset !== 0) {
            const shifted = shiftSegments(targetSegments, offset);
            shifted.forEach(segment => {
              updateSegment(currentProject.id, activeTrackId, segment.id, segment);
            });
          }
          break;
          
        case 'scale-duration':
          const factor = parseFloat(prompt('Enter scale factor (0.5 = half speed, 2 = double speed):') || '1');
          if (factor !== 1) {
            const scaled = scaleSegments(targetSegments, factor);
            scaled.forEach(segment => {
              updateSegment(currentProject.id, activeTrackId, segment.id, segment);
            });
          }
          break;
      }
      
      setSelectedSegments(new Set());
    } catch (error) {
      console.error('Batch operation error:', error);
    } finally {
      setIsProcessing(false);
    }
  }, [currentProject, activeTrackId, segments, selectedSegments, updateSegment, deleteSegment, addSegment]);
  
  // Toggle segment selection
  const toggleSegmentSelection = useCallback((segmentId: string) => {
    setSelectedSegments(prev => {
      const next = new Set(prev);
      if (next.has(segmentId)) {
        next.delete(segmentId);
      } else {
        next.add(segmentId);
      }
      return next;
    });
  }, []);
  
  // Clear video URL on unmount
  useEffect(() => {
    return () => {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
    };
  }, [videoUrl]);
  
  // Memoize callbacks to prevent re-renders
  const handleTimeUpdate = useCallback((time: number) => {
    setPlaybackTime(time);
  }, [setPlaybackTime]);
  
  const handleDurationChange = useCallback((duration: number) => {
    setLocalVideoDuration(duration);
    if (currentProject) {
      setVideoDuration(duration);
    }
  }, [currentProject, setVideoDuration]);
  
  // Memoize video container to prevent re-renders
  const videoContainer = useMemo(() => (
    <ResizableVideoContainer 
      videoUrl={videoUrl || undefined}
      onTimeUpdate={handleTimeUpdate}
      onDurationChange={handleDurationChange}
      videoRef={videoRef}
    />
  ), [videoUrl, handleTimeUpdate, handleDurationChange]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };
  
  // Handle burn subtitles
  const handleBurnSubtitles = useCallback(async () => {
    if (!currentProject || !videoUrl) return;
    
    setIsBurning(true);
    setBurnProgress(0);
    setBurnStatus('Initializing...');
    
    try {
      const blob = await videoExporter.exportWithSubtitles(currentProject, {
        burnSubtitles: true,
        fps: 30,
        quality: 0.9,
        format: burnFormat,
        onProgress: (data) => {
          setBurnProgress(data.progress);
          setBurnStatus(data.status);
          
          // Handle error state
          if (data.progress === -1) {
            setIsBurning(false);
            alert('Export failed: ' + data.status);
          }
        }
      });
      
      if (blob) {
        const extension = burnFormat === 'mp4' ? 'mp4' : 'webm';
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${currentProject.name || 'video'}-with-subtitles.${extension}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        // Show success state
        setBurnStatus('Export complete!');
        setBurnProgress(100);
      }
    } catch (error) {
      console.error('Burn subtitles error:', error);
      setBurnStatus('Error during export');
    } finally {
      setTimeout(() => setIsBurning(false), 2000);
    }
  }, [currentProject, videoUrl, burnFormat]);
  
  // Cancel burn
  const handleCancelBurn = useCallback(() => {
    // TODO: Implement actual cancellation logic
    setIsBurning(false);
    setBurnProgress(0);
    setBurnStatus('');
  }, []);
  
  return (
    <SubtitleErrorBoundary>
      <div className="min-h-screen bg-gray-900 text-white p-4">
        <div className="max-w-[1920px] mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 text-transparent bg-clip-text">
              AI Subtitle Editor
            </h1>
            
            <div className="flex items-center gap-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
              >
                Select Video
              </button>
              
              {segments.length > 0 && (
                <>
                  <button
                    onClick={() => importInputRef.current?.click()}
                    className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
                  >
                    Import
                  </button>
                  
                  <div className="relative group">
                    <button
                      disabled={isExporting}
                      className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
                    >
                      {isExporting ? 'Exporting...' : 'Export'}
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                    
                    <div className="absolute right-0 top-full mt-2 w-56 bg-gray-800 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 border border-gray-700">
                      <div className="p-2">
                      <button
                        onClick={() => handleExport('srt')}
                          className="w-full px-3 py-2 text-left hover:bg-gray-700 rounded transition-colors flex items-center gap-2"
                      >
                          <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        Export as SRT
                      </button>
                      <button
                        onClick={() => handleExport('vtt')}
                          className="w-full px-3 py-2 text-left hover:bg-gray-700 rounded transition-colors flex items-center gap-2"
                      >
                          <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        Export as WebVTT
                      </button>
                        
                        <div className="border-t border-gray-700 my-2"></div>
                        
                        <div className="px-3 py-2">
                          <label className="text-sm text-gray-400 mb-1 block">Burn Subtitles Format</label>
                        <select
                          value={burnFormat}
                          onChange={(e) => setBurnFormat(e.target.value as 'webm' | 'mp4')}
                            className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-cyan-500 outline-none"
                        >
                            <option value="webm">WebM (Fast)</option>
                            <option value="mp4">MP4 (Compatible)</option>
                        </select>
                        </div>
                        
                        <button
                          onClick={() => handleBurnSubtitles()}
                          className="w-full px-3 py-2 bg-cyan-600 hover:bg-cyan-700 rounded transition-colors flex items-center justify-center gap-2 text-white mt-2"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                          </svg>
                          Burn Subtitles to Video
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => setShowModelManager(!showModelManager)}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors"
                  >
                    Models
                  </button>
                </>
              )}
            </div>
          </div>
          
          {/* Hidden file inputs */}
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleVideoSelect}
            className="hidden"
          />
          <input
            ref={importInputRef}
            type="file"
            accept=".srt,.vtt"
            onChange={handleImport}
            className="hidden"
          />
          
          {videoUrl ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Left panel - Video and timeline */}
              <div className="lg:col-span-2 space-y-4">
                {/* Video container */}
                {videoContainer}
                
                {/* Timeline */}
                <div className="bg-gray-800 rounded-lg p-4">
                  <SubtitleTimeline
                    segments={segments}
                    duration={videoDuration}
                    currentTime={playbackTime}
                    onTimeChange={(time) => {
                      setPlaybackTime(time);
                      if (videoRef.current) {
                        videoRef.current.currentTime = time;
                      }
                    }}
                    onSegmentClick={(segmentId) => selectSegment(segmentId)}
                  />
                </div>
                
                {/* Fixed editor below timeline */}
                {selectedSegment && (
                  <div className="mt-4 bg-gray-800 rounded-lg p-4">
                    <SubtitleSegmentEditor
                      segment={selectedSegment}
                      trackId={activeTrackId || ''}
                      onClose={() => selectSegment(selectedSegment.id, false)}
                      autoFocus={true}
                    />
                  </div>
                )}
              </div>
              
              {/* Right panel - Unified Editor */}
              <div className="space-y-4">
                {/* Transcription Panel */}
                <div className="bg-gray-800 rounded-lg p-4">
                  <TranscriptionPanel
                    audioBuffer={audioBuffer}
                    onTranscriptionComplete={(segments) => {
                      console.log('Transcription complete:', segments);
                    }}
                  />
                </div>
                
                {/* Style Settings Toggle */}
                <div className="bg-gray-800 rounded-lg p-4">
                  <button
                    onClick={() => setShowStyleSettings(!showStyleSettings)}
                    className="w-full flex items-center justify-between text-left"
                  >
                    <h3 className="font-semibold text-white">Style & Position Settings</h3>
                    <ChevronDown className={`w-4 h-4 transition-transform ${showStyleSettings ? 'rotate-180' : ''}`} />
                  </button>
                  
                  {showStyleSettings && (
                    <div className="mt-4">
                      <SubtitleStyleControls />
                    </div>
                  )}
                </div>
                
                {/* Segment list */}
                <div className="bg-gray-800 rounded-lg p-4 max-h-96 overflow-y-auto">
                  <h3 className="font-semibold mb-3">Subtitle Segments</h3>
                  
                  {segments.length === 0 ? (
                    <p className="text-gray-400 text-sm">
                      No subtitles yet. Use AI transcription or add manually.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {segments.map((segment) => {
                        const readingSpeed = calculateReadingSpeed(segment);
                        const isSelected = selectedSegmentId === segment.id;
                        const isInSelection = selectedSegments.has(segment.id);
                        
                        return (
                          <div
                            key={segment.id}
                            className={`p-3 rounded-lg cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-blue-600'
                                : isInSelection
                                ? 'bg-blue-600/30'
                                : 'bg-gray-700 hover:bg-gray-600'
                            }`}
                            onClick={() => selectSegment(segment.id)}
                            onDoubleClick={() => toggleSegmentSelection(segment.id)}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs text-gray-400">
                                {new Date(segment.startTime * 1000).toISOString().substr(14, 5)} - 
                                {new Date(segment.endTime * 1000).toISOString().substr(14, 5)}
                              </span>
                              {!readingSpeed.isOptimal && (
                                <span className="text-xs text-yellow-400">
                                  {readingSpeed.wordsPerMinute > 180 ? 'Too fast' : 'Too slow'}
                                </span>
                              )}
                            </div>
                            <p className="text-sm line-clamp-2">{segment.text}</p>
                            {segment.speaker && (
                              <span className="text-xs text-blue-400 mt-1">
                                Speaker: {segment.speaker}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
        ) : (
          <div className="flex items-center justify-center h-[calc(100vh-200px)]">
            <div className="text-center">
                <div className="w-32 h-32 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </div>
                <h2 className="text-2xl font-semibold mb-2">No video selected</h2>
                <p className="text-gray-400 mb-6">Select a video file to start adding subtitles</p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors text-lg"
                >
                  Select Video File
                </button>
              </div>
            </div>
          )}

          {/* Model manager modal */}
          {showModelManager && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-gray-800 rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold">Whisper Model Manager</h2>
                  <button
                    onClick={() => setShowModelManager(false)}
                    className="text-gray-400 hover:text-white"
                  >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                <ModelDownloadPanel />
              </div>
            </div>
          )}

        </div>
      </div>
      
      {/* Burn Progress Modal */}
      {isBurning && (
        <BurnProgressModal
          isOpen={isBurning}
          progress={burnProgress}
          status={burnStatus}
          format={burnFormat}
          onCancel={handleCancelBurn}
        />
      )}
    </SubtitleErrorBoundary>
  );
} 