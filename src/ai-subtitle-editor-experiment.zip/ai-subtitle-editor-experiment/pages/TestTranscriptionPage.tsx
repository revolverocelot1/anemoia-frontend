import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Upload, Mic, FileAudio } from 'lucide-react';

const TestTranscriptionPage: React.FC = () => {
  const navigate = useNavigate();
  const [logs, setLogs] = useState<Array<{ message: string; type: 'info' | 'error' | 'success' | 'warning' }>>([]);
  const [worker, setWorker] = useState<Worker | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const log = (message: string, type: 'info' | 'error' | 'success' | 'warning' = 'info') => {
    setLogs(prev => [...prev, { 
      message: `[${new Date().toLocaleTimeString()}] ${message}`, 
      type 
    }]);
    console.log(message);
  };

  const testWorker = async () => {
    log('Testing Whisper worker...');
    setIsLoading(true);
    
    try {
      const newWorker = new Worker(new URL('../workers/whisper.worker.ts', import.meta.url), { 
        type: 'module' 
      });
      
      newWorker.addEventListener('error', (event) => {
        log(`Worker error: ${event.message}`, 'error');
        setIsLoading(false);
      });
      
      newWorker.addEventListener('message', (event) => {
        const { type, progress, status, error, details } = event.data;
        
        if (type === 'progress') {
          log(`Progress: ${progress}% - ${status}`, 'info');
        } else if (type === 'error') {
          log(`Worker error: ${error}`, 'error');
          if (details) {
            log(`Details: ${JSON.stringify(details, null, 2)}`, 'error');
          }
          setIsLoading(false);
        } else if (type === 'result') {
          log('Worker completed successfully', 'success');
          setIsLoading(false);
        }
      });
      
      setWorker(newWorker);
      log('Worker created, sending load-model message...', 'success');
      
      newWorker.postMessage({
        type: 'load-model',
        model: 'whisper-tiny'
      });
      
    } catch (error: any) {
      log(`Failed to create worker: ${error.message}`, 'error');
      setIsLoading(false);
    }
  };

  const testAudioTranscription = async () => {
    if (!worker) {
      log('Worker not initialized. Please test worker first.', 'error');
      return;
    }

    log('Creating test audio...');
    
    // Create a simple test audio (1 second of silence)
    const sampleRate = 16000;
    const duration = 1;
    const audioData = new Float32Array(sampleRate * duration);
    
    // Add a simple sine wave
    for (let i = 0; i < audioData.length; i++) {
      audioData[i] = Math.sin(2 * Math.PI * 440 * i / sampleRate) * 0.1;
    }
    
    log('Sending audio to worker for transcription...', 'info');
    
    worker.postMessage({
      type: 'transcribe',
      audio: audioData,
      options: {
        language: 'en',
        task: 'transcribe'
      }
    });
  };

  const getLogColor = (type: string) => {
    switch(type) {
      case 'error': return 'text-red-500';
      case 'success': return 'text-green-500';
      case 'warning': return 'text-yellow-500';
      default: return 'text-blue-500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </button>

        <h1 className="text-3xl font-bold mb-8">Transcription Test Page</h1>

        <div className="space-y-4 mb-8">
          <button
            onClick={testWorker}
            disabled={isLoading}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 px-6 py-3 rounded-lg transition-colors"
          >
            <Mic className="w-5 h-5" />
            {isLoading ? 'Loading...' : 'Test Whisper Worker'}
          </button>

          <button
            onClick={testAudioTranscription}
            disabled={!worker || isLoading}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 px-6 py-3 rounded-lg transition-colors"
          >
            <FileAudio className="w-5 h-5" />
            Test Audio Transcription
          </button>
        </div>

        <div className="bg-black rounded-lg p-4 max-h-[600px] overflow-y-auto">
          <h2 className="text-lg font-semibold mb-4">Logs:</h2>
          <div className="space-y-1 font-mono text-sm">
            {logs.length === 0 ? (
              <div className="text-gray-500">No logs yet. Click a test button to start.</div>
            ) : (
              logs.map((log, index) => (
                <div key={index} className={getLogColor(log.type)}>
                  {log.message}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestTranscriptionPage; 