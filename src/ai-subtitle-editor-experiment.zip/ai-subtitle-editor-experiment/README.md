# AI Subtitle Editor - Experimental Version

This folder contains the experimental AI subtitle editor that uses OpenAI's Whisper AI models for automatic transcription.

## Status
This is a failed experiment that has been moved here for potential future development. The implementation had various issues including model loading errors and performance problems.

## Files Moved
- All subtitle components from `/src/components/subtitle/`
- Subtitle pages: `SubtitlePageEnhanced.tsx`, `TestTranscriptionPage.tsx`, `SubtitleEditorLanding.tsx`
- Subtitle utilities: `subtitle-utils.ts`, `subtitle-operations.ts`
- Subtitle store: `subtitle-store.ts`
- Subtitle types: `subtitle.ts`
- Subtitle hooks: `useSubtitleKeyboardShortcuts.ts`
- Whisper workers: `whisper.worker.ts`, `whisper-simple.worker.ts`

## Original Implementation
The original, simpler subtitle editor can be found in the main application.

## Note
This experimental version will be revisited later for potential improvements or integration with a backend service for better performance. 