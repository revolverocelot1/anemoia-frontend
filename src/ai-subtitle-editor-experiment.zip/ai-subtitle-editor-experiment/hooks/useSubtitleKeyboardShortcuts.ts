import { useEffect, useCallback, useRef, useState } from 'react';
import { useSubtitleStore } from '../stores/subtitle-store';
import { KEYBOARD_SHORTCUTS, type KeyboardShortcut } from '../types/subtitle';

interface KeyboardShortcutsOptions {
  enabled?: boolean;
  onShortcut?: (action: string) => void;
}

export function useSubtitleKeyboardShortcuts(options: KeyboardShortcutsOptions = {}) {
  const { enabled = true, onShortcut } = options;
  const activeElementRef = useRef<Element | null>(null);
  
  const {
    // Playback
    isPlaying,
    setIsPlaying,
    playbackTime,
    videoDuration,
    setPlaybackTime,
    skipForward,
    skipBackward,
    playbackRate,
    setPlaybackRate,
    
    // Selection
    selectedSegmentIds,
    selectSegment,
    selectAllSegments,
    clearSelection,
    
    // Segments
    addSegment,
    deleteSelectedSegments,
    mergeSegments,
    splitSegment,
    
    // Track operations
    activeTrackId,
    currentProject,
    
    // UI
    zoomLevel,
    setZoomLevel,
    
    // Save
    saveProject,
    hasUnsavedChanges,
    
    // Export
    exportSegments
  } = useSubtitleStore();
  
  // Check if we're in an input field
  const isInputActive = useCallback(() => {
    const activeElement = document.activeElement;
    activeElementRef.current = activeElement;
    
    if (!activeElement) return false;
    
    const tagName = activeElement.tagName.toLowerCase();
    const isContentEditable = activeElement.getAttribute('contenteditable') === 'true';
    
    return (
      tagName === 'input' ||
      tagName === 'textarea' ||
      tagName === 'select' ||
      isContentEditable
    );
  }, []);

  // Handle keyboard shortcuts
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (!enabled) return;
    
    // Skip if user is typing in an input field
    if (isInputActive() && !e.ctrlKey && !e.metaKey) return;
    
    // Find matching shortcut
    const shortcut = KEYBOARD_SHORTCUTS.find(s => {
      const keyMatch = s.key.toLowerCase() === e.key.toLowerCase();
      const ctrlMatch = s.ctrl ? (e.ctrlKey || e.metaKey) : !(e.ctrlKey || e.metaKey);
      const shiftMatch = s.shift ? e.shiftKey : !e.shiftKey;
      const altMatch = s.alt ? e.altKey : !e.altKey;
      
      return keyMatch && ctrlMatch && shiftMatch && altMatch;
    });
    
    if (!shortcut) return;
    
    // Prevent default browser behavior
      e.preventDefault();
    e.stopPropagation();
    
    // Execute action
    executeAction(shortcut.action);
    
    // Call callback if provided
    if (onShortcut) {
      onShortcut(shortcut.action);
    }
  }, [enabled, isInputActive, onShortcut]);

  // Execute shortcut action
  const executeAction = useCallback((action: string) => {
    switch (action) {
      // Playback controls
      case 'playPause':
        setIsPlaying(!isPlaying);
        break;
        
      case 'skipForward5':
        skipForward(5);
        break;
        
      case 'skipBackward5':
        skipBackward(5);
        break;
        
      case 'skipForward10':
        skipForward(10);
        break;
        
      case 'skipBackward10':
        skipBackward(10);
        break;
        
      case 'skipForward1':
        skipForward(1);
        break;
        
      case 'skipBackward1':
        skipBackward(1);
        break;
        
      case 'jumpToStart':
        setPlaybackTime(0);
        break;
        
      case 'jumpToEnd':
        setPlaybackTime(videoDuration);
        break;
        
      case 'speedUp':
        setPlaybackRate(Math.min(2, playbackRate + 0.25));
        break;
        
      case 'speedDown':
        setPlaybackRate(Math.max(0.25, playbackRate - 0.25));
        break;
        
      case 'resetSpeed':
        setPlaybackRate(1);
        break;
        
      // Subtitle operations
      case 'newSubtitle':
        if (currentProject && activeTrackId) {
          addSegment(activeTrackId, {
            text: '',
            startTime: playbackTime,
            endTime: playbackTime + 2
          });
        }
        break;
        
      case 'deleteSelected':
        if (selectedSegmentIds.length > 0) {
          deleteSelectedSegments();
        }
        break;
        
      case 'mergeSelected':
        if (selectedSegmentIds.length > 1 && activeTrackId) {
          mergeSegments(activeTrackId, selectedSegmentIds);
        }
        break;
        
      case 'splitAtPlayhead':
        if (selectedSegmentIds.length === 1 && activeTrackId) {
          // Find the selected segment
          const track = currentProject?.tracks.find(t => t.id === activeTrackId);
          const segment = track?.segments.find(s => s.id === selectedSegmentIds[0]);
          
          if (segment && playbackTime > segment.startTime && playbackTime < segment.endTime) {
            splitSegment(activeTrackId, segment.id, playbackTime);
          }
        }
        break;
        
      // Selection
      case 'selectAll':
        selectAllSegments();
        break;
        
      case 'clearSelection':
        clearSelection();
        break;
        
      case 'nextSubtitle':
        navigateToNextSubtitle();
        break;
        
      case 'previousSubtitle':
        navigateToPreviousSubtitle();
        break;
        
      // File operations
      case 'save':
        if (hasUnsavedChanges) {
          saveProject();
        }
        break;
        
      case 'export':
        // Trigger export modal (this would be handled by the UI)
        document.dispatchEvent(new CustomEvent('showExportModal'));
        break;
        
      // View controls
      case 'zoomIn':
        setZoomLevel(Math.min(10, zoomLevel * 1.2));
        break;
        
      case 'zoomOut':
        setZoomLevel(Math.max(0.1, zoomLevel / 1.2));
        break;
        
      case 'resetZoom':
        setZoomLevel(1);
        break;
        
      // Timeline navigation
      case 'frameForward':
        // Assuming 30fps
        skipForward(1 / 30);
        break;
        
      case 'frameBackward':
        skipBackward(1 / 30);
        break;
        
      // Find functionality
      case 'find':
        document.dispatchEvent(new CustomEvent('showFindDialog'));
        break;
        
      case 'findNext':
        document.dispatchEvent(new CustomEvent('findNext'));
        break;
        
      case 'findPrevious':
        document.dispatchEvent(new CustomEvent('findPrevious'));
        break;
    }
  }, [
    isPlaying, setIsPlaying, playbackTime, videoDuration, setPlaybackTime,
    skipForward, skipBackward, playbackRate, setPlaybackRate,
    currentProject, activeTrackId, addSegment, selectedSegmentIds,
    deleteSelectedSegments, mergeSegments, splitSegment,
    selectAllSegments, clearSelection, hasUnsavedChanges, saveProject,
    zoomLevel, setZoomLevel
  ]);

  // Navigate to next subtitle
  const navigateToNextSubtitle = useCallback(() => {
    if (!currentProject || !activeTrackId) return;
    
    const track = currentProject.tracks.find(t => t.id === activeTrackId);
    if (!track) return;
    
    const sortedSegments = [...track.segments].sort((a, b) => a.startTime - b.startTime);
    const currentSegmentIndex = selectedSegmentIds.length > 0
      ? sortedSegments.findIndex(s => s.id === selectedSegmentIds[0])
      : -1;
    
    let nextSegment;
    if (currentSegmentIndex >= 0 && currentSegmentIndex < sortedSegments.length - 1) {
      nextSegment = sortedSegments[currentSegmentIndex + 1];
    } else {
      // Find first segment after current playback time
      nextSegment = sortedSegments.find(s => s.startTime > playbackTime);
    }
    
    if (nextSegment) {
      selectSegment(nextSegment.id, false);
      setPlaybackTime(nextSegment.startTime);
    }
  }, [currentProject, activeTrackId, selectedSegmentIds, playbackTime, selectSegment, setPlaybackTime]);

  // Navigate to previous subtitle
  const navigateToPreviousSubtitle = useCallback(() => {
    if (!currentProject || !activeTrackId) return;
    
    const track = currentProject.tracks.find(t => t.id === activeTrackId);
    if (!track) return;
    
    const sortedSegments = [...track.segments].sort((a, b) => a.startTime - b.startTime);
    const currentSegmentIndex = selectedSegmentIds.length > 0
      ? sortedSegments.findIndex(s => s.id === selectedSegmentIds[0])
      : sortedSegments.length;
    
    let previousSegment;
    if (currentSegmentIndex > 0) {
      previousSegment = sortedSegments[currentSegmentIndex - 1];
    } else {
      // Find last segment before current playback time
      const segmentsBefore = sortedSegments.filter(s => s.endTime < playbackTime);
      previousSegment = segmentsBefore[segmentsBefore.length - 1];
    }
    
    if (previousSegment) {
      selectSegment(previousSegment.id, false);
      setPlaybackTime(previousSegment.startTime);
    }
  }, [currentProject, activeTrackId, selectedSegmentIds, playbackTime, selectSegment, setPlaybackTime]);

  // Set up event listeners
  useEffect(() => {
    if (!enabled) return;
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [enabled, handleKeyDown]);

  // Additional shortcuts for special keys
  useEffect(() => {
    if (!enabled) return;
    
    const handleSpecialKeys = (e: KeyboardEvent) => {
      // Escape key to exit fullscreen
      if (e.key === 'Escape') {
        if (document.fullscreenElement) {
          document.exitFullscreen();
        }
      }
      
      // F11 for fullscreen
      if (e.key === 'F11') {
        e.preventDefault();
        const videoContainer = document.querySelector('.video-container');
        if (videoContainer) {
          if (!document.fullscreenElement) {
            videoContainer.requestFullscreen();
      } else {
            document.exitFullscreen();
          }
        }
      }
    };
    
    window.addEventListener('keydown', handleSpecialKeys);
    
    return () => {
      window.removeEventListener('keydown', handleSpecialKeys);
    };
  }, [enabled]);

  // Export helper functions
  const getShortcutForAction = (action: string): KeyboardShortcut | undefined => {
    return KEYBOARD_SHORTCUTS.find(s => s.action === action);
  };

  const formatShortcut = (shortcut: KeyboardShortcut): string => {
    const parts: string[] = [];
    
    if (shortcut.ctrl) parts.push('Ctrl');
    if (shortcut.alt) parts.push('Alt');
    if (shortcut.shift) parts.push('Shift');
    
    // Format special keys
    let key = shortcut.key;
    if (key === ' ') key = 'Space';
    if (key === 'ArrowLeft') key = '←';
    if (key === 'ArrowRight') key = '→';
    if (key === 'ArrowUp') key = '↑';
    if (key === 'ArrowDown') key = '↓';
    
    parts.push(key);
    
    return parts.join('+');
  };

  return {
    executeAction,
    getShortcutForAction,
    formatShortcut,
    shortcuts: KEYBOARD_SHORTCUTS,
    isInputActive: isInputActive()
  };
}

// Hook for displaying keyboard shortcuts help
export function useKeyboardShortcutsHelp() {
  const [showHelp, setShowHelp] = useState(false);
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Show help with F1 or Shift+?
      if (e.key === 'F1' || (e.shiftKey && e.key === '?')) {
        e.preventDefault();
        setShowHelp(prev => !prev);
      }
    };
    
      window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);
  
  return {
    showHelp,
    setShowHelp,
    toggleHelp: () => setShowHelp(prev => !prev)
  };
}

// Extend keyboard shortcuts in types
export const EXTENDED_KEYBOARD_SHORTCUTS: KeyboardShortcut[] = [
  ...KEYBOARD_SHORTCUTS,
  { key: 'f', action: 'frameForward', description: 'Next frame' },
  { key: 'd', action: 'frameBackward', description: 'Previous frame' },
  { key: 'f', ctrl: true, action: 'find', description: 'Find subtitle' },
  { key: 'g', ctrl: true, action: 'findNext', description: 'Find next' },
  { key: 'g', ctrl: true, shift: true, action: 'findPrevious', description: 'Find previous' },
  { key: 'ArrowUp', action: 'speedUp', description: 'Increase playback speed' },
  { key: 'ArrowDown', action: 'speedDown', description: 'Decrease playback speed' },
  { key: 'r', ctrl: true, action: 'resetSpeed', description: 'Reset playback speed' },
  { key: 'F11', action: 'fullscreen', description: 'Toggle fullscreen' },
  { key: 'F1', action: 'help', description: 'Show keyboard shortcuts' }
]; 